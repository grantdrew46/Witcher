const {boot}=require('/home/claude/T/harness.js');
const S=boot('/home/claude/W/sheet.html'), G=boot('/home/claude/W/gm.html');
setTimeout(()=>{
  const es=x=>{try{return S.dom.window.eval(x);}catch(e){return 'THREW: '+e.message;}};
  const eg=x=>{try{return G.dom.window.eval(x);}catch(e){return 'THREW: '+e.message;}};
  const bad=[];
  /* The first version of this compared with !== true and !== , which pass on
     a thrown string \u2014 so a probe whose code did not even run reported ok.
     A condition must be a real boolean or it is a broken probe, not a pass. */
  const chk=(label,ok,detail)=>{
    if(typeof ok==='string' && /^THREW/.test(ok)){
      console.log('  BUG '+label+'  \u2014 probe threw: '+ok.slice(0,80));
      bad.push(label+' (threw)'); return;
    }
    if(typeof ok!=='boolean'){
      console.log('  ??? '+label+'  \u2014 probe returned '+typeof ok+', not a boolean: '
        +JSON.stringify(ok).slice(0,60));
      bad.push(label+' (not a boolean)'); return;
    }
    console.log('  '+(ok?'ok  ':'BUG ')+label+(detail?('  \u2014 '+detail):''));
    if(!ok) bad.push(label);
  };
  es(`window.toast=function(t){window.__t=t;};window.save=function(){};
      window.renderInventory=function(){};window.renderCompTracker=function(){};
      window.renderComp=function(){};window.syncLogLine=function(){};
      window.renderVentures=function(){};window._ventureSyncPanel=function(){};
      window.syncSend=function(){};window._sync={connected:false};
      window.confirm=function(){return true;};window.prompt=function(a,b){return b;};`);

  console.log('=== foraging ===');
  // does a fumble ever un-spend?
  es('char._forageSpent=true; char._clock={day:1,watch:0};');
  es('_applyClock({day:2,watch:0,label:"Day 2"});');
  chk('a new day clears the worked-out ground',
    es('char._forageSpent===false || char._forageSpent==null')===true,
    'fumble set it; the clock advanced');
  // negative / silly DCs
  chk('forageHours copes with a missing DC', es('typeof forageHours(undefined)==="number"')===true);
  chk('forageableAt copes with an unknown place',
    es('Array.isArray(forageableAt("nowhere"))')===true);
  // does a successful forage respect qty formulas like 1d6/2 (can round to 0)?
  const zero=es(`(function(){
    char.skills['Wilderness Survival']={val:20}; char.stats.INT=10;
    var c=getAllCompData().filter(function(x){return String(x.qty)==='1d6/2';})[0];
    if(!c) return 'no such formula';
    var mins=[];
    for(var i=0;i<20;i++){ char.inventory=[]; char._forageSpent=false;
      _forageAttempt(c,'T');
      if(char.inventory[0]) mins.push(char.inventory[0].qty); }
    return JSON.stringify({min:Math.min.apply(null,mins),max:Math.max.apply(null,mins)});})()`);
  chk('a halved quantity never yields zero items',
    (typeof zero==='string' && !/^THREW/.test(zero) && !/\"min\":0/.test(zero)), String(zero));

  console.log('\n=== settlements and stock ===');
  chk('an unknown tier is clamped',
    es('(function(){pcCitySet("x","X",99);return pcCity().tier===3;})()')===true);
  chk('a zero tier is clamped',
    es('(function(){pcCitySet("y","Y",0);return pcCity().tier>=1;})()')===true);
  chk('switching city then back inside the window keeps the shelf',
    es(`(function(){
      char._clock={day:1,watch:0}; char._shopStamp=null;
      pcCitySet('a','A',2); var first=JSON.stringify(_serializeStock());
      pcCitySet('b','B',2); pcCitySet('a','A',2);
      return JSON.stringify(_serializeStock())===first;})()`)===true);
  chk('a tier change at the same city restocks',
    es(`(function(){
      char._clock={day:1,watch:0}; char._shopStamp=null;
      pcCitySet('c','C',1); var a=Object.keys(_lanStock).length;
      pcCitySet('c','C',3); var b=Object.keys(_lanStock).length;
      return b>a;})()`)===true, 'hamlet -> city should open more shops');

  console.log('\n=== points of interest ===');
  chk('the shop card handles an unknown shop id',
    es('(function(){try{pcBattlePoiCard({n:"X",poi:true,pkind:"shop",ptarget:"nonesuch"});'
      +'var e=document.getElementById("pcPoiPop");var ok=!!e;if(e)e.remove();return ok;}catch(x){return "THREW";}})()')===true);
  chk('an unknown poi kind does not throw',
    es('(function(){try{pcBattlePoiCard({n:"X",poi:true,pkind:"wat"});'
      +'var e=document.getElementById("pcPoiPop");if(e)e.remove();return true;}catch(x){return "THREW: "+x.message;}})()')===true);
  chk('_poiOpenGame survives a missing game',
    es('(function(){try{_poiOpenGame("notagame");return true;}catch(x){return "THREW";}})()')===true);
  chk('mountActiveMinigame exists or is guarded',
    es('typeof mountActiveMinigame==="function" || String(_poiOpenGame).indexOf("typeof mountActiveMinigame")>=0')===true);

  console.log('\n=== the clock ===');
  chk('the sheet clock survives a malformed message',
    es('(function(){_applyClock({});return pcClock().day>=1;})()')===true);
  chk('watch wraps rather than running off the end',
    eg('(function(){gmClockSet(1,4);gmClockAdvance(1);return gmClock().day===2&&gmClock().watch===0;})()')===true);
  chk('advancing zero watches does not move the date',
    eg('(function(){gmClockSet(5,2);var a=gmClockLabel();gmClockAdvance(0);return gmClockLabel()===a;})()')===true,
    'advance(0) should be a no-op');

  console.log('\n=== ventures ===');
  chk('a venture with no myCapital still winds up',
    es(`(function(){
      char.crowns=0;
      char._ventures=[{id:'old',type:'stall',name:'Legacy',capital:800,rep:0,weeks:0,
        earned:0,debt:0,closed:false,partner:null,partnerBiz:0,staffBiz:0,linkedTo:null}];
      window.confirm=function(){return true;};
      ventureClose('old');
      return char.crowns===400;})()`)===true, 'pre-band ventures lack myCapital');
  chk('the armoury does not sell its last piece',
    es('_ventureSellStock({rep:5,stock:[{name:"A",val:100}]},20,10,{mult:1}).coin===0')===true);
  chk('a band is found for a silly capital',
    es('typeof _ventureBand(-5).dc==="number"')===true);

  console.log('\n=== textures and kinds ===');
  chk('every alias points at a real kind',
    eg(`Object.keys(WB.KIND_ALIAS||{}).every(function(k){
      return WB.KINDS.some(function(x){return x.k===WB.KIND_ALIAS[k];}); })`)===true);
  chk('no alias shadows a real kind',
    eg(`Object.keys(WB.KIND_ALIAS||{}).every(function(k){
      return !WB.KINDS.some(function(x){return x.k===k;}); })`)===true,
    'an alias for a name that already exists would be dead');

  console.log('\n' + (bad.length ? ('FOUND '+bad.length+' BUG(S)') : 'no bugs found'));
  process.exit(0);
},6000);
