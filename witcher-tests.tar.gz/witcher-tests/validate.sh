#!/bin/bash
# validate.sh <name>   e.g. validate.sh sheet
set -u
export NODE_PATH=/home/claude/.npm-global/lib/node_modules
N="$1"; cd /home/claude/W || exit 1
case "$N" in
  sheet) BP=-15; BB=1; BK=0 ;;
  gm)    BP=-8;  BB=1; BK=0 ;;
  map)   BP=0;   BB=0; BK=0 ;;
  *) echo "unknown $N"; exit 1 ;;
esac
python3 - "$N" <<'PY'
import re,sys
n=sys.argv[1]
h=open(f'/home/claude/W/{n}.html',encoding='utf-8').read()
js='\n;\n'.join(re.findall(r'<script(?![^>]*\bsrc=)[^>]*>(.*?)</script>',h,re.S))
open(f'/home/claude/W/{n}.js','w',encoding='utf-8').write(js)
print('brackets %d %d %d'%(js.count('(')-js.count(')'),js.count('{')-js.count('}'),js.count('[')-js.count(']')))
PY
B=$(python3 -c "
import re
js=open('/home/claude/W/$N.js',encoding='utf-8').read()
print(js.count('(')-js.count(')'), js.count('{')-js.count('}'), js.count('[')-js.count(']'))")
set -- $B
if [ "$1" -ne "$BP" ] || [ "$2" -ne "$BB" ] || [ "$3" -ne "$BK" ]; then
  echo "BRACKET DRIFT: got $1/$2/$3 baseline $BP/$BB/$BK"; else echo "brackets match baseline"; fi
node --check "$N.js" && echo "node --check OK" || { echo "SYNTAX FAIL"; exit 1; }
node --max-old-space-size=7168 /home/claude/T/boot.js "$N.html"

# Size gate. 20 MB means 20,000,000 bytes, not 20 MiB — the sheet sat at
# 20.55 MB while a MiB-based check called it fine.
B=$(stat -c%s "/home/claude/W/$N.html")
if [ "$B" -ge 20000000 ]; then
  printf "SIZE FAIL %s: %d bytes = %.2f MB (limit 20 MB)\n" "$N.html" "$B" "$(echo "scale=4;$B/1000000"|bc)"
else
  printf "size OK   %s: %.2f MB, %d KB headroom\n" "$N.html" "$(echo "scale=4;$B/1000000"|bc)" "$(( (20000000-B)/1000 ))"
fi
