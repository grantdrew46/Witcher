# Vocabulary

Every fact here was extracted by measurement (`node vocab.js`), and suite 09
re-checks the load-bearing ones on every run. If this file and the code
disagree, the suite fails — a stale reference is worse than none.

It exists because a whole working session produced five confident wrong
answers, all from the same mistake: testing with inputs the system never
produces. Not one was a bug in the code.

## Which globals live where

Querying a GM global from the sheet returns `'THREW: X is not defined'`. Take
`.length` of that and you get a plausible number — 35, 31 — which reads as a
real count. That cost two turns chasing bugs that did not exist.

**GM only** — `BATTLE_SCENES`, `DEFAULT_BESTIARY`, `RANDOM_POOLS`,
`combatants`, `resolveLootLine`, `rollDiceFormula`, `gmClock`, `GM_WATCHES`

**Sheet only** — `char`, `getAllCompData`, `pcLootFindComp`,
`LAN_EXETER_SHOPS`, `SHOP_MIN_TIER`, `FORAGE_PLACES`, `CITY_SIZES`,
`RARITY_COLORS`, `SUBSTANCE_COLORS`, `_lanStock`, `_shopTier`,
`_forageRollQty`, `pcClock`, `PC_WATCHES`

**Both** — `WB` and everything hanging off it

**Neither** (function-local, not reachable from a test) — `TEXMAP`

`rollDiceFormula` being GM-only is what silently broke forage quantities: the
sheet called it behind a `typeof` guard, so every yield fell back to 1 and
every stated `2d6` was discarded. The sheet's own roller is `_forageRollQty`.

## Side values

The board produces exactly three. Anything else falls through to the default.

| side | colour | shape | dashed |
|---|---|---|---|
| `enemy` | `#E05545` | 14% | no |
| `neutral` | `#D9A53A` | 50% | yes |
| `npc` | `#D9A53A` | 50% | yes |

`'pc'`, `'foe'`, `'ally'`, `'monster'` are **not** side values. Testing with
them made every token look identical and led me to add a ring that already
existed. Party tokens use `'party'`, which `WB.sideColor` handles, but no
scene produces one — they arrive from the roster, not from scene data.

Because `neutral` and `npc` ring the same, map icons are separated by
**purpose** instead: gold shops, green forage, blue games, amber inns.

## Which render path a kind takes

`WB.stampHTML` has five outcomes. There are **two definitions** of it in each
file and the second overrides the first — any change belongs in the live one.

| path | kinds | how to detect |
|---|---|---|
| SVG pattern ref | 52 | `url(#...)` in the HTML |
| CSS class | 114 | `class="wbp-..."`, rule in `#wbPropCSS` |
| inline base64 | 1 | `base64,` in the HTML |
| flat colour | 0 | `background`/`gradient`, no art |

The flat-colour path is now empty. It had 11 kinds in it, all of them textures
imported into `WB.TEX2DATA` but registered in `TEXMAP`, which only indexes
`WB.TEXDATA`. `texSrc()` consults each map against its own store, so the
renderer never found them and the Ash valley, the forests and the reed beds
drew as flat colour while their art sat unreachable in the same file. There are
**two texture maps** and they are not interchangeable.

A texture name is also not always a kind name: `moss` is drawn by the `swamp`
kind. Do not assume they match.

Never test "has art" by looking for `<img>` or by measuring HTML length. Both
were used as proxies, and both broke when prop art moved into a stylesheet
while the behaviour was unchanged. Check all three paths.

## Loaded object shapes

A stamp on the board carries `i, k, x, y, w, h, l, lv, locked, dc`.

**The label field is `l`, not `label`.** Reading the wrong one made every
deliberately one-ended connector look orphaned, so the fog guard silently
paired things it should have left alone.

A token carries `i, n, side, x, y, lv, sz, hp, mhp, dead, fx, loot, lootPool,
img, k` plus, where relevant, `link, riding, ridden, npc/nrole/ninfo/nwhere,
poi/pkind/ptarget/pnote`.

Anything a scene sets that must reach the players has to be added to the
**snapshot whitelist** as well. NPCs, POIs and the roof flag each arrived on
the party's board as anonymous dots until they were whitelisted.

## Scene schema

```
st:  [kind, x, y, w, h, label|null, level]
sp:  [creature, count, x, y, level, 'open'?]      'open' = visible at load
npc: [name, x, y, level, role, info, where]       tappable card, not a combatant
ic:  [name, x, y, level, emoji, kind, target, note]   kind: shop|forage|game|inn
ct:  [x, y, type, difficulty, label, level, stampKind]
hz:  [x, y, w, h, name, effect, level]
tr:  [x, y, radius, name, detect, level]
fg:  [name, x, y, w, h, 'hidden'|'roof'|null, level]
ev:  [x, y, w, h, height, name, level]
bg:  key into WB.CITYMAPS, positioned by bgx/bgy/bgw/bgo
gm:  ['#Heading', 'line', ...]
```

**`fg` is fog-of-war, not area labels.** A fifth element of `'hidden'` or
`'roof'` marks an interior and draws a 96%-opaque diagonal roof. Using it to
name regions roofed 49 areas across 20 scenes.

Separately, `WB.roofHTML` draws that same stripe over **every cell with a
floor on the level above**, automatically, with no relation to fog. That was
99% of `glass_forge` and 100% of `three_cells`. It is `WB.ROOFS_ON`, off by
default. No fog setting affects it — which is why the first fix did nothing.

## Valid targets

A scene icon pointing at a name that does not exist opens an empty card at the
table. Suite 09 checks every one.

- **shop** (16): `wagonwright armorer weaponsmith fletcher apothecary mage
  general stable inn services transit bank healer herbalist blackmarket ferry`
  — note `smith` is **not** one; it is a forage place
- **forage** (10): `forest field cave mountain water swamp burnt smith
  brewery fletcher`
- **game**: `gwent dice memory aard`
- **bg**: keys of `WB.CITYMAPS`
- **marker art**: keys of `WB.POI_ART`

## Writing checks

- Compare explicitly: `S.check(desc, ev('...') === true)`. A bare eval passes
  on any truthy value, and a thrown eval returns a truthy string.
- Wrap anything measured in `S.val()`, which throws rather than letting a
  `'THREW: ...'` string be counted.
- Never use `eb('true')`. Two checks were written that way and both hid real
  work that had not been done.
- Test with values from this file. If a value is not here, check whether the
  system produces it before building a conclusion on it.

## Editing scene data

**Never reorder stamps by parsing the array with bracket counting.** Labels
contain `\u2014`-style escapes and apostrophes (`forge-master\u2019s`), and a
bracket parser that tracks quotes by comparing one character against a
two-character string silently mis-splits entries. One reorder pass dropped
half of `loch_eskalott`'s stamps (46 → 23) and invented 31 phantom ones in
`ruined_keep` (49 → 80), while reporting success. The suite caught it only
because a level-2 grate vanished and left its partner unpaired.

What works:

- **Line surgery.** Most scene files put one stamp per line. Split on `\n`,
  select whole lines with a regex anchored on `\['kind',`, move them, join.
- **Direct string replacement** of one exact, unique stamp, with an assertion
  that it occurs exactly once before and after.
- **Count before and after.** Any edit that is meant to reorder must leave the
  stamp count unchanged. Assert it, every time.

**Stamp order is render order.** A later stamp draws over an earlier one. A
dust or fog-like layer belongs directly after the floor and before anything
standing on it; an aperture (window, door) belongs after the wall it is cut
into. Suite 09 asserts nothing is wholly buried except bare floor under dust.
