#!/usr/bin/env python3
"""Surgical single-occurrence replace with safe write (.tmp then os.replace).
Usage: edit.py <file> <old_path> <new_path>   (old/new read from files to avoid quoting hell)
Never opens the target for writing until the new content is fully built."""
import sys, os

def main():
    path, oldf, newf = sys.argv[1], sys.argv[2], sys.argv[3]
    old = open(oldf, encoding='utf-8').read()
    new = open(newf, encoding='utf-8').read()
    h = open(path, encoding='utf-8').read()

    n = h.count(old)
    if n != 1:
        print('ABORT: old text occurs %d times in %s (need exactly 1)' % (n, path))
        sys.exit(2)
    if not old.strip():
        print('ABORT: empty old text'); sys.exit(2)

    out = h.replace(old, new)
    if out == h:
        print('ABORT: replace was a no-op'); sys.exit(2)

    tmp = path + '.tmp'
    with open(tmp, 'w', encoding='utf-8') as f:
        f.write(out)
    # only swap in once the write above completed without raising
    os.replace(tmp, path)
    print('OK %s: %d -> %d bytes (%+d)' % (path, len(h), len(out), len(out) - len(h)))

if __name__ == '__main__':
    main()
