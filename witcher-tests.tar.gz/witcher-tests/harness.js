const {JSDOM}=require('jsdom'); const fs=require('fs');
function stubCtx(){const n=()=>{};return new Proxy({measureText:()=>({width:10}),
  createLinearGradient:()=>({addColorStop:n}),createRadialGradient:()=>({addColorStop:n}),
  createPattern:()=>null,getImageData:()=>({data:new Uint8ClampedArray(4)}),
  canvas:{width:300,height:150}},{get:(t,k)=>k in t?t[k]:n});}
function boot(file,opts){
  opts=opts||{}; const errs=[];
  const dom=new JSDOM(fs.readFileSync(file,'utf8'),{runScripts:'dangerously',
    pretendToBeVisual:true,url:'https://local/',
    beforeParse(w){
      w.matchMedia=q=>({matches:false,media:q,addListener(){},removeListener(){},
        addEventListener(){},removeEventListener(){},onchange:null,dispatchEvent(){}});
      w.HTMLCanvasElement.prototype.getContext=()=>stubCtx();
      w.HTMLCanvasElement.prototype.toDataURL=()=>'data:image/png;base64,';
      w.scrollTo=()=>{}; w.alert=()=>{}; w.confirm=()=>true; w.prompt=()=>null;
      w.onerror=m=>errs.push('onerror: '+m);
      w.addEventListener('unhandledrejection',e=>errs.push('rejection: '+e.reason));
      const ce=w.console.error; w.console.error=(...a)=>errs.push('console.error: '+String(a[0]).slice(0,180));
      if(opts.beforeParse) opts.beforeParse(w);
    }});
  dom.virtualConsole&&dom.virtualConsole.on('jsdomError',e=>errs.push('jsdomError: '+(e.message||e)));
  return {dom,window:dom.window,errs};
}
function Suite(name){
  const R={name,pass:0,fail:0,fails:[]};
  /* A thrown eval must never pass. Every suite wraps window.eval in a helper
     that returns the string 'THREW: ...' on error, and a non-empty string is
     truthy \u2014 so `S.check(desc, ev('...'))` passed silently whenever the code
     under test threw. Several checks were passing without checking anything.
     Any condition that is a THREW string now fails, loudly. */
  R.check=(desc,cond)=>{
    if(typeof cond==='string' && /^THREW/.test(cond)){
      R.fail++; R.fails.push(desc+'  [condition threw: '+cond.slice(0,90)+']');
      return;
    }
    if(typeof cond==='string' && cond!=='' && cond!=='false'){
      /* a bare non-empty string is almost always an accident: the suite meant
         to compare it, not to treat it as a boolean */
      R.fail++; R.fails.push(desc+'  [condition is a string, not a boolean: '+cond.slice(0,60)+']');
      return;
    }
    if(cond){R.pass++;} else {R.fail++;R.fails.push(desc);}
  };
  /* A thrown eval returns 'THREW: ...'. Taking .length of that string gave a
     plausible-looking number \u2014 35, 31 \u2014 which read as a real count and sent me
     chasing bugs that did not exist. Any THREW value fails outright, however
     it arrives. */
  R.eq=(desc,got,want)=>{
    if(typeof got==='string' && /^THREW/.test(got)){
      R.fail++; R.fails.push(desc+'  [expression threw: '+got.slice(0,90)+']');
      return;
    }
    R.check(desc+' (got '+JSON.stringify(got)+', want '+JSON.stringify(want)+')',
      JSON.stringify(got)===JSON.stringify(want));
  };
  /* Use for any value the suite does arithmetic on before comparing. */
  R.val=(v)=>{
    if(typeof v==='string' && /^THREW/.test(v)) throw new Error('suite read a thrown value: '+v);
    return v;
  };
  R.report=()=>{
    console.log(`[${R.fail?'FAIL':'PASS'}] ${R.name}: ${R.pass} passed, ${R.fail} failed`);
    R.fails.slice(0,15).forEach(f=>console.log('    x '+f));
    return R.fail===0;
  };
  return R;
}
// force Math.random to a fixed sequence, restore after
function withRandom(w,seq,fn){ const o=w.Math.random; let i=0;
  w.Math.random=()=>{const v=seq[i%seq.length];i++;return v;};
  try{ return fn(); } finally { w.Math.random=o; } }
module.exports={boot,Suite,withRandom};
