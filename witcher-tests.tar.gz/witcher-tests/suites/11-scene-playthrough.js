/* Suite 11 — Scene playthrough.
   Loads every battle scene the way the GM does and checks it is playable:
   creatures land on open ground, nothing sits inside a wall or off the grid,
   every level can be reached, and movement actually works from the middle of
   the board. Static checks on the scene data missed all of this. */
const {boot,Suite}=require('../harness.js');
const S=Suite('11 scene-playthrough');
const {dom,errs}=boot('/home/claude/W/gm.html');

setTimeout(()=>{
  const ev=x=>{try{return dom.window.eval(x);}catch(e){return {err:String(e.message)};}};
  S.check('gm boots clean',errs.length===0);

  ev(`(function(){
    window.gmBattleToast=function(){}; window.gmBattleTouch=function(){};
    window.gmBattleUndoPush=function(){}; window.gmBroadcastRoster=function(){};
    window.gmSyncSend=function(){}; window.logRoll=function(){};
    window.renderCombatants=function(){};
    window._gmBUi=window._gmBUi||{}; window._gmBView=null;
    window._gmB=window._gmB||{toks:[],stamps:[],levels:[{n:'G'}],lvl:0,w:20,h:20};
    return true;})()`);

  const ids=JSON.parse(ev('JSON.stringify(BATTLE_SCENES.map(function(s){return s.id;}))'));
  S.check('there are scenes to test ('+ids.length+')',ids.length>=15);

  ids.forEach(id=>{
    const r=ev(`(function(){
      combatants.length=0;
      try{ gmBattleLoadScene(${JSON.stringify(id)}, false); }catch(e){ return {err:String(e.message)}; }
      var B=window._gmB, inWall=0, off=0, badLvl=0;
      B.toks.forEach(function(t){
        if(t.x<0||t.y<0||t.x>=B.w||t.y>=B.h) off++;
        if((t.lv||0)<0||(t.lv||0)>=B.levels.length) badLvl++;
        B.stamps.forEach(function(s){
          if(!/^(wall|stonewall|timberwall)$/.test(s.k)) return;
          if((s.lv||0)!==(t.lv||0)) return;
          if(t.x>=s.x&&t.x<s.x+s.w&&t.y>=s.y&&t.y<s.y+s.h) inWall++; });
      });
      var reach=0;
      try{ var rr=WB.reachable({stamps:B.stamps,elev:B.elev,w:B.w,h:B.h,lvl:0},
             Math.floor(B.w/2),Math.floor(B.h/2),10,null);
           reach=rr?Object.keys(rr).length:0; }catch(e){ reach=-1; }
      return {stamps:B.stamps.length, creat:B.toks.filter(function(t){return t.link!=null;}).length,
              piles:B.toks.filter(function(t){return t.loot;}).length,
              inWall:inWall, off:off, badLvl:badLvl, reach:reach,
              levels:B.levels.length, name:B.name};
    })()`);
    if(r.err){ S.check('"'+id+'" loads without throwing ('+r.err+')',false); return; }
    S.check('"'+id+'" loads',!!r.name);
    S.eq('"'+id+'": no creature stands inside a wall',r.inWall,0);
    S.eq('"'+id+'": no token is off the grid',r.off,0);
    S.eq('"'+id+'": no token is on a level that does not exist',r.badLvl,0);
    S.check('"'+id+'": something can move on it ('+r.reach+' cells)',r.reach>0);
    S.check('"'+id+'": its stamps survived the load ('+r.stamps+')',r.stamps>0);
  });

  /* the four rebuilt for the Courier's Burden opening carry a live encounter */
  ['rd_ambush','luton_quay','gullet_siren','glass_forge'].forEach(id=>{
    const r=ev(`(function(){
      combatants.length=0; gmBattleLoadScene(${JSON.stringify(id)}, false);
      var B=window._gmB;
      return {creat:B.toks.filter(function(t){return t.link!=null;}).length,
              piles:B.toks.filter(function(t){return t.loot&&t.loot.length;}).length,
              haz:(B.hazards||[]).length, tr:(B.traps||[]).length,
              elev:(B.elev||[]).length, areas:(B.fog||[]).length,
              stages:(B.stages||[]).length, combatants:combatants.length};
    })()`);
    S.check('"'+id+'" arrives with creatures on the board ('+r.creat+')',r.creat>=5);
    S.eq('"'+id+'": every creature has a combatant',r.creat,r.combatants);
    S.check('"'+id+'" has loot piles ('+r.piles+')',r.piles>=3);
    S.check('"'+id+'" has hazards',r.haz>=1);
    S.check('"'+id+'" has traps',r.tr>=1);
    S.check('"'+id+'" has elevation',r.elev>=3);
    S.check('"'+id+'" has named areas',r.areas>=4);
    S.check('"'+id+'" has staged reveals',r.stages>=2);
  });

  /* named characters drop a note, not a pile */
  S.check('a named character spawns no loot pile',
    ev(`(function(){
      var b=DEFAULT_BESTIARY.filter(function(x){return x.name==='Iorveth';})[0];
      if(!b) return true;
      var c=makeMonsterCombatant(b,10); c.dead=true;
      combatants.length=0; combatants.push(c);
      c.rolledLoot=rollMonsterLoot(b.loot,b.name);
      window._gmB={w:20,h:20,lvl:0,lootDone:{},toks:[{i:1,n:'I',x:5,y:5,lv:0,link:c.id,side:'npc'}]};
      gmBattleLootSweep();
      return window._gmB.toks.filter(function(t){return t.loot;}).length===0;})()`)===true);
  S.check('but the pointer still shows on the GM card',
    ev(`(function(){
      var b=DEFAULT_BESTIARY.filter(function(x){return x.name==='Zoltan Chivay';})[0];
      return /sourcebook/i.test((b.loot||[]).join(' '));})()`)===true);
  S.check('archetypes keep their kit',
    ev(`(function(){
      return ['Scout','Smuggler','Courier','Merchant'].every(function(n){
        var b=DEFAULT_BESTIARY.filter(function(x){return x.name===n;})[0];
        return b && (b.loot||[]).length>3 && !/sourcebook/i.test(b.loot.join(' '));});})()`)===true);

  /* ── concealment ──────────────────────────────────────────────────────
     Scene creatures stand where the chapter puts them from the moment the
     board loads, but the party cannot see them: gmBattleSpawnBeast hides
     every spawn, and a hidden token is not sent at all rather than filtered
     client-side. A sixth spawn element of 'open' is the exception, for
     creatures the party is meant to see on arrival. */
  [['creyden_street',2],['rd_ambush',2],['glass_forge',1],
   ['gullet_siren',4],['luton_quay',0]].forEach(function(pair){
    const r=ev(`(function(){
      combatants.length=0; gmBattleLoadScene(${JSON.stringify(pair[0])}, false);
      var B=window._gmB;
      var creat=B.toks.filter(function(t){return t.link!=null;});
      var snap=gmBattleSnapshot();
      var seen=(snap.toks||[]).filter(function(t){return t.link!=null;});
      return {onBoard:creat.length, hidden:creat.filter(function(t){return t.hid;}).length,
              seen:seen.length,
              strandedFlag:creat.filter(function(t){return t._gmHid;}).length};
    })()`);
    S.check('"'+pair[0]+'" places its creatures ('+r.onBoard+')',r.onBoard>0);
    S.eq('  the party sees only what it should',r.seen,pair[1]);
    S.eq('  the rest are concealed',r.hidden,r.onBoard-pair[1]);
    S.eq('  and a hidden one is not sent at all',r.seen,r.onBoard-r.hidden);
    /* _gmHid means the GM hid it by hand; the auto-reveal skips those, so a
       scene must never set it or its ambush can never spring */
    S.eq('  none is stranded by the deliberate-hide flag',r.strandedFlag,0);
  });
  S.check('revealing a concealed creature sends it to the players',
    ev(`(function(){
      combatants.length=0; gmBattleLoadScene('creyden_street', false);
      var b=window._gmB.toks.filter(function(t){return t.hid && t.link!=null;})[0];
      if(!b) return false;
      var before=gmBattleSnapshot().toks.filter(function(t){return t.link!=null;}).length;
      gmBattleToggleHide(b.i, true);
      var after=gmBattleSnapshot().toks.filter(function(t){return t.link!=null;}).length;
      return after===before+1;})()`)===true);
  S.check('the GM can count what is still concealed',
    ev(`(function(){ combatants.length=0; gmBattleLoadScene('glass_forge', false);
      return typeof gmBattleHiddenCount==='function' && gmBattleHiddenCount()>0;})()`)===true);

  /* ── named townsfolk ──────────────────────────────────────────────────
     The map doubles as an exploration tool between fights: the party walks
     the town and taps whoever is standing there. The card carries only what
     is visible across a room; the GM does the talking. */
  [['luton_quay',6],['creyden_street',6],['gullet_siren',1]].forEach(function(pair){
    const r=ev(`(function(){
      combatants.length=0; gmBattleLoadScene(${JSON.stringify(pair[0])}, false);
      var B=window._gmB, n=B.toks.filter(function(t){return t.npc;});
      var inWall=0;
      n.forEach(function(t){ B.stamps.forEach(function(s){
        if(!/^(wall|stonewall|timberwall)$/.test(s.k)) return;
        if((s.lv||0)!==(t.lv||0)) return;
        if(t.x>=s.x&&t.x<s.x+s.w&&t.y>=s.y&&t.y<s.y+s.h) inWall++; }); });
      var snap=gmBattleSnapshot();
      var sent=(snap.toks||[]).filter(function(t){return t.npc;});
      return {placed:n.length, inWall:inWall,
        named:n.every(function(t){return !!t.n && !!t.nrole && !!t.ninfo;}),
        harmless:n.every(function(t){return t.hp===0 && t.mhp===0 && !t.link;}),
        inGrid:n.every(function(t){return t.x>=0&&t.y>=0&&t.x<B.w&&t.y<B.h;}),
        sent:sent.length,
        sentInfo:sent.every(function(t){return !!t.nrole && !!t.ninfo;}),
        combatants:combatants.filter(function(c){
          return n.some(function(t){return t.n===c.name;});}).length};
    })()`);
    S.eq('"'+pair[0]+'" places its townsfolk',r.placed,pair[1]);
    S.check('  each has a name, a role and something to see',r.named);
    S.eq('  none is standing in a wall',r.inWall,0);
    S.check('  all inside the map',r.inGrid);
    S.check('  they are not combatants',r.harmless);
    S.eq('  and never enter initiative',r.combatants,0);
    S.eq('  every one reaches the players',r.sent,pair[1]);
    S.check('  carrying their details, not just a dot',r.sentInfo);
  });

  /* difficult ground must not leak between floors — cellar mud used to slow
     anyone walking the storey above it */
  const mud='[{k:"mud",x:5,y:5,w:4,h:4,lv:0},{k:"flagstone",x:5,y:5,w:4,h:4,lv:1}]';
  S.eq('mud below does not slow the floor above',ev('WB.costAt('+mud+',5,5,1)'),1);
  S.eq('but it still slows you when you are in it',ev('WB.costAt('+mud+',5,5,0)'),2);
  S.check('a caller that omits the level keeps the old behaviour',
    ev('WB.costAt('+mud+',5,5)')===2);
  S.check('range is larger on the clear floor than wading',
    ev(`(function(){var st=${mud};
      var a=WB.reachable({stamps:st,elev:[],w:20,h:20,lvl:1},5,5,20,null);
      var b=WB.reachable({stamps:st,elev:[],w:20,h:20,lvl:0},5,5,20,null);
      return Object.keys(a).length>Object.keys(b).length;})()`));

  process.exit(S.report()?0:1);
},6000);
