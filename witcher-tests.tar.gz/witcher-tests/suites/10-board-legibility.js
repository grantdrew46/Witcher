/* Suite 10 — Board legibility.
   Token names were losing the square to prop labels and SP captions, tokens
   stacked on one another vanished with no sign they were there, and there
   was no way to identify a token whose name chip was clipped. */
const {boot,Suite}=require('../harness.js');
const S=Suite('10 board-legibility');
const A=boot('/home/claude/W/gm.html');
const B=boot('/home/claude/W/sheet.html');

setTimeout(()=>{
  const ea=s=>A.dom.window.eval(s), eb=s=>B.dom.window.eval(s);
  S.check('gm boots clean',A.errs.length===0);
  S.check('sheet boots clean',B.errs.length===0);

  /* 1. stack counting */
  const T=JSON.stringify([
    {i:1,n:'Merrick',x:3,y:3,lv:0,sz:1},{i:2,n:'Hector',x:3,y:3,lv:0,sz:1},
    {i:3,n:'Dasik',  x:3,y:3,lv:0,sz:1},{i:4,n:'Alone', x:9,y:9,lv:0,sz:1},
    {i:5,n:'Upstairs',x:3,y:3,lv:1,sz:1},{i:6,n:'Corpse',x:9,y:9,lv:0,sz:1,dead:true},
    {i:7,n:'Pile',   x:9,y:9,lv:0,sz:1,loot:['x']},
    {i:8,n:'Steed',  x:9,y:9,lv:0,sz:1,ridden:true}
  ]);
  const st=k=>ea('JSON.parse(JSON.stringify(WB.stackCounts('+T+')))')[k];
  S.eq('three in one square marks the top one +2',st('3'),2);
  S.check('the ones underneath carry no badge',st('1')===undefined&&st('2')===undefined);
  /* the render sorts dead and loot first so the living paint over them, so
     after sorting it is the living token that carries the badge */
  const sorted=ea('JSON.parse(JSON.stringify(WB.stackCounts(WB.sortToks('+T+'))))');
  S.eq('a body lying under a living token is counted',sorted['4'],1);
  S.check('and the corpse itself carries no badge',sorted['6']===undefined);
  S.check('a token one floor up does not join the stack',st('5')===undefined);
  S.check('loot piles are not counted as bodies',
    JSON.stringify(ea('WB.stackCounts('+T+')')).indexOf('"7"')<0);
  S.check('a ridden mount is not counted (it is under its rider)',
    JSON.stringify(ea('WB.stackCounts('+T+')')).indexOf('"8"')<0);
  S.eq('stackCounts agrees across both files',
    ea('JSON.stringify(WB.stackCounts('+T+'))'),eb('JSON.stringify(WB.stackCounts('+T+'))'));
  S.eq('an empty board is safe',ea('JSON.stringify(WB.stackCounts([]))'),'{}');
  S.eq('a null list is safe',ea('JSON.stringify(WB.stackCounts(null))'),'{}');

  /* 2. the name must outrank every label on the board */
  const html=ea('WB.tokenHTML({i:3,n:"Dasik",x:3,y:3,lv:0,sz:1},{gm:true,stack:2})');
  S.check('the name sits at z-index 60',/z-index:60/.test(html));
  S.check('the stack badge sits above the name',/z-index:61/.test(html));
  S.check('the badge reads +2',/\+2</.test(html));
  S.check('no badge is drawn when nothing is underneath',
    !/\+\d</.test(ea('WB.tokenHTML({i:4,n:"Alone",x:9,y:9,lv:0,sz:1},{gm:true,stack:0})')));
  S.check('prop labels stay well below the name',
    /z-index:2/.test(ea('WB.labelChip("SP 5")')));

  /* 3. hovering names the token */
  S.check('the token carries its name as a hover title',/title="Dasik/.test(html));
  S.check('hover mentions what is underneath',/more underneath/.test(html));
  S.check('hover names the mount when riding',
    /mounted on Roach/.test(ea('WB.tokenHTML({i:9,n:"M",x:1,y:1,lv:0,sz:1,riding:"Roach"},{gm:true})')));
  S.check('a plain token still gets a title',
    /title="Alone"/.test(ea('WB.tokenHTML({i:4,n:"Alone",x:9,y:9,lv:0,sz:1},{gm:true})')));

  /* 4. occupancy, and every label path honouring it.
     There are two stampHTML implementations — the second overrides the first —
     with five separate label paths between them. Three were missed on the
     first pass, so every kind shape is checked here. */
  const kinds=['table','wall','water','crate','door','tree','rug','flagstone'];
  [ea,eb].forEach((f,n)=>{
    const who=n?'sheet':'gm';
    f('WB.setOccupied([{i:1,n:"A",x:3,y:3,lv:0,sz:1}],0)');
    S.check(who+': the occupied square is marked',f('!!WB.OCCUPIED["3:3"]'));
    S.check(who+': a free square is not',!f('!!WB.OCCUPIED["6:6"]'));
    kinds.forEach(k=>{
      const on =f('WB.stampHTML({k:"'+k+'",x:3,y:3,w:1,h:1,l:"SP 5"},true)');
      const off=f('WB.stampHTML({k:"'+k+'",x:6,y:6,w:1,h:1,l:"SP 5"},true)');
      S.check(who+': "'+k+'" label hidden under a body',String(on).indexOf('SP 5')<0);
      S.check(who+': "'+k+'" label shown on a free square',String(off).indexOf('SP 5')>=0);
    });
  });

  /* a large creature covers its whole footprint */
  ea('WB.setOccupied([{i:1,n:"Troll",x:4,y:4,lv:0,sz:2}],0)');
  ['4:4','5:4','4:5','5:5'].forEach(c=>
    S.check('a 2x2 body occupies '+c,ea('!!WB.OCCUPIED["'+c+'"]')));
  S.check('and no further',!ea('!!WB.OCCUPIED["6:6"]'));
  ea('WB.setOccupied([{i:1,n:"A",x:3,y:3,lv:1,sz:1}],0);');
  S.check('a body on another floor does not occupy this one',!ea('!!WB.OCCUPIED["3:3"]'));
  S.check('a wide prop is busy if any of its cells is',
    ea('(function(){WB.setOccupied([{i:1,x:5,y:5,lv:0,sz:1}],0);'
      +'return WB.stampBusy({x:3,y:5,w:4,h:1});})()'));
  S.check('stampBusy is safe on nothing',!ea('WB.stampBusy(null)'));

  /* ── cover and firing lanes ──────────────────────────────────────────
     Every building in the scene library is drawn with stonewall/timberwall,
     and neither was in WB.COVER — so 92 wall segments across 14 scenes
     stopped nothing. And a window sits on the wall cell it is cut into, so
     taking the highest SP meant the wall always won and the window did
     nothing at all. */
  const shot=(stamps,a,b,f)=>(f||ea)('(function(){var r=WB.coverOnLine('+JSON.stringify(stamps)
    +','+JSON.stringify(a)+','+JSON.stringify(b)+',0);return r?{n:r.n,sp:r.sp}:null;})()');
  const across={gx:1,gy:5.5}, far={gx:9,gy:5.5};
  [['stonewall',30],['timberwall',15],['wall',30],['pillar',30]].forEach(([k,sp])=>{
    const r=shot([{k:k,x:5,y:0,w:1,h:10,lv:0}],across,far);
    S.check('"'+k+'" stops a shot ('+(r?r.sp:'none')+')',!!r&&r.sp===sp);
  });
  const win=[{k:'timberwall',x:5,y:0,w:1,h:10,lv:0},{k:'window',x:5,y:5,w:1,h:1,lv:0}];
  S.eq('a shot through the window meets only the frame',(shot(win,across,far)||{}).sp,2);
  S.check('the same wall away from the window still stops it',
    (shot(win,{gx:1,gy:2.5},{gx:9,gy:2.5})||{}).sp===15);
  S.check('a window is flagged as an opening',ea('!!WB.COVER.window.opening'));
  S.check('an arrowslit is not treated as a lane',!ea('!!WB.COVER.arrowslit.opening'));
  S.check('cover on another floor is ignored',
    shot([{k:'stonewall',x:5,y:0,w:1,h:10,lv:1}],across,far)===null);
  S.check('open ground is clear',shot([],across,far)===null);
  S.check('the cover table matches in both files',
    ea('Object.keys(WB.COVER).length')===eb('Object.keys(WB.COVER).length'));

  /* Every enclosed scene needs somewhere to shoot through. A firing lane is
     any opening a shot can cross — window, arrowslit, archway, portcullis —
     not just a window: a sea-rock lookout is pierced with arrowslits, which
     is the same thing, and an open road has no building to put a window in. */
  const scenes=ea(`(function(){ return BATTLE_SCENES.map(function(s){
      var lanes=0,solid=0;
      (s.st||[]).forEach(function(e){
        if(/^(window|arrowslit|archway|portcullis|doorframe)$/.test(e[0])) lanes++;
        if(/^(wall|stonewall|timberwall)$/.test(e[0])) solid++; });
      return {id:s.id, lv:(s.lv?s.lv.length:1), lanes:lanes, solid:solid};
    }); })()`);
  scenes.filter(x=>x.solid>=6).forEach(x=>
    S.check('enclosed scene "'+x.id+'" has a firing lane ('+x.lanes+' lanes / '+x.solid+' walls)',
      x.lanes>0));
  S.check('no scene is walled with no way to shoot through',
    scenes.filter(x=>x.solid>=10&&x.lanes===0).length===0);
  S.check('every scene wall kind is in the cover table',
    ea(`(function(){ var miss=[];
      BATTLE_SCENES.forEach(function(s){ (s.st||[]).forEach(function(e){
        if(/wall|pillar|portcullis/.test(e[0]) && !WB.COVER[e[0]]) miss.push(e[0]); }); });
      return miss.length===0; })()`));

  /* ── board legibility, second pass ───────────────────────────────────────
     Everything below came from looking at what the board actually draws
     rather than at the data behind it. */
  const L2=boot('/home/claude/W/gm.html');
  setTimeout(function(){
    const e2=function(x){ try{ return L2.dom.window.eval(x); }catch(e){ return 'THREW: '+e.message; } };
    const mk=function(extra){
      return '(function(){return WB.tokenHTML(Object.assign({i:"t",n:"Merrick",e:"\\u2694",x:1,y:1,sz:1,'
        + 'hp:20,mhp:20,fx:[],dead:false},'+extra+'),{gm:true});})()';
    };
    const ring=function(extra){
      const h=String(e2(mk(extra)));
      const m=h.match(/inset 0 0 0 \d+px ([^;]*)/);
      return m ? m[1] : 'none';
    };
    e2('window.gmBattleToast=function(){};window.gmBattleTouch=function(){};window.gmBattleUndoPush=function(){};window.gmBroadcastRoster=function(){};window.gmSyncSend=function(){};window.logRoll=function(){};window.renderCombatants=function(){};window.gmBroadcastInitiative=function(){};window._gmBUi={};window._gmBView=null;window._gmB={toks:[],stamps:[],levels:[{n:"G"}],lvl:0,w:20,h:20};');

    /* side rings already existed; testing with 'pc'/'foe' made them look absent */
    S.eq('enemy rings red',e2('WB.sideColor("enemy")'),'#E05545');
    S.eq('neutral rings gold',e2('WB.sideColor("neutral")'),'#D9A53A');
    S.check('"pc" and "foe" are not real side values',
      e2(`WB.sideColor('pc')===WB.sideColor('nonsense')
          && WB.sideColor('foe')===WB.sideColor('nonsense')`)===true);

    /* map icons are all neutral, so they separate by purpose */
    const kinds=['shop','forage','game','inn'].map(function(k){
      return ring('{poi:true,pkind:"'+k+'",side:"neutral"}'); });
    S.check('every map-icon kind has its own ring',
      kinds.every(function(c){return c!=='none';}) && new Set(kinds).size===kinds.length);
    S.check('an ordinary token has no purpose ring',ring('{side:"neutral"}')==='none');

    /* painted markers instead of phone glyphs */
    S.check('marker art is loaded',e2('Object.keys(WB.POI_ART||{}).length')>=22);
    S.check('every marker is a real image',
      e2(`Object.keys(WB.POI_ART||{}).every(function(k){
        return /^data:image\\/(webp|png);base64,/.test(WB.POI_ART[k]); })`)===true);
    /* Every icon type in the campaign now has painted art. The emoji path
       remains as a fallback for anything added later. */
    S.eq('no icon anywhere falls back to an emoji',
      e2(`(function(){
        var m={};
        BATTLE_SCENES.forEach(function(s){
          (s.ic||[]).forEach(function(e){
            if(!WB.poiArtFor({ptarget:e[6],pkind:e[5]})) m[e[6]||e[5]]=1; }); });
        return Object.keys(m);})()`).length,0);
    S.check('but the emoji fallback still works for a new icon type',
      e2(`(function(){
        var h=WB.tokenHTML({i:'t',n:'X',e:'\\u2694',x:1,y:1,sz:1,hp:0,mhp:0,fx:[],
          dead:false,poi:true,pkind:'shop',ptarget:'somethingnew'},{gm:true});
        return !/<img/.test(h);})()`)===true);
    S.check('an alias only stands in for something it honestly resembles',
      e2(`(function(){
        /* reedy shallow water on a stony bank is what a marsh looks like */
        return WB.POI_ART_ALIAS.swamp==='water'
            && Object.keys(WB.POI_ART_ALIAS).length<=2;})()`)===true);
    /* WB.monArt matches loosely on the token name and ran before the marker
       and initials branches, so a shop called "The Weaponsmith" and an NPC
       called "Keira Metz" drew as whatever creature their name resembled.
       Sixteen collisions across the scenes. This assertion caught it only
       because mk() names its token "Merrick", which also matched. */
    S.check('a shop with a marker renders it',
      /<img/.test(String(e2(mk('{poi:true,pkind:"shop",ptarget:"weaponsmith"}')))));
    S.eq('no icon or named NPC is hijacked by creature name-matching',
      e2(`(function(){
        var bad=[];
        BATTLE_SCENES.forEach(function(sc){
          combatants.length=0; gmBattleLoadScene(sc.id,false);
          window._gmB.toks.forEach(function(t){
            if(!t.poi && !t.npc) return;
            var h=WB.tokenHTML(t,{gm:true});
            /* a marker, an emoji or initials \u2014 never a creature portrait */
            if(t.poi && WB.POI_ART[t.ptarget||t.pkind] && !/object-fit:contain/.test(h))
              bad.push(sc.id+':'+t.n);
            if(t.npc && t.ini && h.indexOf(t.ini)<0) bad.push(sc.id+':'+t.n);
          });
        });
        return bad;})()`).length,0);
    S.check('while a real creature still gets its portrait',
      e2(`(function(){
        var h=WB.tokenHTML({i:'t',n:'Drowner',x:1,y:1,sz:1,hp:20,mhp:20,fx:[],
          dead:false,side:'enemy',link:3},{gm:true});
        return /base64|wbp-/.test(h);})()`)===true);
    S.check('contained, not cover-cropped',
      /object-fit:contain/.test(String(e2(mk('{poi:true,pkind:"shop",ptarget:"weaponsmith"}')))));
    S.check('a shop without one falls back to its emoji',
      !/<img/.test(String(e2(mk('{poi:true,pkind:"shop",ptarget:"nosuchshop"}')))));

    /* mounted \u2014 asked for repeatedly and never made obvious */
    const mounted=String(e2(mk('{riding:"Bay gelding",sz:2,side:"party"}')));
    const afoot=String(e2(mk('{side:"party"}')));
    S.check('a mounted token carries a standing badge',/MOUNTED/.test(mounted));
    S.check('and a horse glyph on the name',/\uD83D\uDC0E/.test(mounted));
    S.check('and a ring of its own',/inset 0 0 0 3px rgba\(226,168,74/.test(mounted));
    S.check('and names the mount on hover',/mounted on Bay gelding/.test(mounted));
    S.check('a token on foot shows none of it',
      !/MOUNTED/.test(afoot) && !/rgba\(226,168,74/.test(afoot));
    S.check('the GM initiative list calls it out too',
      e2('typeof _gmMountedBanner')==='function');
    S.check('naming the mount and what it changes',
      e2(`(function(){
        window._gmB={toks:[{i:'a',link:7,riding:'Bay gelding'}],stamps:[],
          levels:[{n:'G'}],lvl:0,w:20,h:20};
        var b=_gmMountedBanner({id:7});
        return /MOUNTED/.test(b) && /Bay gelding/.test(b)
          && /SPD/.test(b) && /charge/.test(b);})()`)===true);
    S.check('and nothing for a combatant on foot',
      e2(`(function(){
        window._gmB={toks:[{i:'b',link:8}],stamps:[],levels:[{n:'G'}],lvl:0,w:20,h:20};
        return _gmMountedBanner({id:8})==='';})()`)===true);

    /* named NPCs were all the same crossed-swords emoji */
    S.eq('every named NPC gets initials',
      e2(`(function(){
        var bad=[];
        BATTLE_SCENES.forEach(function(sc){
          if(!sc.npc) return;
          combatants.length=0;
          gmBattleLoadScene(sc.id,false);
          window._gmB.toks.filter(function(t){return t.npc;}).forEach(function(t){
            if(!t.ini) bad.push(sc.id+':'+t.n); });
        });
        return bad;})()`).length,0);
    S.check('one or two upper-case letters',
      e2(`(function(){
        combatants.length=0; gmBattleLoadScene('abbey_script',false);
        return window._gmB.toks.filter(function(t){return t.npc;})
          .every(function(t){ return /^[A-Z]{1,2}$/.test(t.ini); });})()`)===true);
    S.check('titles stripped so six brothers are not all BR',
      e2(`(function(){
        combatants.length=0; gmBattleLoadScene('abbey_script',false);
        var i=window._gmB.toks.filter(function(t){return t.npc;}).map(function(t){return t.ini;});
        return new Set(i).size===i.length;})()`)===true);
    S.check('and they reach the players',
      e2(`(function(){
        combatants.length=0; gmBattleLoadScene('abbey_script',false);
        var n=(gmBattleSnapshot().toks||[]).filter(function(t){return t.npc;});
        return n.length>0 && n.every(function(t){return !!t.ini;});})()`)===true);

    /* prop art was inlined per instance */
    S.check('no kind inlines its art',
      e2(`(function(){
        var bad=[];
        WB.KINDS.forEach(function(kd){
          var h=WB.stampHTML({k:kd.k,x:1,y:1,w:2,h:2},true);
          if(!/url\\(#/.test(h)&&!/class="wbp-/.test(h)&&/base64,/.test(h)) bad.push(kd.k); });
        return bad.length===0;})()`)===true);
    S.check('a non-tiling kind still stretches to its footprint',
      e2(`(function(){
        var h=WB.stampHTML({k:'rug',x:1,y:1,w:3,h:2},true);
        var m=h.match(/class="(wbp-nt[^"]*)"/);
        var sh=document.getElementById('wbPropCSS');
        return !!(m && sh && sh.textContent.indexOf('.'+m[1]+'{')>=0);})()`)===true);

    process.exit(S.report()?0:1);
  },5400);
},6000);
