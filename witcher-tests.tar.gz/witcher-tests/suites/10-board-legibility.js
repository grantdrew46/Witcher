/* Suite 10 — Board legibility.
   Token names were losing the square to prop labels and SP captions, tokens
   stacked on one another vanished with no sign they were there, and there
   was no way to identify a token whose name chip was clipped. */
const {boot,Suite}=require('../harness.js');
const S=Suite('10 board-legibility');
const A=boot('/home/claude/W/gm.html');
const B=boot('/home/claude/W/sheet.html');

setTimeout(()=>{
  const ea=s=>A.dom.window.eval(s), eb=s=>B.dom.window.eval(s);
  S.check('gm boots clean',A.errs.length===0);
  S.check('sheet boots clean',B.errs.length===0);

  /* 1. stack counting */
  const T=JSON.stringify([
    {i:1,n:'Merrick',x:3,y:3,lv:0,sz:1},{i:2,n:'Hector',x:3,y:3,lv:0,sz:1},
    {i:3,n:'Dasik',  x:3,y:3,lv:0,sz:1},{i:4,n:'Alone', x:9,y:9,lv:0,sz:1},
    {i:5,n:'Upstairs',x:3,y:3,lv:1,sz:1},{i:6,n:'Corpse',x:9,y:9,lv:0,sz:1,dead:true},
    {i:7,n:'Pile',   x:9,y:9,lv:0,sz:1,loot:['x']},
    {i:8,n:'Steed',  x:9,y:9,lv:0,sz:1,ridden:true}
  ]);
  const st=k=>ea('JSON.parse(JSON.stringify(WB.stackCounts('+T+')))')[k];
  S.eq('three in one square marks the top one +2',st('3'),2);
  S.check('the ones underneath carry no badge',st('1')===undefined&&st('2')===undefined);
  /* the render sorts dead and loot first so the living paint over them, so
     after sorting it is the living token that carries the badge */
  const sorted=ea('JSON.parse(JSON.stringify(WB.stackCounts(WB.sortToks('+T+'))))');
  S.eq('a body lying under a living token is counted',sorted['4'],1);
  S.check('and the corpse itself carries no badge',sorted['6']===undefined);
  S.check('a token one floor up does not join the stack',st('5')===undefined);
  S.check('loot piles are not counted as bodies',
    JSON.stringify(ea('WB.stackCounts('+T+')')).indexOf('"7"')<0);
  S.check('a ridden mount is not counted (it is under its rider)',
    JSON.stringify(ea('WB.stackCounts('+T+')')).indexOf('"8"')<0);
  S.eq('stackCounts agrees across both files',
    ea('JSON.stringify(WB.stackCounts('+T+'))'),eb('JSON.stringify(WB.stackCounts('+T+'))'));
  S.eq('an empty board is safe',ea('JSON.stringify(WB.stackCounts([]))'),'{}');
  S.eq('a null list is safe',ea('JSON.stringify(WB.stackCounts(null))'),'{}');

  /* 2. the name must outrank every label on the board */
  const html=ea('WB.tokenHTML({i:3,n:"Dasik",x:3,y:3,lv:0,sz:1},{gm:true,stack:2})');
  S.check('the name sits at z-index 60',/z-index:60/.test(html));
  S.check('the stack badge sits above the name',/z-index:61/.test(html));
  S.check('the badge reads +2',/\+2</.test(html));
  S.check('no badge is drawn when nothing is underneath',
    !/\+\d</.test(ea('WB.tokenHTML({i:4,n:"Alone",x:9,y:9,lv:0,sz:1},{gm:true,stack:0})')));
  S.check('prop labels stay well below the name',
    /z-index:2/.test(ea('WB.labelChip("SP 5")')));

  /* 3. hovering names the token */
  S.check('the token carries its name as a hover title',/title="Dasik/.test(html));
  S.check('hover mentions what is underneath',/more underneath/.test(html));
  S.check('hover names the mount when riding',
    /mounted on Roach/.test(ea('WB.tokenHTML({i:9,n:"M",x:1,y:1,lv:0,sz:1,riding:"Roach"},{gm:true})')));
  S.check('a plain token still gets a title',
    /title="Alone"/.test(ea('WB.tokenHTML({i:4,n:"Alone",x:9,y:9,lv:0,sz:1},{gm:true})')));

  /* 4. occupancy, and every label path honouring it.
     There are two stampHTML implementations — the second overrides the first —
     with five separate label paths between them. Three were missed on the
     first pass, so every kind shape is checked here. */
  const kinds=['table','wall','water','crate','door','tree','rug','flagstone'];
  [ea,eb].forEach((f,n)=>{
    const who=n?'sheet':'gm';
    f('WB.setOccupied([{i:1,n:"A",x:3,y:3,lv:0,sz:1}],0)');
    S.check(who+': the occupied square is marked',f('!!WB.OCCUPIED["3:3"]'));
    S.check(who+': a free square is not',!f('!!WB.OCCUPIED["6:6"]'));
    kinds.forEach(k=>{
      const on =f('WB.stampHTML({k:"'+k+'",x:3,y:3,w:1,h:1,l:"SP 5"},true)');
      const off=f('WB.stampHTML({k:"'+k+'",x:6,y:6,w:1,h:1,l:"SP 5"},true)');
      S.check(who+': "'+k+'" label hidden under a body',String(on).indexOf('SP 5')<0);
      S.check(who+': "'+k+'" label shown on a free square',String(off).indexOf('SP 5')>=0);
    });
  });

  /* a large creature covers its whole footprint */
  ea('WB.setOccupied([{i:1,n:"Troll",x:4,y:4,lv:0,sz:2}],0)');
  ['4:4','5:4','4:5','5:5'].forEach(c=>
    S.check('a 2x2 body occupies '+c,ea('!!WB.OCCUPIED["'+c+'"]')));
  S.check('and no further',!ea('!!WB.OCCUPIED["6:6"]'));
  ea('WB.setOccupied([{i:1,n:"A",x:3,y:3,lv:1,sz:1}],0);');
  S.check('a body on another floor does not occupy this one',!ea('!!WB.OCCUPIED["3:3"]'));
  S.check('a wide prop is busy if any of its cells is',
    ea('(function(){WB.setOccupied([{i:1,x:5,y:5,lv:0,sz:1}],0);'
      +'return WB.stampBusy({x:3,y:5,w:4,h:1});})()'));
  S.check('stampBusy is safe on nothing',!ea('WB.stampBusy(null)'));

  /* ── cover and firing lanes ──────────────────────────────────────────
     Every building in the scene library is drawn with stonewall/timberwall,
     and neither was in WB.COVER — so 92 wall segments across 14 scenes
     stopped nothing. And a window sits on the wall cell it is cut into, so
     taking the highest SP meant the wall always won and the window did
     nothing at all. */
  const shot=(stamps,a,b,f)=>(f||ea)('(function(){var r=WB.coverOnLine('+JSON.stringify(stamps)
    +','+JSON.stringify(a)+','+JSON.stringify(b)+',0);return r?{n:r.n,sp:r.sp}:null;})()');
  const across={gx:1,gy:5.5}, far={gx:9,gy:5.5};
  [['stonewall',30],['timberwall',15],['wall',30],['pillar',30]].forEach(([k,sp])=>{
    const r=shot([{k:k,x:5,y:0,w:1,h:10,lv:0}],across,far);
    S.check('"'+k+'" stops a shot ('+(r?r.sp:'none')+')',!!r&&r.sp===sp);
  });
  const win=[{k:'timberwall',x:5,y:0,w:1,h:10,lv:0},{k:'window',x:5,y:5,w:1,h:1,lv:0}];
  S.eq('a shot through the window meets only the frame',(shot(win,across,far)||{}).sp,2);
  S.check('the same wall away from the window still stops it',
    (shot(win,{gx:1,gy:2.5},{gx:9,gy:2.5})||{}).sp===15);
  S.check('a window is flagged as an opening',ea('!!WB.COVER.window.opening'));
  S.check('an arrowslit is not treated as a lane',!ea('!!WB.COVER.arrowslit.opening'));
  S.check('cover on another floor is ignored',
    shot([{k:'stonewall',x:5,y:0,w:1,h:10,lv:1}],across,far)===null);
  S.check('open ground is clear',shot([],across,far)===null);
  S.check('the cover table matches in both files',
    ea('Object.keys(WB.COVER).length')===eb('Object.keys(WB.COVER).length'));

  /* Every enclosed scene needs somewhere to shoot through. A firing lane is
     any opening a shot can cross — window, arrowslit, archway, portcullis —
     not just a window: a sea-rock lookout is pierced with arrowslits, which
     is the same thing, and an open road has no building to put a window in. */
  const scenes=ea(`(function(){ return BATTLE_SCENES.map(function(s){
      var lanes=0,solid=0;
      (s.st||[]).forEach(function(e){
        if(/^(window|arrowslit|archway|portcullis|doorframe)$/.test(e[0])) lanes++;
        if(/^(wall|stonewall|timberwall)$/.test(e[0])) solid++; });
      return {id:s.id, lv:(s.lv?s.lv.length:1), lanes:lanes, solid:solid};
    }); })()`);
  scenes.filter(x=>x.solid>=6).forEach(x=>
    S.check('enclosed scene "'+x.id+'" has a firing lane ('+x.lanes+' lanes / '+x.solid+' walls)',
      x.lanes>0));
  S.check('no scene is walled with no way to shoot through',
    scenes.filter(x=>x.solid>=10&&x.lanes===0).length===0);
  S.check('every scene wall kind is in the cover table',
    ea(`(function(){ var miss=[];
      BATTLE_SCENES.forEach(function(s){ (s.st||[]).forEach(function(e){
        if(/wall|pillar|portcullis/.test(e[0]) && !WB.COVER[e[0]]) miss.push(e[0]); }); });
      return miss.length===0; })()`));

  process.exit(S.report()?0:1);
},6000);
