/* Suite 04 — Balanced weapon effect (pg.72)
   "When a critical wound is scored with this weapon, roll 2d6+2 for the
    critical. If the attack was aimed, roll 1d6+1 instead of 1d6 to determine
    the severity of the critical."
   Aimed severity triggers greater at 5+, so the +1 pulls a raw 4 into greater.
   Limbs take no roll at all (pg.158), so Balanced cannot affect them. */
const {boot,Suite}=require('../harness.js');
const S=Suite('04 balanced (pg.72)');
const {dom,errs}=boot('/home/claude/W/sheet.html');

setTimeout(()=>{
  const ev=s=>dom.window.eval(s);
  const LEVELS=ev('Object.keys(CRIT_WOUNDS)');
  S.check('boot clean',errs.length===0);

  /* run resolveAimedCritWound with a forced d6 face and a chosen weapon */
  const run=(L,id,face,bal)=>ev('(function(){'
    +'var ow=window._pendingAttackWeapon, orand=Math.random;'
    +'window._pendingAttackWeapon='+(bal?"{effect:'Balanced'}":'null')+';'
    +'Math.random=function(){return '+(((face-1)/6)+0.01)+';};'
    +'try{var r=resolveAimedCritWound('+JSON.stringify(L)+',{id:'+JSON.stringify(id)+',label:"x"});'
    +'return r&&r.wound?{roll:String(r.wound.roll),note:String(r.note||"")}:null;}'
    +'finally{window._pendingAttackWeapon=ow;Math.random=orand;}})()');

  S.check('_pcAttackIsBalanced exists',ev('typeof _pcAttackIsBalanced')==='function');
  S.check('Balanced detected from the effect text',
    ev('(function(){var o=window._pendingAttackWeapon;window._pendingAttackWeapon={effect:"Balanced"};'
      +'try{return _pcAttackIsBalanced();}finally{window._pendingAttackWeapon=o;}})()')===true);
  S.check('plain weapon is not Balanced',
    ev('(function(){var o=window._pendingAttackWeapon;window._pendingAttackWeapon={effect:"Ablating"};'
      +'try{return _pcAttackIsBalanced();}finally{window._pendingAttackWeapon=o;}})()')===false);

  LEVELS.forEach(L=>{
    for(let f=1;f<=6;f++){
      /* unbalanced: greater at 5-6 */
      const h=run(L,'head',f,false);
      S.eq(L+' head d6='+f+' plain',h&&h.roll,f>=5?'12':'11');
      const t=run(L,'torso',f,false);
      S.eq(L+' torso d6='+f+' plain',t&&t.roll,f>=5?'9\u201310':'6\u20138');

      /* balanced: +1, so greater from a raw 4 */
      const hb=run(L,'head',f,true);
      S.eq(L+' head d6='+f+' Balanced',hb&&hb.roll,f>=4?'12':'11');
      const tb=run(L,'torso',f,true);
      S.eq(L+' torso d6='+f+' Balanced',tb&&tb.roll,f>=4?'9\u201310':'6\u20138');

      /* limbs take no roll, so Balanced changes nothing */
      ['r_arm','l_arm','r_limb','l_limb'].forEach(k=>
        S.eq(L+' '+k+' d6='+f+' Balanced is inert',
          (run(L,k,f,true)||{}).roll,'4\u20135'));
      ['r_leg','l_leg'].forEach(k=>
        S.eq(L+' '+k+' d6='+f+' Balanced is inert',
          (run(L,k,f,true)||{}).roll,'2\u20133'));
    }
  });

  /* the label must tell the player which die was rolled */
  S.check('note reads 1d6+1 when Balanced',/1d6\+1/.test((run('Simple','head',3,true)||{}).note||''));
  S.check('note reads 1d6 when not Balanced',/1d6:/.test((run('Simple','head',3,false)||{}).note||''));

  /* raw 4 is the whole point of the rule — it flips with Balanced */
  LEVELS.forEach(L=>{
    S.check(L+' a raw 4 is lesser plain and greater Balanced (head)',
      run(L,'head',4,false).roll==='11'&&run(L,'head',4,true).roll==='12');
    S.check(L+' a raw 4 is lesser plain and greater Balanced (torso)',
      run(L,'torso',4,false).roll==='6\u20138'&&run(L,'torso',4,true).roll==='9\u201310');
  });

  /* unaimed half of the rule: 2d6+2 */
  S.check('unaimed Balanced adds +2 to the 2d6 total',
    ev('(function(){var o=window._pendingAttackWeapon;window._pendingAttackWeapon={effect:"Balanced"};'
      +'var orand=Math.random;Math.random=function(){return 0.01;};'   /* d1=1,d2=1 */
      +'try{var r=rollCritWound("Simple");return r&&r.total===4&&r.balanced===true;}'
      +'finally{window._pendingAttackWeapon=o;Math.random=orand;}})()')===true);

  process.exit(S.report()?0:1);
},5000);
