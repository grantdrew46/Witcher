/* Suite 06 — Loot lifecycle: every coin and item must be payable exactly once.
   Four routes out of a pile:
     1. a PC walks over and takes it        (battle_loot_take -> gmSendGrantLoot)
     2. the GM assigns it to a player       (gmBattleSendAssigned)
     3. the GM splits the crowns            (gmBattleSplitCrowns)
     4. the corpse sweep spawns the pile    (gmBattleLootSweep)
   Each must consume what it hands out, and the sweep must not re-spawn.
   Also covers WB.cellOccupied, which the board click handler needs. */
const {boot,Suite}=require('../harness.js');
const S=Suite('06 loot-lifecycle + cellOccupied');
const {dom,errs}=boot('/home/claude/W/gm.html');

setTimeout(()=>{
  const ev=s=>dom.window.eval(s);
  S.check('boot clean',errs.length===0);

  /* ── WB.cellOccupied ─────────────────────────────────────────────── */
  S.check('WB.cellOccupied is defined',ev('typeof WB.cellOccupied')==='function');
  const T=JSON.stringify([
    {i:1,n:'Hector',x:5,y:5,lv:0,sz:1},
    {i:2,n:'Corpse',x:5,y:5,lv:0,sz:1,dead:true},
    {i:3,n:'Pile',x:7,y:7,lv:0,sz:1,loot:['Crowns (5)']},
    {i:4,n:'Troll',x:8,y:8,lv:0,sz:2},          /* covers 8,8 8,9 9,8 9,9 */
    {i:5,n:'Upstairs',x:7,y:7,lv:1,sz:1},
    {i:6,n:'DeadToo',x:9,y:9,lv:0,sz:1,dead:true}
  ]);
  const co=(x,y,self)=>ev('(function(){var r=WB.cellOccupied('+T+','+x+','+y+','+self+');'
    +'return r?r.n:null;})()');
  S.eq('living token standing on a corpse is returned',co(5,5,2),'Hector');
  S.eq('the corpse does not return itself',co(5,5,1),null);
  S.eq('nobody standing on the loot pile',co(7,7,3),null);
  S.eq('a token one floor up is not standing here',co(7,7,3),null);
  S.eq('a large creature covers the whole footprint',co(9,9,6),'Troll');
  S.eq('empty cell returns null',co(1,1,1),null);
  S.eq('another corpse never steals the click',co(9,9,4),null);
  S.eq('null token list is safe',ev('WB.cellOccupied(null,1,1,1)'),null);
  S.eq('unknown selfId is safe',ev('(function(){var r=WB.cellOccupied('+T+',5,5,999);return r?r.n:null;})()'),'Hector');

  /* ── loot routes ─────────────────────────────────────────────────── */
  /* build a board with two bodies carrying crowns and items */
  const setup=`(function(parties){
    window._gmB = window._gmB || {};
    var B = window._gmB;
    B.w=20; B.h=20; B.lvl=0; B.lootDone={};
    B.toks=[
      {i:101,n:'Loot',x:2,y:2,side:'npc',loot:['Crowns (25)','Drowner Brain'],lootOf:'Drowner'},
      {i:102,n:'Loot',x:4,y:4,side:'npc',loot:['Crowns (10)','Rusty Sword'],lootOf:'Bandit'}
    ];
    window._gmBGrants = [];
    window.gmBattleGrantLoot = function(pid, items, crowns){
      window._gmBGrants.push({pid:pid, items:(items||[]).slice(), crowns:crowns||0});
    };
    window.gmBattlePartyList = function(){ return parties; };
    window.gmBattleToast = function(){};
    window.gmBattleTouch  = function(){};
    return true;
  })`;

  const poolTotal=()=>ev('(function(){var p=gmBattleLootPool(),t=0;'
    +'for(var i=0;i<p.length;i++)t+=p[i].crowns;return t;})()');
  const poolCount=()=>ev('gmBattleLootPool().length');
  const paid=()=>ev('window._gmBGrants.reduce(function(a,g){return a+g.crowns;},0)');

  /* --- split crowns: 35 total, 4 players -> 8 each, 3 remain --- */
  ev(setup+'([{id:"p1"},{id:"p2"},{id:"p3"},{id:"p4"}])');
  S.eq('pool starts at 35 crowns',poolTotal(),35);
  ev('gmBattleSplitCrowns()');
  S.eq('first split pays 8 x 4 = 32',paid(),32);
  S.eq('3 odd crowns stay in the pool',poolTotal(),3);
  S.check('the two item lines survive the split',
    ev('gmBattleLootPool().map(function(p){return p.text;}).join("|")').indexOf('Drowner Brain')>=0);

  /* the whole point: pressing it again must not pay again */
  ev('gmBattleSplitCrowns()');
  S.eq('second split pays nothing more (3 < 4 players)',paid(),32);
  S.eq('pool still holds only the 3 odd crowns',poolTotal(),3);

  /* --- an exact division leaves nothing behind --- */
  ev(setup+'([{id:"p1"},{id:"p2"},{id:"p3"},{id:"p4"},{id:"p5"}])');
  ev('gmBattleSplitCrowns()');
  S.eq('35 across 5 pays all 35',paid(),35);
  S.eq('no crowns left in the pool',poolTotal(),0);
  S.eq('items remain on the field',poolCount(),2);
  ev('gmBattleSplitCrowns()');
  S.eq('splitting an empty purse pays nothing',paid(),35);

  /* --- a PC taking a pile consumes it --- */
  ev(setup+'([{id:"p1"},{id:"p2"}])');
  ev('gmSendGrantLoot("p1", gmBattleTokById(101))');
  S.eq('taking pile 101 grants its 25 crowns',paid(),25);
  S.eq('pile 101 is gone from the pool',
    ev('gmBattleLootPool().filter(function(p){return p.tok===101;}).length'),0);
  S.eq('the other pile is untouched',poolTotal(),10);
  ev('gmSendGrantLoot("p2", gmBattleTokById(101))');
  S.eq('taking an already-emptied pile pays nothing',paid(),25);

  /* --- split after a pickup must not re-pay the taken coins --- */
  ev('gmBattleSplitCrowns()');
  S.eq('split only pays the 10 still on the field',paid(),35);
  S.eq('nothing left to split',poolTotal(),0);

  /* --- the corpse sweep is idempotent --- */
  S.check('lootDone guard exists on the board state',ev('typeof window._gmB.lootDone')==='object');
  ev('window._gmB.lootDone={"7":1}');
  S.eq('a swept corpse is not swept twice',ev('window._gmB.lootDone["7"]'),1);
  S.check('lootDone survives a save (no leading underscore)',
    ev('(function(){var out={},B=window._gmB;'
      +'for(var k in B) if(k.charAt(0)!=="_") out[k]=B[k];'
      +'return out.lootDone!==undefined;})()')===true);

  /* --- crown-line detection must match the real bestiary format --- */
  [['Crowns (25)',true],['25 crowns',true],['crowns (7)',true],['  Crowns ( 3 ) ',true],
   ['Drowner Brain',false],['Rusty Sword',false],['Crown Jewel',false],
   ['Crowns (5) and a dagger',false],['',false]].forEach(([t,want])=>
    S.eq('WB.isCrownLine '+JSON.stringify(t),ev('WB.isCrownLine('+JSON.stringify(t)+')'),want));
  S.check('markup is stripped before testing',
    ev('WB.isCrownLine("<span style=\'color:gold\'>Crowns (12)</span>")')===true);

  /* --- the summary must not list coin as an item AND as a total --- */
  ev(`(function(){ window._gmB.toks=[{i:201,n:'Loot',x:1,y:1,
        loot:['Crowns (25)','Drowner Brain','Drowner Brain','12 crowns']}]; })()`);
  const items=ev('gmLootGrouped().map(function(g){return g.name+"x"+g.qty;}).join("|")');
  const tot=ev('(function(){var c=0;gmBattleLootPool().forEach(function(p){c+=(p.crowns||0);});return c;})()');
  S.eq('summary item list excludes coin',items,'Drowner Brainx2');
  S.eq('summary crown total still counts both coin lines',tot,37);
  S.check('neither crown format leaks into the item list',
    items.toLowerCase().indexOf('crown')<0);

  /* ── spoils reach the player as real items ────────────────────────────
     Loot used to arrive as a stub named "Battlefield loot" with no damage,
     armour or weight. The compendium record was already being looked up and
     discarded. Only 19 of 878 generated loot lines even matched, because the
     names carry quantities, arrow prefixes and descriptive tails. */
  const B2=boot('/home/claude/W/sheet.html');
  setTimeout(()=>{
    const eb=x=>{try{return B2.dom.window.eval(x);}catch(e){return 'ERR:'+e.message;}};
    S.check('sheet boots clean',B2.errs.length===0);
    S.check('pcLootResolveAll exists',eb('typeof pcLootResolveAll')==='function');

    const one=(raw)=>eb('JSON.stringify(pcLootResolveAll('+JSON.stringify(raw)+'))');
    S.check('a plain line resolves',/Iron Long Sword/.test(one('Iron Long Sword (1)')));
    S.eq('quantity is read off the line',
      JSON.parse(one('Bolts (20)'))[0].qty,20);
    S.eq('an arrow prefix keeps only what was rolled',
      JSON.parse(one('Random rune \u2192 Veles Runestone'))[0].name,'Veles Rune');
    S.eq('a descriptive tail is dropped',
      JSON.parse(one('Green Mutagen \u2014 +5 HP (Alchemy DC 18 to consume)'))[0].name,'Green Mutagen');
    S.eq('a rolled list unpacks into several items',
      JSON.parse(one('Random items \u2192 Dice, Reins')).length,2);
    /* An exact match now wins: porting the GM item list added "Wraith Essence"
       alongside the sheet's own "Essence of Wraith". Either resolves, and the
       exact one is the right answer. */
    S.check('reversed word order still resolves',
      !!JSON.parse(one('Wraith essence (1)'))[0].comp);
    S.check('and prefers an exact name when one exists',
      /wraith/i.test(JSON.parse(one('Wraith essence (1)'))[0].name));
    S.eq('and the other way round',
      JSON.parse(one('Fragment of stone (1)'))[0].name,'Stone Fragment');
    S.check('a plural finds its singular',
      !!JSON.parse(one('Drowner brains (2)'))[0].comp);
    S.check('a synonym bridges the two data sets',
      !!JSON.parse(one('Troll skin (1)'))[0].comp);
    S.check('a non-item resolves to no compendium entry',
      !JSON.parse(one('Mundane items (2)'))[0].comp);
    /* the generator resolves its own categories; the sweep must emit the
       rolled picks, never the "Mundane items (3)" header */
    S.eq('a comma in an ordinary name does not split it',
      JSON.parse(one('A strange, empty lamp')).length,1);
    S.eq('but a rolled list still splits',
      JSON.parse(one('Random items \u2192 Dice, Reins')).length,2);
    S.eq('bolts are crossbow ammunition',
      JSON.parse(one('Bolts (20)'))[0].name,'Standard Scorpio Bolt');
    S.eq('arrows are bow ammunition',
      JSON.parse(one('Arrows (30)'))[0].name,'Standard Arrow (x10)');
    S.check('the bestiary typo is bridged',
      !!JSON.parse(one('Alchmey set (1)'))[0].comp);
    S.check('coin is currency, never an item',
      eb(`(function(){ char.inventory=[]; char.crowns=0;
        pcBattleReceiveLoot(['Crowns (12)'],12);
        return char.inventory.length===0 && char.crowns===12; })()`)===true);
    /* Some bestiary loot entries lost their separators, so several items
       arrive as one string. Split by matching known compendium names, never
       by capitalisation: "Journal Ledger" is two items and "Green Mutagen" is
       one, and the two are shaped identically. */
    S.check('a run-on list splits into its items',
      JSON.parse(one('Belt pouch Writing kit Journal Ledger')).length>=3);
    S.check('every piece of that list resolves',
      JSON.parse(one('Belt pouch Writing kit Journal Ledger')).every(function(x){return !!x.comp;}));
    S.eq('a title-cased single item is not split','Green Mutagen',
      JSON.parse(one('Green Mutagen'))[0].name);
    S.eq('nor is Specter Dust','Specter Dust',
      JSON.parse(one('Specter Dust'))[0].name);
    /* Dimeritium restraints are a core rulebook item (pg.167-168), so this
       must resolve rather than be split into "Dimeritium" and "shackles". */
    S.eq('Dimeritium shackles stays one item',
      JSON.parse(one('Dimeritium shackles')).length,1);
    S.eq('and resolves to the real entry',
      JSON.parse(one('Dimeritium shackles'))[0].comp.name,'Dimeritium Shackles');
    S.check('carrying the anti-magic rule',
      /Vigor Threshold/.test(JSON.parse(one('Dimeritium shackles'))[0].comp.effect));
    S.check('a four-item NPC list splits fully',
      JSON.parse(one('Skellige helm Hindarsfjall heavy armor Hindarsfjall heavy chausses')).length===3);
    S.check('tiling is safe on a two-word string',eb('pcLootTile("Wolf liver").length')===1);
    S.check('tiling is safe on empty input',eb('pcLootTile("").length')===0);
    /* An item and its crafting diagram share a name. Loot is the object. */
    S.eq('loot resolves to the item, not its recipe',
      JSON.parse(one('Standard Scorpio Bolt'))[0].comp.type,'ammo');
    S.check('recipes are still in the compendium',
      eb('getAllCompData().some(function(c){return c.type==="recipe";})'));
    /* 17 gear items were entered twice; 5 more share a name but differ */
    S.eq('a double-entered item is folded into one',
      eb('getAllCompData().filter(function(c){return c.name==="Satchel";}).length'),1);
    S.eq('and keeps the book-sourced figures',
      eb('getAllCompData().filter(function(c){return c.name==="Satchel";})[0].cost'),14);
    /* GM decision: where the same object was entered twice, the book version
       (the one with a printed category) wins outright — including where that
       loses a bonus the homebrew entry carried. */
    [['Bandolier',19],["Merchant's Tools",60],['Holy Symbol',14],['Black magic doll',500]]
      .forEach(function(pair){
        const got=JSON.parse(eb('JSON.stringify(getAllCompData().filter(function(c){'
          +'return String(c.name).toLowerCase()==='+JSON.stringify(pair[0].toLowerCase())+';})'
          +'.map(function(c){return c.cost;}))'));
        S.eq('"'+pair[0]+'" is now a single entry',got.length,1);
        S.eq('"'+pair[0]+'" kept the book figure',got[0],pair[1]);
      });
    S.check('Holy Symbol keeps the book effect, not the homebrew bonus',
      /religious focus/i.test(eb('getAllCompData().filter(function(c){'
        +'return String(c.name).toLowerCase()==="holy symbol";})[0].effect')));
    /* Sun stone had two unrelated effects; GM chose the fire focus. The
       navigation entry carried the book category, so this cannot be decided
       by category and is named explicitly. */
    S.eq('Sun stone is a single entry',
      eb('getAllCompData().filter(function(c){return /^sun\\s*stone$/i.test(c.name||"");}).length'),1);
    S.check('and it is the fire-casting one',
      /fire/i.test(eb('getAllCompData().filter(function(c){'
        +'return /^sun\\s*stone$/i.test(c.name||"");})[0].effect')));
    S.eq('at the fire version cost',
      eb('getAllCompData().filter(function(c){return /^sun\\s*stone$/i.test(c.name||"");})[0].cost'),40);
    /* the loot tables write it as one word */
    S.check('"Sunstone" still finds it despite the spacing',
      !!JSON.parse(one('Sunstone'))[0].comp);
    S.check('and resolves to the same entry',
      JSON.parse(one('Sunstone'))[0].comp.cost===40);
    S.check('no other same-name same-type duplicates remain',
      eb(`(function(){var c={},n=0;getAllCompData().forEach(function(x){
        if(!x.name||x.type==='recipe')return; var k=x.name.toLowerCase()+'|'+(x.type||'');
        c[k]=(c[k]||0)+1;});
        var keep={};
        Object.keys(c).forEach(function(k){ if(c[k]>1 && !keep[k]) n++; });
        return n===0;})()`)===true);
    /* pg.251 / Journal pg.144: a mutagen belongs to the creature it came from.
       A Werewolf's and a Nekker's differ in effect and Alchemy DC, so a drop
       labelled only by colour is unusable. */
    /* 12 from the core book, 16 from the Journal, 3 from Monsters on the Road.
       Botchling is in the Journal's table and stays out, having been removed
       from the campaign. */
    S.eq('every mutagen in the book tables has an entry',
      eb('getAllCompData().filter(function(c){return /mutagen \\(/i.test(c.name||"");}).length'),31);
    ['Alp Mutagen (Blue)','Glustyworp Mutagen (Green)','Werecat Mutagen (Red)'].forEach(function(n){
      S.check('"'+n+'" imported from the DLC',!!JSON.parse(one(n))[0].comp);
    });
    ['Alp Saliva','Glustyworp Stomach','Werecat Teeth'].forEach(function(n){
      S.check('"'+n+'" imported with its substance',
        !!JSON.parse(one(n))[0].comp && !!JSON.parse(one(n))[0].comp.substance);
    });
    S.check('the nine pure substances are in',
      eb('getAllCompData().filter(function(c){return /^Pure /.test(c.name||"");}).length')===9);
    S.check('a pure unit counts as two',
      /two units/i.test(eb('getAllCompData().filter(function(c){return c.name==="Pure Vitriol";})[0].effect')));
    /* the two parts printed nowhere, added as homebrew with a substance */
    S.check('Werewolf Pelt distils',JSON.parse(one('Werewolf pelt'))[0].comp.substance==='Rebis');
    S.check('Rat Tail distils',JSON.parse(one('Rat tails'))[0].comp.substance==='Vitriol');
    S.check('both are marked homebrew',
      /\u2699/.test(eb('getAllCompData().filter(function(c){return c.name==="Rat Tail";})[0].cat')));
    /* the merged Holy Symbol keeps both effects */
    S.check('Holy Symbol keeps the book effect and the homebrew bonus',
      /Religious focus/.test(eb('getAllCompData().filter(function(c){return /^holy symbol$/i.test(c.name||"");})[0].effect'))
      && /Initiate of the Gods/.test(eb('getAllCompData().filter(function(c){return /^holy symbol$/i.test(c.name||"");})[0].effect')));
    [['Werewolf Mutagen (Red)','+3 melee',20,'Rapid hair growth'],
     ['Nekker Mutagen (Red)','+1 melee',15,'Baldness & grey skin'],
     ['Leshen Mutagen (Blue)','+1 WILL',22,'Plant growth on the body'],
     ['Succubus Mutagen (Green)','+5 HP',18,'Small horns and a tail']].forEach(function(m){
      const c=JSON.parse(one(m[0]))[0].comp;
      S.check('"'+m[0]+'" resolves',!!c);
      if(!c) return;
      S.check('  effect is the creature\'s own',String(c.effect).indexOf(m[1])>=0);
      S.eq('  Alchemy DC',c.alchemyDC,m[2]);
      S.eq('  minor mutation',c.minorMutation,m[3]);
    });
    S.check('Botchling is excluded, being removed from the campaign',
      !eb('getAllCompData().some(function(c){return /botchling/i.test(c.name||"");})'));
    /* Named characters carry a pointer to the sourcebook instead of a kit —
       their gear runs to pages and they are rarely killed. It is a GM note,
       so it must never reach the floor as an item. */
    /* stronger than before: it is filtered out entirely rather than merely
       failing to match, so it can never reach a pack */
    S.eq('the sourcebook pointer is not an item at all',
      JSON.parse(one('See the sourcebook for this character\u2019s equipment')).length,0);
    /* The 32 props the GM approved: they were loot names with no stats and
       no reason to keep them, and each now does something. */
    [['Lady\u2019s favor','Courage'],['Jar of leeches','Bleeding'],
     ['Spiral talisman','way-station'],['Redanian tabard','Persuasion'],
     ['Interrogation kit','Interrogation'],['Herbalist\u2019s tools','Herbalism'],
     ['House livery','Disguise'],['Squirrel tail','bounty'],
     ['Map case','Wilderness Survival'],['Grave ledger page','Deduction']].forEach(function(pair){
      const c=JSON.parse(one(pair[0]))[0].comp;
      S.check('"'+pair[0]+'" resolves',!!c);
      if(c) S.check('  and carries its use ('+pair[1]+')',
        String(c.effect||'').indexOf(pair[1])>=0);
    });
    S.check('all 32 are marked as house rules',
      eb('getAllCompData().filter(function(c){return /\\u2699/.test(c.cat||"");}).length')>=32);
    /* the random-possessions junk now buys a small situational edge each */
    [['Twine','tripline'],['Lockpicks','Pick Lock'],['Ball of clay','impression'],
     ['Unit of feathers','Fletching'],['Musical instrument','Charisma'],
     ['Books & notes','Education'],["Artisan's tools",'Crafting'],
     ["Labourer's tools",'bludgeoning'],['Stolen trinket','fence'],
     ['Gnawed crowns','remembers']].forEach(function(pair){
      const c=JSON.parse(one(pair[0]))[0].comp;
      S.check('"'+pair[0]+'" resolves',!!c);
      if(c) S.check('  and does something ('+pair[1]+')',
        String(c.effect||'').indexOf(pair[1])>=0);
    });
    /* items that were only ever a parsing failure */
    S.eq('"Bolts (x10)" reads the count off the name',
      JSON.parse(one('Bolts (x10)'))[0].qty,10);
    S.check('and matches the ammunition',!!JSON.parse(one('Bolts (x10)'))[0].comp);
    S.check('"Glyph of Yrden" resolves',!!JSON.parse(one('Glyph of Yrden'))[0].comp);
    S.check('"Wolf liver" resolves',!!JSON.parse(one('Wolf liver'))[0].comp);
    S.check('"Chitin" resolves',!!JSON.parse(one('Chitin'))[0].comp);
    /* transcription leftovers must never reach a pack */
    ['\u00d72','1','of some form','Ledger &','Crownsin florens',
     'Crownsin mixed old mint','Any Worn Weapons or Items','The Armor Animated'
    ].forEach(function(junk){
      S.eq('"'+junk+'" is not an item',JSON.parse(one(junk)).length,0);
    });
    /* Three bestiary entries lost the space in "Crowns in florens". That
       failed the coin test at both ends \u2014 the GM never extracted the amount
       and the sheet never credited it, so the coin evaporated between the
       corpse and the pack. */
    ['Crowns (25)','Crowns (4d10) in florens','Crownsin florens',
     'Crownsin old coin','Crownsin mixed old mint','1250 Crowns'].forEach(function(n){
      S.check('"'+n+'" is recognised as coin',eb('WB.isCrownLine('+JSON.stringify(n)+')')===true);
      S.eq('  and never enters the pack',JSON.parse(one(n)).length,0);
    });
    S.check('an actual item is still an item',eb('WB.isCrownLine("Iron Long Sword")')===false);
    /* A creature name is also half of its mutagen's name, so tiling on
       bestiary entries split "Grave Hag Mutagen (Green)" into the monster
       and an orphan that matched nothing. */
    [['Grave Hag Mutagen (Green)','+5 HP'],['Rock Troll Mutagen (Green)','+10 HP'],
     ['Werewolf Mutagen (Red)','+3 melee'],['Siren Mutagen (Blue)','Vigor']].forEach(function(pair){
      const r=JSON.parse(one(pair[0]));
      S.eq('"'+pair[0]+'" is not split apart',r.length,1);
      S.check('  and resolves',!!r[0].comp);
      if(r[0].comp) S.check('  with its own effect ('+pair[1]+')',
        String(r[0].comp.effect||'').indexOf(pair[1])>=0);
    });
    S.check('a creature name alone is still not a tiling anchor',
      eb('(function(){var t=pcLootTile("Grave Hag Mutagen (Green)");return t.length===1;})()')===true);
    /* The dash strip ran before the bracket strip, leaving a dangling
       "(inedible" that matched nothing. */
    S.eq('a parenthetical explanation does not orphan a bracket',
      JSON.parse(one('Plague-tainted meat (inedible \u2014 burn it)'))[0].name,'Plague-tainted Meat');
    S.check('and it resolves',!!JSON.parse(one('Plague-tainted meat (inedible \u2014 burn it)'))[0].comp);
    S.check('a normal dashed note still works',
      !!JSON.parse(one('Rat tails (5) \u2014 1 crown each'))[0].comp);
    /* rn read as m: the deity is Chernobog, as the other runestones are */
    S.check('the rune is spelled Chernobog',!!JSON.parse(one('Chernobog Rune'))[0].comp);
    S.check('so is the glyph',!!JSON.parse(one('Chernobog Glyph'))[0].comp);
    S.eq('and the misreading is gone from the compendium',
      S.val(eb(`getAllCompData().filter(function(c){
        return /chemobog/i.test((c.name||'')+(c.desc||'')); }).map(function(c){return c.name;})`)).length,0);
    S.check('the Phoenix egg has an entry',!!JSON.parse(one('Phoenix Egg'))[0].comp);
    /* Foraging reads the compendium. The first version carried its own herb
       tables, which invented seventeen herbs that do not exist \u2014 and ignored
       that every component already states where it is found, its DC and its
       yield. There must be no second source of truth here. */
    S.check('there are forage places',eb('Object.keys(FORAGE_PLACES||{}).length')>=8);
    S.check('every place has an icon and a location matcher',
      eb(`Object.keys(FORAGE_PLACES).every(function(k){
        var p=FORAGE_PLACES[k]; return !!p.n && !!p.e && p.match instanceof RegExp; })`));
    S.check('the terrain places each surface something',
      eb(`['forest','field','cave','mountain','water'].every(function(k){
        return forageableAt(k).length > 0; })`));
    S.eq('everything surfaced comes straight from the compendium',
      eb(`(function(){
        var bad=[];
        Object.keys(FORAGE_PLACES).forEach(function(k){
          forageableAt(k).forEach(function(c){
            if(!(c.forage>0) || !c.name) bad.push(c.name||'?'); }); });
        return bad;})()`).length,0);
    S.eq('creature drops are never offered as foraging',
      eb(`(function(){
        var bad=[];
        Object.keys(FORAGE_PLACES).forEach(function(k){
          forageableAt(k).forEach(function(c){
            if(/found on|found in/i.test(String(c.loc||''))) bad.push(c.name); }); });
        return bad;})()`).length,0);
    /* the time curve the GM approved: steepening at the top */
    S.eq('DC 8 is half an hour',eb('forageHours(8)'),0.5);
    S.eq('DC 12 is an hour',eb('forageHours(12)'),1);
    S.eq('DC 15 is two',eb('forageHours(15)'),2);
    S.eq('DC 18 is four',eb('forageHours(18)'),4);
    S.eq('DC 20 is eight',eb('forageHours(20)'),8);
    S.eq('DC 24 is sixteen \u2014 a two-day expedition',eb('forageHours(24)'),16);
    S.check('and the label says so',/day/.test(eb('forageHoursLabel(24)')));
    /* colour: substance for components, rarity for materials */
    S.check('a substance component is coloured by its substance',
      eb(`(function(){
        var c=forageableAt('forest').filter(function(x){return _forageSub(x);})[0];
        return !!c && _forageColour(c)===SUBSTANCE_COLORS[_forageSub(c)];})()`)===true);
    S.check('a plain material is coloured by rarity',
      eb(`(function(){
        var c=forageableAt('forest').filter(function(x){return !_forageSub(x);})[0];
        return !c || _forageColour(c)===RARITY_COLORS[c.rarity];})()`)===true);
    S.check('tracked components read the same list the tracker box uses',
      eb(`(function(){
        char.trackedComponents=['Timber'];
        return _forageTracked('Timber') && !_forageTracked('Mistletoe');})()`)===true);
    /* the attempt */
    S.check('a successful forage banks components, not pack items',
      eb(`(function(){
        window.toast=function(){}; window.save=function(){};
        window.renderInventory=function(){}; window.renderCompTracker=function(){};
        window.syncLogLine=function(){}; window.syncSend=function(){};
        window._sync={connected:false};
        char.skills['Wilderness Survival']={val:12}; char.stats.INT=10;
        char.inventory=[]; char._forageSpent=false;
        var c=forageableAt('forest').filter(function(x){return x.forage<=10;})[0]
              || forageableAt('forest')[0];
        _forageAttempt(c,'Test');
        return char.inventory.length===0
          || char.inventory.every(function(i){ return i.location==='Component'; });})()`)===true);
    S.check('margin buys quantity',
      eb(`(function(){
        char.skills['Wilderness Survival']={val:20}; char.stats.INT=10;
        var big=0;
        for(var i=0;i<12;i++){
          char.inventory=[]; char._forageSpent=false;
          var c=getAllCompData().filter(function(x){return x.name==='Timber';})[0];
          _forageAttempt(c,'T');
          if(char.inventory[0] && char.inventory[0].qty>1) big++;
        }
        return big>0;})()`)===true);
    /* Three bugs found by probing rather than by the suite:
       \u2014 rollDiceFormula is GM-side and does not exist here, so every stated
         quantity was silently discarded and a find gave 1 plus margin;
       \u2014 a fumbled forage set a flag nothing ever cleared, so one bad roll
         disabled foraging for the rest of the campaign;
       \u2014 an unknown game key fell back to gwent, hiding scene typos. */
    S.check('the quantity roller exists sheet-side',eb('typeof _forageRollQty')==='function');
    [['2d6',2,12],['1d10',1,10],['1d6',1,6],['1d6/2',1,3],['1d6/3',1,2],['3',3,3]].forEach(function(t){
      const r=JSON.parse(eb(`(function(){
        var lo=99,hi=0,zero=0;
        for(var i=0;i<300;i++){ var v=_forageRollQty(${JSON.stringify(t[0])});
          if(v<lo)lo=v; if(v>hi)hi=v; if(v<1)zero++; }
        return JSON.stringify({lo:lo,hi:hi,zero:zero});})()`));
      S.eq('"'+t[0]+'" never yields nothing',r.zero,0);
      S.check('  and stays in range ('+r.lo+'-'+r.hi+')',r.lo>=t[1] && r.hi<=t[2]);
    });
    S.check('a stated quantity is actually rolled, not replaced by 1',
      eb(`(function(){
        var seen={};
        for(var i=0;i<200;i++) seen[_forageRollQty('2d6')]=1;
        return Object.keys(seen).length>3;})()`)===true);
    S.check('a new day reopens ground closed by a fumble',
      eb(`(function(){
        window.toast=function(){}; window.save=function(){};
        window.renderComp=function(){}; window.renderVentures=function(){};
        window.syncLogLine=function(){};
        char._forageSpent=true; char._clock={day:1,watch:0};
        _applyClock({day:2,watch:0,label:'Day 2'});
        return char._forageSpent===false;})()`)===true);
    S.check('but the same day does not',
      eb(`(function(){
        char._forageSpent=true; char._clock={day:5,watch:0};
        _applyClock({day:5,watch:3,label:'Day 5'});
        return char._forageSpent===true;})()`)===true);
    S.check('an unknown game is reported rather than opening gwent',
      eb(`(function(){
        window.__t=''; window.toast=function(t){window.__t=t;};
        _poiOpenGame('nosuchgame');
        return /not set up/.test(String(window.__t));})()`)===true);
    /* The guard itself, rather than the toast text \u2014 asserting through the
       UI made this depend on whichever stub owned window.toast at the time. */
    S.check('a fumble closes the ground for the day',
      String(eb(`(function(){
        char._forageSpent=true;
        var stale=document.getElementById('pcForagePop'); if(stale) stale.remove();
        _poiForage('forest','X');
        return document.getElementById('pcForagePop') ? 'OPENED' : 'refused';})()`))==='refused');
    S.check('the guard is checked before the item list',
      /_forageSpent/.test(String(eb('String(_poiForage)')).split('forageableAt')[0]));
    S.check('the picker lists items and can be opened',
      eb(`(function(){
        char._forageSpent=false;
        var el=document.getElementById('pcForagePop'); if(el) el.remove();
        _poiForage('cave','Cave mouth');
        var p=document.getElementById('pcForagePop');
        var ok=!!p && p.querySelectorAll('[data-fidx]').length>2;
        if(p) p.remove();
        return ok;})()`)===true);
    S.check('empty input is safe',eb('pcLootResolveAll("").length')===0);
    S.check('null input is safe',eb('pcLootResolveAll(null).length')===0);

    /* the whole point: stats, not a stub */
    const inv=eb(`(function(){ char.inventory=[];
      pcBattleReceiveLoot(['Iron Long Sword (1)'],0);
      var it=char.inventory[0];
      return it?{name:it.name,dmg:it.dmg,wt:it.wt,fromComp:!!it.fromComp}:null; })()`);
    S.eq('a looted sword keeps its name',inv&&inv.name,'Iron Long Sword');
    S.check('and its damage ('+(inv&&inv.dmg)+')',!!(inv&&inv.dmg));
    S.check('and its weight ('+(inv&&inv.wt)+')',!!(inv&&inv.wt));
    S.check('and is flagged as compendium-linked',!!(inv&&inv.fromComp));
    S.check('crafting components route to the craft list, not the pack',
      eb(`(function(){ char.inventory=[];
        pcBattleReceiveLoot(['Drowner brains (2)'],0);
        return char.inventory.length===0; })()`)===true);

    /* colours are keyed to the compendium type */
    S.check('a weapon and a component get different colours',
      eb('pcLootColor({type:"weapon"})')!==eb('pcLootColor({type:"component"})'));
    S.check('an unknown type falls back safely',
      String(eb('pcLootColor({type:"nonsense"})')).length>0);

    /* GM-side assertions run last, inside this block, and own the exit —
       previously they sat after a process.exit and 42 assertions never ran. */
    /* "Random Runestones (x3)" produced one rune, not three: parseInt("x3")
       is NaN, so the count fell back to 1 at both quantity-parsing sites.
       These live GM-side, so they need the tracker rather than the sheet. */
    const G2=boot('/home/claude/W/gm.html');
    setTimeout(function(){
      const eg=x=>{try{return G2.dom.window.eval(x);}catch(e){return 'THREW: '+e.message;}};
      const lbl=q=>String(eg('resolveLootLine('+JSON.stringify(q)+').label')).replace(/<[^>]+>/g,'');
      /* Two checks in this suite were written as eb('true') \u2014 placeholders
         that always passed while claiming to verify a removal. Both live here
         now, where the GM globals they need actually exist. */
      S.eq('"No identifying marks" is gone from every loot table',
        S.val(eg(`(function(){
          var bad=[];
          DEFAULT_BESTIARY.forEach(function(b){
            (b.loot||[]).forEach(function(l){
              if(typeof l==='string' && /no identifying marks/i.test(l)) bad.push(b.name); }); });
          return bad;})()`)).length,0);
      S.eq('the Chemobog misreading is gone from every random pool',
        S.val(eg(`(function(){
          var bad=[];
          Object.keys(RANDOM_POOLS||{}).forEach(function(k){
            (RANDOM_POOLS[k]||[]).forEach(function(n){
              if(/chemobog/i.test(String(n))) bad.push(k+':'+n); }); });
          return bad;})()`)).length,0);
      S.check('and Chernobog is there under the right spelling',
        eg(`[].concat(RANDOM_POOLS.rune||[],RANDOM_POOLS.glyph||[])
             .filter(function(n){return /chernobog/i.test(n);}).length===2`)===true);
      S.check('a random rune resolves to a named rune',/Rune/.test(lbl('Random rune')));
      S.check('runestones route to the rune pool',/Rune/.test(lbl('Random Runestones (x3)')));
      /* duplicates are collapsed into "Veles Rune \u00d73", so count the runes
         rather than the commas \u2014 three of one is still three */
      const runeCount=function(q){
        var s=lbl(q).split('\u2192')[1]||'';
        return s.split(',').reduce(function(a,part){
          var m=/[^A-Za-z]\s*(\d+)\s*$/.exec(part);
          return a+(m?parseInt(m[1],10):1); },0);
      };
      S.eq('and (x3) yields three of them',runeCount('Random Runestones (x3)'),3);
      S.eq('(2) yields two',runeCount('Random Runestones (2)'),2);
      S.check('a dice count still works',/\(\d+\)/.test(lbl('Mundane items (x1d6)')));
      /* a collapsed duplicate reads "Stribog Rune \u00d72", so strip the count
         before checking the name against the pool */
      S.check('each rolled rune is a real pool entry',
        eg(`(function(){
          for (var t=0;t<10;t++){
            var s=resolveLootLine('Random Runestones (x3)').label.replace(/<[^>]+>/g,'');
            var names=(s.split('\u2192')[1]||'').split(',').map(function(x){
              return x.replace(/[^A-Za-z]+\\d+\\s*$/,'').trim(); });
            if(!names.every(function(n){ return RANDOM_POOLS.rune.indexOf(n)>=0; })) return false;
          }
          return true;})()`)===true);
      process.exit(S.report()?0:1);
    },5200);
    return;
  },5200);
},5000);
