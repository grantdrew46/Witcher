/* Suite 02 — Falls, climbing, elevation (pg.170 mount-throw rate)
   pg.171: metres/2 rounded down, in d6, ALWAYS to the torso. 1 elevation level = 3 m.
   Climb DCs 2 m -> 12, 4 m -> 16, 6 m -> 20.
   Also checks gm.js and sheet.js have NOT drifted apart on the shared helpers. */
const {boot,Suite}=require('../harness.js');
const S=Suite('02 falls-climb (pg.170)');
const A=boot('/home/claude/W/sheet.html');
const B=boot('/home/claude/W/gm.html');

setTimeout(()=>{
  const ea=s=>A.dom.window.eval(s), eb=s=>B.dom.window.eval(s);
  S.check('sheet boots clean',A.errs.length===0);
  S.check('gm boots clean',B.errs.length===0);

  /* 1. elevation */
  S.eq('WB.LEVEL_METRES is 3 (sheet)',ea('WB.LEVEL_METRES'),3);
  S.eq('WB.LEVEL_METRES is 3 (gm)',eb('WB.LEVEL_METRES'),3);
  /* fallMetres clamps to >=1 level and takes |steps| by design — it is only ever
     called with a real level change, and a downward step arrives negative. */
  [[1,3],[2,6],[3,9],[-1,3],[-2,6],[0,3]].forEach(([lv,m])=>
    S.eq('fallMetres('+lv+' levels)',ea('WB.fallMetres('+lv+')'),m));
  S.eq('fallMetres floors at one level',ea('WB.fallMetres(0)'),ea('WB.LEVEL_METRES'));

  /* 2. fall dice = 1d6 per metre, minimum 1 */
  /* pg.171: metres divided by 2, rounded down. Under 2 m is zero dice. */
  const cases=[[1,0],[2,1],[3,1],[4,2],[6,3],[9,4],[12,6],[0.4,0],[0,0],[-5,0],[2.4,1],[2.6,1],[30,15]];
  cases.forEach(([m,n])=>{
    S.eq('fallDice('+m+') sheet',ea('WB.fallDice('+m+')'),n);
    S.eq('fallDice('+m+') gm',eb('WB.fallDice('+m+')'),n);
  });

  /* 3. rollFall structure and bounds */
  [1,2,4,9,30].forEach(m=>{
    const want=ea('WB.fallDice('+m+')');
    for(let i=0;i<40;i++){
      const f=ea('(function(){var f=WB.rollFall('+m+');return {d:f.dice,n:f.rolls.length,'
        +'t:f.total,s:f.rolls.reduce(function(a,b){return a+b;},0),'
        +'lo:f.rolls.length?Math.min.apply(null,f.rolls):1,'
        +'hi:f.rolls.length?Math.max.apply(null,f.rolls):6,m:f.metres};})()');
      if(f.d!==want||f.n!==want||f.t!==f.s||f.lo<1||f.hi>6||f.t<want||f.t>6*want||f.m!==m){
        S.check('rollFall('+m+') well-formed [iter '+i+'] '+JSON.stringify(f),false); return;
      }
    }
    S.check('rollFall('+m+'m) = '+want+'d6, well-formed over 40 rolls',true);
  });
  S.eq('a 1 m drop rolls no dice at all',ea('WB.rollFall(1).rolls.length'),0);
  S.eq('a 1 m drop deals no damage',ea('WB.rollFall(1).total'),0);
  S.check('no ceiling on a long fall (30 m = 15d6)',ea('WB.fallDice(30)')===15);

  /* 4. climb DCs */
  const dcs=[[1,12],[2,12],[3,16],[4,16],[5,20],[6,20],[7,22],[8,22],[10,24],[12,26]];
  dcs.forEach(([m,dc])=>{
    S.eq('climbDC('+m+'m) sheet',ea('WB.climbDC('+m+')'),dc);
    S.eq('climbDC('+m+'m) gm',eb('WB.climbDC('+m+')'),dc);
  });
  S.check('climbDC is monotonic non-decreasing',
    (()=>{let p=0;for(let m=1;m<=30;m++){const d=ea('WB.climbDC('+m+')');if(d<p)return false;p=d;}return true;})());

  /* 5. a climb is always harder than the fall it risks — sanity coupling */
  S.check('one storey (4m) climb DC 16 risks 2d6',
    ea('WB.climbDC(4)')===16&&ea('WB.fallDice(4)')===2);

  /* 6. hazard panel must use the same rate as the battle map */
  const haz=ea(`(function(){
    var m=document.getElementById('haz-fall-m'), r=document.getElementById('haz-fall-res');
    if(!m){ m=document.createElement('input'); m.id='haz-fall-m'; document.body.appendChild(m); }
    if(!r){ r=document.createElement('div'); r.id='haz-fall-res'; document.body.appendChild(r); }
    var out=[];
    [1,2,3,4,6,9].forEach(function(mm){
      m.value=String(mm); r.innerHTML='';
      try{ hazardFallRoll(); }catch(e){ out.push({m:mm,err:String(e)}); return; }
      var t=r.textContent||'';
      var mt=t.match(/(\\d+)d6/);
      /* under 2 m the panel says 'no damage' instead of printing 0d6 */
      out.push({m:mm, dice: mt?parseInt(mt[1],10):0, expect: WB.fallDice(mm),
                said: /no damage/i.test(t)});
    });
    return out;
  })()`);
  haz.forEach(h=>{
    S.eq('hazard panel '+h.m+'m dice matches WB.fallDice',h.dice,h.expect);
    if(h.expect===0) S.check('hazard panel says no damage at '+h.m+'m',h.said);
  });
  S.check('hazard panel reports the torso, not a rolled location',
    ea("(function(){var m=document.getElementById('haz-fall-m'),"
      +"r=document.getElementById('haz-fall-res');m.value='9';r.innerHTML='';"
      +"hazardFallRoll();var t=r.textContent||'';"
      +"return /Torso/.test(t)&&!/d10/.test(t);})()"));

  /* 7. pg.171 collision: whoever you land on takes the same damage.
        Also checks the height panel now carries the destination floor - it
        used to move the token sideways and leave it on the storey it left. */
  const fall=(spec)=>eb('(function(){'
    +'var b=DEFAULT_BESTIARY.find(function(x){return x.name==="Nekker";});'
    +'var A=makeMonsterCombatant(b,10), B2=makeMonsterCombatant(b,9);'
    +'combatants.length=0;combatants.push(A,B2);'
    +'window._gmB={w:20,h:20,lvl:0,elev:{},stamps:{},toks:'+spec+'};'
    +'window.gmBattleToast=function(){};window.gmBattleTouch=function(){};'
    +'var T=window._gmB.toks;T[0].link=A.id;if(T[1])T[1].link=B2.id;'
    +'var a0=A.hp,b0=B2.hp;'
    +'var f=gmBattleFall(T[0],9,"Dropped down");'
    +'return {total:f.total,dice:f.dice,faller:a0-A.hp,other:b0-B2.hp};})()');

  let r=fall('[{i:11,n:"Faller",x:5,y:5,lv:0},{i:12,n:"Victim",x:5,y:5,lv:0}]');
  S.eq('a 9 m fall is 4d6',r.dice,4);
  S.check('the faller takes damage ('+r.faller+')',r.faller>0);
  S.check('the body landed on takes damage too ('+r.other+')',r.other>0);
  S.eq('both take the same total after their own soak',r.faller,r.other);

  r=fall('[{i:11,n:"Faller",x:5,y:5,lv:0},{i:12,n:"Elsewhere",x:9,y:9,lv:0}]');
  S.check('someone across the board is not hit',r.other===0);
  r=fall('[{i:11,n:"Faller",x:5,y:5,lv:0},{i:12,n:"Upstairs",x:5,y:5,lv:1}]');
  S.check('someone on another floor is not landed on',r.other===0);
  r=fall('[{i:11,n:"Faller",x:5,y:5,lv:0},{i:12,n:"Corpse",x:5,y:5,lv:0,dead:true}]');
  S.check('landing on a corpse harms nobody further',r.other===0);
  r=fall('[{i:11,n:"Faller",x:5,y:5,lv:0}]');
  S.check('an empty landing cell does not throw',typeof r.total==='number');

  /* the height panel must hand the destination floor to the token */
  const drop=eb('(function(){'
    +'var b=DEFAULT_BESTIARY.find(function(x){return x.name==="Nekker";});'
    +'var A=makeMonsterCombatant(b,10);combatants.length=0;combatants.push(A);'
    +'window._gmB={w:20,h:20,lvl:0,elev:{},stamps:{},toks:[{i:11,n:"T",x:5,y:5,lv:2,link:A.id}]};'
    +'window.gmBattleToast=function(){};window.gmBattleTouch=function(){};'
    +'gmBattleAct("hgt-go:11:6:6:3:0:12:1");'
    +'var t=window._gmB.toks[0];return {x:t.x,y:t.y,lv:t.lv};})()');
  S.eq('a drop moves the token',[drop.x,drop.y],[6,6]);
  S.eq('a drop lands it on the destination floor',drop.lv,1);

  const noLv=eb('(function(){'
    +'var b=DEFAULT_BESTIARY.find(function(x){return x.name==="Nekker";});'
    +'var A=makeMonsterCombatant(b,10);combatants.length=0;combatants.push(A);'
    +'window._gmB={w:20,h:20,lvl:0,elev:{},stamps:{},toks:[{i:11,n:"T",x:5,y:5,lv:2,link:A.id}]};'
    +'window.gmBattleToast=function(){};window.gmBattleTouch=function(){};'
    +'gmBattleAct("hgt-go:11:6:6:3:0:12");'          /* legacy action, no floor field */
    +'var t=window._gmB.toks[0];return t.lv;})()');
  S.eq('an action without a floor field leaves the level alone',noLv,2);

  process.exit(S.report()?0:1);
},6000);
