/* Suite 08 — The sync contract.
   Every message one app sends must be dispatched on at the other end, and
   every payload field must actually be read there. A feature wired at only
   one end is silent: nothing throws, nothing logs, it simply never happens.
   Three of those were found by hand last session (pc_condition, pc_roll,
   say); this suite is so the next one is found by the runner instead. */
const {Suite}=require('../harness.js');
const C=require('../synccontract.js');
const S=Suite('08 sync-contract');

const gm=C.js('/home/claude/W/gm.html');
const sh=C.js('/home/claude/W/sheet.html');
const gmOut=C.outbound(gm,'gmSyncSend');
const shOut=C.outbound(sh,'syncSend');
const gmIn=C.handled(gm), shIn=C.handled(sh);

/* Traffic that deliberately does not cross to the other app. Anything listed
   here must still be dispatched on by its OWN app, which is asserted below —
   otherwise this list would be a place to hide genuinely dead features. */
const INTRA={
  shop_state:{ side:'sheet', why:'players sync shop stock to each other over the broadcast; the GM is not a party to it' },
  inn_state:{ side:'sheet', why:'the rolled inn is shared between players so everyone sees the same rooms, services and talk; the GM tracker has no inn' },
  state_please:{ side:'sheet', why:'a late joiner asks the room for the shared world state and whoever is present answers; sheet-to-sheet only' }
};

/* --- the extractor itself must not fail open ------------------------------
   A source-derived audit that silently matches nothing would pass every
   assertion below, so floor it against the known shape of the apps. */
S.check('GM script extracted ('+gm.length+' chars)',gm.length>1000000);
S.check('sheet script extracted ('+sh.length+' chars)',sh.length>1000000);
S.check('GM sends a plausible number of message types ('+Object.keys(gmOut).length+')',
  Object.keys(gmOut).length>=20);
S.check('sheet sends a plausible number of message types ('+Object.keys(shOut).length+')',
  Object.keys(shOut).length>=20);
S.check('GM dispatches on a plausible number of types ('+gmIn.size+')',gmIn.size>=40);
S.check('sheet dispatches on a plausible number of types ('+shIn.size+')',shIn.size>=40);
S.check('known types are found (battle_move)',!!shOut.battle_move);
S.check('known types are found (battle_toks)',!!gmOut.battle_toks);

/* --- type coverage, both directions -------------------------------------- */
Object.keys(shOut).sort().forEach(t=>{
  if(INTRA[t]) return;
  S.check('sheet sends "'+t+'" and the GM dispatches on it',gmIn.has(t));
});
Object.keys(gmOut).sort().forEach(t=>{
  if(INTRA[t]) return;
  S.check('GM sends "'+t+'" and the sheet dispatches on it',shIn.has(t));
});

/* --- the whitelist has to stay honest ------------------------------------ */
Object.keys(INTRA).forEach(t=>{
  const own=INTRA[t].side==='sheet'?shIn:gmIn;
  const sent=INTRA[t].side==='sheet'?shOut:gmOut;
  S.check('intra-app "'+t+'" is still actually sent',!!sent[t]);
  S.check('intra-app "'+t+'" is handled by its own app \u2014 '+INTRA[t].why,own.has(t));
});

/* --- field coverage ------------------------------------------------------
   Fields sent but never read at the far end. Nothing crashes; the payload
   simply arrives and is dropped. Some are deliberate, some are undecided —
   each carries its reason. Listed rather than asserted away so the set
   cannot grow quietly: a NEW unread field fails, and clearing one fails
   too, which is the prompt to update this list. */
const DEAD=[
  /* Kept deliberately, not gaps. The battle map already receives hp/mhp for
     every visible token via gmBattleSnapshot and draws the health bar from
     it; the attack result card omits the number by GM decision. */
  ['gm','pc_attack_result','targetHp',    'by design: HP is not shown in the result card'],
  ['gm','pc_attack_result','targetMaxHp', 'by design: the map health bar already covers this'],
];
const deadKey=(side,t,f)=>side+'|'+t+'|'+f;
const DEADSET=new Set(DEAD.map(d=>deadKey(d[0],d[1],d[2])));

let shFields=0, gmFields=0;
const found=new Set();
Object.keys(shOut).sort().forEach(t=>{
  if(INTRA[t]) return;
  [...shOut[t]].sort().forEach(f=>{
    shFields++;
    const ok=C.reads(gm,f), k=deadKey('sheet',t,f);
    if(!ok) found.add(k);
    if(!DEADSET.has(k)) S.check('sheet "'+t+'" field "'+f+'" is read by the GM',ok);
  });
});
Object.keys(gmOut).sort().forEach(t=>{
  if(INTRA[t]) return;
  [...gmOut[t]].sort().forEach(f=>{
    gmFields++;
    const ok=C.reads(sh,f), k=deadKey('gm',t,f);
    if(!ok) found.add(k);
    if(!DEADSET.has(k)) S.check('GM "'+t+'" field "'+f+'" is read by the sheet',ok);
  });
});
S.check('sheet payload fields audited ('+shFields+')',shFields>=40);
S.check('GM payload fields audited ('+gmFields+')',gmFields>=40);

/* the known-dead list must match reality exactly, in both directions */
DEAD.forEach(d=>S.check('still dead, as recorded: '+d[1]+'.'+d[2]+' \u2014 '+d[3],
  found.has(deadKey(d[0],d[1],d[2]))));
[...found].forEach(k=>S.check('unread field is a recorded one, not a new break: '+k,DEADSET.has(k)));
S.eq('the dead-payload count has not moved',found.size,DEAD.length);

/* --- regressions this suite exists to prevent ---------------------------- */
S.check('battle_state survives a !== guard on the sheet',shIn.has('battle_state'));
S.check('pc_condition round-trips',!!shOut.pc_condition&&gmIn.has('pc_condition'));
S.check('pc_roll round-trips',!!shOut.pc_roll&&gmIn.has('pc_roll'));
S.check('say round-trips',!!gmOut.say&&shIn.has('say'));
S.check('battle_fx nested a.gx is seen as a field',
  !!shOut.battle_fx&&[...shOut.battle_fx].indexOf('a.gx')>=0);
S.check('the fall-collision event reaches the GM log',
  !!shOut.event&&gmIn.has('event'));
/* wired this pass — these must stay read at the far end */
S.check('stunReq reaches the player',C.reads(sh,'stunReq'));
S.check('mounted reaches the GM',C.reads(gm,'mounted'));
S.check('staSpent reaches the GM',C.reads(gm,'staSpent'));
S.check('dmgFormula reaches the GM',C.reads(gm,'dmgFormula'));
S.check('the redundant attacker echo is gone from pc_attack_result',
  !(gmOut.pc_attack_result&&gmOut.pc_attack_result.has('attacker')));
S.check('spellKind reaches the player',C.reads(sh,'spellKind'));
S.check('attackDesc reaches the player',C.reads(sh,'attackDesc'));
S.check('the defend modal falls back to effect when attackDesc is absent',
  /m\.attackDesc\s*\|\|\s*m\.effect/.test(sh));
S.eq('only the two deliberate omissions remain unread',DEAD.length,2);
S.check('msg.attacker is still used GM-side for log lines',/msg\.attacker/.test(gm));

/* ── the shared world actually round-trips ──────────────────────────────
   Two players opening the inn generator used to get two different inns: it
   was rolled locally and never left the sheet. The shop reached only whoever
   was already in the room when somebody rerolled. */
const {boot}=require('../harness.js');
const W=boot('/home/claude/W/sheet.html');
setTimeout(function(){
  var ew=function(x){ try{ return W.dom.window.eval(x); }catch(e){ return 'THREW: '+e.message; } };
  ew('(function(){'
    +'window.toast=function(){};window.save=function(){};window.renderComp=function(){};'
    +'window.renderInnGenerator=function(){};window.renderTableLog=function(){};'
    +'window.syncLogLine=function(){};'
    +'window.__out=[]; window.syncSend=function(o){window.__out.push(o);};'
    +'window._sync={connected:true,name:"P",log:[],id:"x"};'
    +'return true;})()');
  S.check('the sheet can broadcast an inn',ew('typeof _broadcastInnState')==='function');
  S.check('and apply one it receives',ew('typeof _applyInnState')==='function');
  ew('window.__out=[]; _innSize="medium"; _innCity=false; rollInn();');
  var sent=JSON.parse(ew('JSON.stringify(window.__out)'));
  var msg=sent.filter(function(m){return m.t==='inn_state';})[0]||{};
  S.check('rolling an inn broadcasts it',!!msg.t);
  S.check('carrying its type and services',!!(msg.inn&&msg.inn.type&&msg.inn.services));
  S.check('its rooms',!!(msg.inn&&msg.inn.rooms));
  S.check('and the talk of the Continent',!!(msg.inn&&msg.inn.talk));
  var mine=ew('JSON.stringify(_innResult)');
  ew('_innResult=null');
  ew('syncHandleMsg(JSON.stringify('+JSON.stringify(msg)+'))');
  S.eq('applying it reproduces the inn exactly',ew('JSON.stringify(_innResult)'),mine);
  ['clearInn()','setInnSize("large")','toggleInnCity()'].forEach(function(call){
    ew('window.__out=[]; '+call+';');
    S.check(call+' is broadcast',
      JSON.parse(ew('JSON.stringify(window.__out)')).some(function(m){return m.t==='inn_state';}));
  });
  ew('window.__out=[]; rollInn(); setShopTier(2); window.__out=[];');
  ew('syncHandleMsg(JSON.stringify({t:"state_please"}))');
  var reply=JSON.parse(ew('JSON.stringify(window.__out)')).map(function(m){return m.t;});
  S.check('a late joiner asking for state gets the shop',reply.indexOf('shop_state')>=0);
  S.check('and gets the inn',reply.indexOf('inn_state')>=0);
  process.exit(S.report()?0:1);
},5200);

