/* Suite 08 — The sync contract.
   Every message one app sends must be dispatched on at the other end, and
   every payload field must actually be read there. A feature wired at only
   one end is silent: nothing throws, nothing logs, it simply never happens.
   Three of those were found by hand last session (pc_condition, pc_roll,
   say); this suite is so the next one is found by the runner instead. */
const {Suite}=require('../harness.js');
const C=require('../synccontract.js');
const S=Suite('08 sync-contract');

const gm=C.js('/home/claude/W/gm.html');
const sh=C.js('/home/claude/W/sheet.html');
const gmOut=C.outbound(gm,'gmSyncSend');
const shOut=C.outbound(sh,'syncSend');
const gmIn=C.handled(gm), shIn=C.handled(sh);

/* Traffic that deliberately does not cross to the other app. Anything listed
   here must still be dispatched on by its OWN app, which is asserted below —
   otherwise this list would be a place to hide genuinely dead features. */
const INTRA={
  shop_state:{ side:'sheet', why:'players sync shop stock to each other over the broadcast; the GM is not a party to it' },
  inn_state:{ side:'sheet', why:'the rolled inn is shared between players so everyone sees the same rooms, services and talk; the GM tracker has no inn' },
  state_please:{ side:'sheet', why:'a late joiner asks the room for the shared world state and whoever is present answers; sheet-to-sheet only' }
};

/* --- the extractor itself must not fail open ------------------------------
   A source-derived audit that silently matches nothing would pass every
   assertion below, so floor it against the known shape of the apps. */
S.check('GM script extracted ('+gm.length+' chars)',gm.length>1000000);
S.check('sheet script extracted ('+sh.length+' chars)',sh.length>1000000);
S.check('GM sends a plausible number of message types ('+Object.keys(gmOut).length+')',
  Object.keys(gmOut).length>=20);
S.check('sheet sends a plausible number of message types ('+Object.keys(shOut).length+')',
  Object.keys(shOut).length>=20);
S.check('GM dispatches on a plausible number of types ('+gmIn.size+')',gmIn.size>=40);
S.check('sheet dispatches on a plausible number of types ('+shIn.size+')',shIn.size>=40);
S.check('known types are found (battle_move)',!!shOut.battle_move);
S.check('known types are found (battle_toks)',!!gmOut.battle_toks);

/* --- type coverage, both directions -------------------------------------- */
Object.keys(shOut).sort().forEach(t=>{
  if(INTRA[t]) return;
  S.check('sheet sends "'+t+'" and the GM dispatches on it',gmIn.has(t));
});
Object.keys(gmOut).sort().forEach(t=>{
  if(INTRA[t]) return;
  S.check('GM sends "'+t+'" and the sheet dispatches on it',shIn.has(t));
});

/* --- the whitelist has to stay honest ------------------------------------ */
Object.keys(INTRA).forEach(t=>{
  const own=INTRA[t].side==='sheet'?shIn:gmIn;
  const sent=INTRA[t].side==='sheet'?shOut:gmOut;
  S.check('intra-app "'+t+'" is still actually sent',!!sent[t]);
  S.check('intra-app "'+t+'" is handled by its own app \u2014 '+INTRA[t].why,own.has(t));
});

/* --- field coverage ------------------------------------------------------
   Fields sent but never read at the far end. Nothing crashes; the payload
   simply arrives and is dropped. Some are deliberate, some are undecided —
   each carries its reason. Listed rather than asserted away so the set
   cannot grow quietly: a NEW unread field fails, and clearing one fails
   too, which is the prompt to update this list. */
const DEAD=[
  /* Kept deliberately, not gaps. The battle map already receives hp/mhp for
     every visible token via gmBattleSnapshot and draws the health bar from
     it; the attack result card omits the number by GM decision. */
  ['gm','pc_attack_result','targetHp',    'by design: HP is not shown in the result card'],
  ['gm','pc_attack_result','targetMaxHp', 'by design: the map health bar already covers this'],
];
const deadKey=(side,t,f)=>side+'|'+t+'|'+f;
const DEADSET=new Set(DEAD.map(d=>deadKey(d[0],d[1],d[2])));

let shFields=0, gmFields=0;
const found=new Set();
Object.keys(shOut).sort().forEach(t=>{
  if(INTRA[t]) return;
  [...shOut[t]].sort().forEach(f=>{
    shFields++;
    const ok=C.reads(gm,f), k=deadKey('sheet',t,f);
    if(!ok) found.add(k);
    if(!DEADSET.has(k)) S.check('sheet "'+t+'" field "'+f+'" is read by the GM',ok);
  });
});
Object.keys(gmOut).sort().forEach(t=>{
  if(INTRA[t]) return;
  [...gmOut[t]].sort().forEach(f=>{
    gmFields++;
    const ok=C.reads(sh,f), k=deadKey('gm',t,f);
    if(!ok) found.add(k);
    if(!DEADSET.has(k)) S.check('GM "'+t+'" field "'+f+'" is read by the sheet',ok);
  });
});
S.check('sheet payload fields audited ('+shFields+')',shFields>=40);
S.check('GM payload fields audited ('+gmFields+')',gmFields>=40);

/* the known-dead list must match reality exactly, in both directions */
DEAD.forEach(d=>S.check('still dead, as recorded: '+d[1]+'.'+d[2]+' \u2014 '+d[3],
  found.has(deadKey(d[0],d[1],d[2]))));
[...found].forEach(k=>S.check('unread field is a recorded one, not a new break: '+k,DEADSET.has(k)));
S.eq('the dead-payload count has not moved',found.size,DEAD.length);

/* --- regressions this suite exists to prevent ---------------------------- */
S.check('battle_state survives a !== guard on the sheet',shIn.has('battle_state'));
S.check('pc_condition round-trips',!!shOut.pc_condition&&gmIn.has('pc_condition'));
S.check('pc_roll round-trips',!!shOut.pc_roll&&gmIn.has('pc_roll'));
S.check('say round-trips',!!gmOut.say&&shIn.has('say'));
S.check('battle_fx nested a.gx is seen as a field',
  !!shOut.battle_fx&&[...shOut.battle_fx].indexOf('a.gx')>=0);
S.check('the fall-collision event reaches the GM log',
  !!shOut.event&&gmIn.has('event'));
/* wired this pass — these must stay read at the far end */
S.check('stunReq reaches the player',C.reads(sh,'stunReq'));
S.check('mounted reaches the GM',C.reads(gm,'mounted'));
S.check('staSpent reaches the GM',C.reads(gm,'staSpent'));
S.check('dmgFormula reaches the GM',C.reads(gm,'dmgFormula'));
S.check('the redundant attacker echo is gone from pc_attack_result',
  !(gmOut.pc_attack_result&&gmOut.pc_attack_result.has('attacker')));
S.check('spellKind reaches the player',C.reads(sh,'spellKind'));
S.check('attackDesc reaches the player',C.reads(sh,'attackDesc'));
S.check('the defend modal falls back to effect when attackDesc is absent',
  /m\.attackDesc\s*\|\|\s*m\.effect/.test(sh));
S.eq('only the two deliberate omissions remain unread',DEAD.length,2);
S.check('msg.attacker is still used GM-side for log lines',/msg\.attacker/.test(gm));

/* ── the shared world actually round-trips ──────────────────────────────
   Two players opening the inn generator used to get two different inns: it
   was rolled locally and never left the sheet. The shop reached only whoever
   was already in the room when somebody rerolled. */
const {boot}=require('../harness.js');
const W=boot('/home/claude/W/sheet.html');
setTimeout(function(){
  var ew=function(x){ try{ return W.dom.window.eval(x); }catch(e){ return 'THREW: '+e.message; } };
  ew('(function(){'
    +'window.toast=function(){};window.save=function(){};window.renderComp=function(){};'
    +'window.renderInnGenerator=function(){};window.renderTableLog=function(){};'
    +'window.syncLogLine=function(){};'
    +'window.__out=[]; window.syncSend=function(o){window.__out.push(o);};'
    +'window._sync={connected:true,name:"P",log:[],id:"x"};'
    +'return true;})()');
  S.check('the sheet can broadcast an inn',ew('typeof _broadcastInnState')==='function');
  S.check('and apply one it receives',ew('typeof _applyInnState')==='function');
  ew('window.__out=[]; _innSize="medium"; _innCity=false; rollInn();');
  var sent=JSON.parse(ew('JSON.stringify(window.__out)'));
  var msg=sent.filter(function(m){return m.t==='inn_state';})[0]||{};
  S.check('rolling an inn broadcasts it',!!msg.t);
  S.check('carrying its type and services',!!(msg.inn&&msg.inn.type&&msg.inn.services));
  S.check('its rooms',!!(msg.inn&&msg.inn.rooms));
  S.check('and the talk of the Continent',!!(msg.inn&&msg.inn.talk));
  var mine=ew('JSON.stringify(_innResult)');
  ew('_innResult=null');
  ew('syncHandleMsg(JSON.stringify('+JSON.stringify(msg)+'))');
  S.eq('applying it reproduces the inn exactly',ew('JSON.stringify(_innResult)'),mine);
  ['clearInn()','setInnSize("large")','toggleInnCity()'].forEach(function(call){
    ew('window.__out=[]; '+call+';');
    S.check(call+' is broadcast',
      JSON.parse(ew('JSON.stringify(window.__out)')).some(function(m){return m.t==='inn_state';}));
  });
  ew('window.__out=[]; rollInn(); setShopTier(2); window.__out=[];');
  ew('syncHandleMsg(JSON.stringify({t:"state_please"}))');
  var reply=JSON.parse(ew('JSON.stringify(window.__out)')).map(function(m){return m.t;});
  S.check('a late joiner asking for state gets the shop',reply.indexOf('shop_state')>=0);
  S.check('and gets the inn',reply.indexOf('inn_state')>=0);

  /* ── the in-game clock ────────────────────────────────────────────────
     Nothing tracked days, so nothing could expire \u2014 shop stock resetting
     every three days had nothing to count against. */
  var C1=boot('/home/claude/W/gm.html');
  setTimeout(function(){
    var eg=function(x){ try{ return C1.dom.window.eval(x); }catch(e){ return 'THREW: '+e.message; } };
    eg('window.gmBattleToast=function(){};window.__out=[];window.gmSyncSend=function(o){window.__out.push(o);};window._sync={connected:true,client:{},name:"GM",id:"g"};');
    S.check('the GM has a clock',eg('typeof gmClock')==='function');
    /* A feature only reachable from the console is not a feature. */
    ['clock-watch','clock-day','clock-set'].forEach(function(a){
      S.check('the toolbar exposes "'+a+'"',
        eg('document.documentElement.innerHTML.indexOf('+JSON.stringify(a)+')>=0')===true);
    });
    S.check('and the date renders somewhere the GM can see it',
      eg('typeof gmClockRender')==='function');
    S.eq('it starts on day 1 at dawn',eg('gmClockLabel()'),'Day 1 \u00b7 dawn');
    S.eq('a watch advances',eg('gmClockAdvance(1)'),'Day 1 \u00b7 morning');
    S.eq('five watches make a day',eg('gmClockAdvance(4)'),'Day 2 \u00b7 dawn');
    S.eq('days can be skipped',eg('gmClockAdvanceDays(3)'),'Day 5 \u00b7 dawn');
    S.eq('and set outright',eg('gmClockSet(12,3)'),'Day 12 \u00b7 dusk');
    var out=JSON.parse(eg('JSON.stringify(window.__out)'));
    S.check('every change is broadcast',out.length>=4);
    var last=out[out.length-1];
    S.eq('carrying the day',last.day,12);
    S.eq('and the watch',last.watch,3);
    ew('syncHandleMsg(JSON.stringify('+JSON.stringify(last)+'))');
    S.eq('the sheet lands on the same date',ew('pcClockLabel()'),'Day 12 \u00b7 dusk');
    S.check('and exposes a stamp for things that expire',
      ew('typeof pcClockStamp')==='function' && ew('pcClockStamp()') > 0);
    S.check('the saved date survives a reload',
      eg(`(function(){
        gmClockSet(7,2); gmClockSave();
        window._gmClock=null;
        gmClockLoad();
        return gmClock().day===7 && gmClock().watch===2;})()`)===true);
    S.check('shop stock knows its own age',ew('typeof _shopStockStale')==='function');
    S.check('fresh stock is not stale',
      ew('(function(){char._shopStamp=12;char._clock={day:13,watch:0};return _shopStockStale();})()')===false);
    S.check('stock older than three days is',
      ew('(function(){char._shopStamp=12;char._clock={day:15,watch:0};return _shopStockStale();})()')===true);
    S.check('never-stocked counts as stale',
      ew('(function(){char._shopStamp=null;return _shopStockStale();})()')===true);
  /* ── settlements ─────────────────────────────────────────────────────
     Stock was one global set, so a hamlet and a capital handed the party the
     same shelf, and returning to a town rerolled it from scratch. */
    S.check('city sizes exist',ew('typeof CITY_SIZES')==='object');
    S.check('a settlement can be set',ew('typeof pcCitySet')==='function');
    const shelf=function(id,nm,t){
      return JSON.parse(ew(`(function(){
        char._clock={day:1,watch:0}; char._shopStamp=null;
        window.renderComp=function(){}; window.syncSend=function(){};
        pcCitySet(${JSON.stringify(id)},${JSON.stringify(nm)},${t});
        return JSON.stringify({label:pcCityLabel(),
          shops:Object.keys(_lanStock).length,
          items:Object.keys(_lanStock).reduce(function(a,k){
            return a+(_lanStock[k].size||0);},0)});})()`));
    };
    const hamlet=shelf('h','Hamlet Test',1);
    const town=shelf('t','Town Test',2);
    const city=shelf('c','City Test',3);
    S.check('a hamlet has fewer shops than a town ('+hamlet.shops+' vs '+town.shops+')',
      hamlet.shops < town.shops);
    S.check('a town fewer than a city ('+town.shops+' vs '+city.shops+')',
      town.shops < city.shops);
    S.check('and fewer items on the shelf ('+hamlet.items+' / '+town.items+' / '+city.items+')',
      hamlet.items < town.items && town.items < city.items);
    S.check('the label names the size',/Hamlet/.test(hamlet.label));
    S.check('returning inside the window keeps the same shelf',
      ew(`(function(){
        char._clock={day:1,watch:0}; char._shopStamp=null;
        window.renderComp=function(){}; window.syncSend=function(){};
        pcCitySet('a','A',1);
        var first=JSON.stringify(_serializeStock());
        pcCitySet('b','B',2);
        pcCitySet('a','A',1);
        return JSON.stringify(_serializeStock())===first;})()`)===true);
    S.check('and past three days it restocks',
      ew(`(function(){
        window.renderComp=function(){}; window.syncSend=function(){};
        char._clock={day:1,watch:0}; char._shopStamp=null;
        pcCitySet('z','Z',3);
        var first=JSON.stringify(_serializeStock());
        char._clock={day:9,watch:0};
        pcCitySet('z','Z',3);
        return JSON.stringify(_serializeStock())!==first;})()`)===true);
    /* Two bugs found by probing rather than by use:
       parseInt(0)||1 made gmClockAdvance(0) advance a watch, and the stock
       cache was keyed on settlement alone, so promoting a hamlet to a city
       kept its two-shop shelf. */
    S.check('advancing zero watches is a no-op',
      eg(`(function(){ gmClockSet(5,2); var a=gmClockLabel();
        gmClockAdvance(0); return gmClockLabel()===a;})()`)===true);
    S.check('advancing zero days is a no-op',
      eg(`(function(){ gmClockSet(5,2); var a=gmClockLabel();
        gmClockAdvanceDays(0); return gmClockLabel()===a;})()`)===true);
    S.check('a negative advance is a no-op too',
      eg(`(function(){ gmClockSet(5,2); var a=gmClockLabel();
        gmClockAdvance(-3); return gmClockLabel()===a;})()`)===true);
    S.check('the stock cache is keyed by tier as well as settlement',
      ew(`(function(){
        window.renderComp=function(){}; window.syncSend=function(){};
        char._clock={day:1,watch:0}; char._shopStamp=null;
        pcCitySet('probe','Probe',1);
        var small=Object.keys(_lanStock).length;
        pcCitySet('probe','Probe',3);
        var big=Object.keys(_lanStock).length;
        return big>small;})()`)===true);
    S.check('the settlement travels with the stock in the sync',
      ew(`(function(){
        window.__out=[]; window.syncSend=function(o){window.__out.push(o);};
        window.renderComp=function(){};
        pcCitySet('q','Qtown',2);
        var m=window.__out.filter(function(x){return x.t==='shop_state';}).pop();
        return !!(m && m.city==='q' && m.cityName==='Qtown' && m.tier===2);})()`)===true);

    S.check('the garden forage rolls Wilderness Survival, not bare INT',
      ew(`(function(){
        char.skills['Wilderness Survival']={val:6}; char.stats.INT=8;
        char.inventory=[]; char._forageYield=3;
        window.renderInventory=function(){}; window.renderComp=function(){};
        lanExeterForage('Celandine');
        return /Wilderness Survival/.test(String(window._lastForage));})()`)===true);
    /* The whole trap array was withheld from players, which is right for a
       trap they have not spotted and wrong for one they have \u2014 the GM knew
       and the party did not, so somebody walks a token into a pit they found
       two rounds ago. Only found traps cross. */
    var T1=boot('/home/claude/W/gm.html');
    setTimeout(function(){
      var et=function(x){ try{ return T1.dom.window.eval(x); }catch(e){ return 'THREW: '+e.message; } };
      et('window.gmBattleToast=function(){};window.gmBattleTouch=function(){};window.gmBattleUndoPush=function(){};window.gmBroadcastRoster=function(){};window.gmSyncSend=function(){};window.logRoll=function(){};window.renderCombatants=function(){};window.gmBroadcastInitiative=function(){};window._gmBUi={};window._gmBView=null;window._gmB={toks:[],stamps:[],levels:[{n:"G"}],lvl:0,w:20,h:20};');
      et('combatants.length=0;gmBattleLoadScene("loch_eskalott",false);');
      S.check('a scene with traps loads them',et('(window._gmB.traps||[]).length')>=2);
      S.eq('an unfound trap does not reach the party',
        et('(gmBattleSnapshot().traps||[]).length'),0);
      et('gmBattleAct("trap-found");');
      S.check('once found, it does',et('(gmBattleSnapshot().traps||[]).length')>=2);
      S.check('carrying its label and its detection note',
        et(`(function(){
          var t=(gmBattleSnapshot().traps||[])[0];
          return !!(t && t.label && t.dmg && t.x!=null && t.r);})()`)===true);
      et('gmBattleAct("trap-hide");');
      S.eq('and the GM can hide them again',
        et('(gmBattleSnapshot().traps||[]).length'),0);
      S.check('the toggle is reachable from the toolbar',
        et('document.documentElement.innerHTML.indexOf("trap-found")>=0')===true);
      S.check('the sheet has a renderer for them',
        ew('typeof pcFoundTrapHTML')==='function');
      S.check('which draws a marker per trap on the right level',
        ew(`(function(){
          var t=[{i:'a',x:10,y:10,r:2,label:'Pit',dmg:'5d6',lv:0},
                 {i:'b',x:4,y:4,r:1,label:'Wire',dmg:'2d6',lv:1}];
          var a=pcFoundTrapHTML(t,0), b=pcFoundTrapHTML(t,1);
          return (a.match(/<div/g)||[]).length===1
              && (b.match(/<div/g)||[]).length===1
              && /Pit/.test(a) && /Wire/.test(b);})()`)===true);
      S.check('and nothing at all when none are found',
        ew('pcFoundTrapHTML([],0)')==='');
      process.exit(S.report()?0:1);
    },5200);
},5200);
},5200);
