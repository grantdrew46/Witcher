/* Suite 07 — Charging & Ramming (pg.171)
   "To calculate this extra damage, divide the number of meters between you and
    your target by 2, (rounded down and capped at 5). Add this number of d6s to
    your damage. If you are galloping on your horse, assume your number is 5."
   The gap is measured between charger and target, not the run-up, so the board
   can supply it. One cell is 2 m, so the cap is reached at exactly 5 cells. */
const {boot,Suite}=require('../harness.js');
const S=Suite('07 charge (pg.171)');
const {dom,errs}=boot('/home/claude/W/sheet.html');

setTimeout(()=>{
  const ev=s=>dom.window.eval(s);
  S.check('boot clean',errs.length===0);

  const stub=`(function(){
    window.__html=''; window.__toast='';
    window._mountState=function(){ return {name:'War horse', mount:{distance:''}}; };
    window.getMountStats=function(){ return {ram:'4d6'}; };
    window.openModal=function(h){ window.__html=h; };
    window.toast=function(t){ window.__toast=t; };
    window.pcBattleToast=function(t){ window.__toast=t; };
    window._pcB={ open:true, awaitTarget:null, toks:[
      {i:1,n:'Merrick',x:10,y:10,lv:0,sz:1},
      {i:2,n:'Target', x:10,y:10,lv:0,sz:1}] };
    window.pcBattleMyTok=function(){ return window._pcB.toks[0]; };
    window.pcBattleTok=function(id){ return window._pcB.toks.filter(function(t){return t.i===id;})[0]; };
    return true; })()`;
  ev(stub);

  const dice=()=>{const h=ev('window.__html');
    let m=/(\d+)d6<\/strong> \(distance/.exec(h);
    if(!m) m=/--gold-l\)">(\d+)d6<\/strong> regardless/.exec(h);
    return m?parseInt(m[1],10):null;};
  const metres=()=>{const m=/from <strong>(\d+)m<\/strong>/.exec(ev('window.__html')); return m?parseInt(m[1],10):null;};
  const tapAt=(dx,dy)=>{ ev('window.__html="";window._pcB.toks[1].x=10+'+dx+';window._pcB.toks[1].y=10+'+dy+';'
    +'window._pcB.awaitTarget={kind:"charge",idx:0};pcResolveChargeTarget(2)'); };

  /* 1. arming does not open the modal — it waits for the tap */
  ev('window.__html="";window._pcB.awaitTarget=null;rollMountCharge(0)');
  S.eq('arming sets a charge awaitTarget',ev('(window._pcB.awaitTarget||{}).kind'),'charge');
  S.check('arming does not open the modal early',ev('window.__html')==='');
  S.check('arming prompts for a tap',/[Tt]ap your target/.test(ev('window.__toast')));

  /* 2. one cell is 2 m, cap reached at 5 cells */
  [[1,2,1],[2,4,2],[3,6,3],[4,8,4],[5,10,5],[7,14,5],[12,24,5]].forEach(([cells,m,d])=>{
    tapAt(cells,0);
    S.eq(cells+' cells measures '+m+'m',metres(),m);
    S.eq(cells+' cells gives '+d+'d6',dice(),d);
  });
  /* diagonals use the same metric as the rest of the board */
  tapAt(3,4);  S.eq('a 3,4 diagonal is 10m (5 cells)',metres(),10);
  S.eq('and caps at 5d6',dice(),5);

  /* 3. adjacent is too close to gain anything */
  tapAt(1,0);
  S.eq('an adjacent target is 2m',metres(),2);
  S.eq('2m still yields 1d6',dice(),1);

  /* 4. the tap clears the armed state so the next tap is a normal selection */
  S.eq('awaitTarget is cleared after measuring',ev('window._pcB.awaitTarget'),null);

  /* 5. galloping overrides the gap entirely */
  [0,2,4,6,8,10,30].forEach(d=>{
    ev('_openChargeModal(0,'+d+',"T",true)');
    S.eq('galloping at '+d+'m is 5d6',dice(),5);
  });
  ev('_openChargeModal(0,6,"T",true)');
  S.check('galloping is labelled as overriding the gap',/regardless of the gap/.test(ev('window.__html')));
  S.check('galloping cites the page',/pg\.171/.test(ev('window.__html')));
  ev('_openChargeModal(0,6,"T",false)');
  S.eq('same gap without galloping is 3d6',dice(),3);
  S.check('a galloping toggle is offered',/Galloping \(5d6\)/.test(ev('window.__html')));

  /* 6. guards */
  ev('window.__toast="";window._pcB.awaitTarget={kind:"charge",idx:0};pcResolveChargeTarget(1)');
  S.check('you cannot charge yourself',/somebody else/i.test(ev('window.__toast')));
  ev('window.__toast="";window._pcB.awaitTarget={kind:"charge",idx:0};pcResolveChargeTarget(999)');
  S.check('a tap on empty ground is rejected',/No target there/i.test(ev('window.__toast')));

  /* 7. manual entry still works away from the map */
  ev('window._pcB.open=false;window.__html="";'
    +'window._mountState=function(){return {name:"Horse",mount:{distance:"9"}};};rollMountCharge(0)');
  S.eq('manual 9m gives 4d6',dice(),4);
  S.eq('manual distance is echoed',metres(),9);
  ev('window.__toast="";window.__html="";'
    +'window._mountState=function(){return {name:"Horse",mount:{distance:""}};};rollMountCharge(0)');
  S.check('blank manual distance asks for one',/Enter a distance/.test(ev('window.__toast')));
  S.check('and does not open a modal',ev('window.__html')==='');

  /* 8. weight modifiers still match the book */
  ev('window._pcB.open=false;window._mountState=function(){return {name:"Horse",mount:{distance:"10"}};};'
    +'_openChargeModal(0,10,"T",false)');
  const h=ev('window.__html');
  [['Very Light','\u00d7\u00bd'],['Light','\u00d71'],['Medium','\u00d72'],['Heavy','\u00d73']].forEach(([lbl,mult])=>
    S.check('weight class '+lbl+' '+mult+' present',h.indexOf(lbl)>=0&&h.indexOf(mult)>=0));

  process.exit(S.report()?0:1);
},5000);
