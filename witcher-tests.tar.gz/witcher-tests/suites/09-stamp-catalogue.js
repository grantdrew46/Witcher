/* Suite 09 — Stamp catalogue and art library.
   Three things this guards:
     - every embedded prop image must be reachable from a placeable kind.
       22 of 108 were not; roughly 1 MiB shipped in every load unusable.
     - every kind must carry a category, or it falls out of the grouped picker.
     - every kind that costs movement must explain why. */
const {boot,Suite}=require('../harness.js');
const S=Suite('09 stamp-catalogue');
const A=boot('/home/claude/W/gm.html');
const B=boot('/home/claude/W/sheet.html');

setTimeout(()=>{
  const ea=s=>A.dom.window.eval(s), eb=s=>B.dom.window.eval(s);
  S.check('gm boots clean',A.errs.length===0);
  S.check('sheet boots clean',B.errs.length===0);

  /* 1. categories */
  S.check('every kind carries a category',ea('WB.KINDS.every(function(k){return !!k.cat;})'));
  S.check('every category has a label',
    ea('WB.KINDS.every(function(k){return !!(WB.KIND_CATS&&WB.KIND_CATS[k.cat]);})'));
  S.check('CAT_ORDER covers every category in use',
    ea('(function(){var u={};WB.KINDS.forEach(function(k){u[k.cat]=1;});'
      +'return Object.keys(u).every(function(c){return WB.CAT_ORDER.indexOf(c)>=0;});})()'));
  S.check('no category is empty',
    ea('WB.CAT_ORDER.every(function(c){return WB.KINDS.some(function(k){return k.cat===c;});})'));
  S.check('terrain edge decals are their own group, not mixed with furniture',
    ea('WB.KINDS.filter(function(k){return k.k.indexOf("edge_")===0;})'
      +'.every(function(k){return k.cat==="edge";})'));
  S.check('kind count is plausible ('+ea('WB.KINDS.length')+')',ea('WB.KINDS.length')>=145);
  S.check('kind keys are unique',
    ea('(function(){var s={},d=0;WB.KINDS.forEach(function(k){if(s[k.k])d++;s[k.k]=1;});return d===0;})()'));

  /* 2. no art may be unreachable, in either file */
  const orphans=f=>f(`(function(){
    var reach={};
    WB.KINDS.forEach(function(k){
      [[1,1],[2,1],[1,2]].forEach(function(d){
        var p=null; try{ p=WB.propFor(k.k,d[0],d[1]); }catch(e){}
        if(p&&p.name) reach[p.name]=1;
      });
    });
    var out=[];
    ['PROPDATA','PROP2DATA','PROP3DATA','STRUCTDATA'].forEach(function(L){
      if(!WB[L]) return;
      Object.keys(WB[L]).forEach(function(n){ if(!reach[n]) out.push(L+'/'+n); });
    });
    return out;
  })()`);
  const oa=orphans(ea), ob=orphans(eb);
  S.eq('no unreachable art in gm ('+oa.join(',')+')',oa.length,0);
  S.eq('no unreachable art in sheet ('+ob.join(',')+')',ob.length,0);

  /* 3. every kind resolves to something drawable */
  const undrawable=f=>f(`(function(){
    var out=[];
    WB.KINDS.forEach(function(k){
      var p=null; try{ p=WB.propFor(k.k,1,1); }catch(e){}
      if(p) return;
      if(WB.ART&&WB.ART[k.k]) return;
      if(WB.ARTFILL&&WB.ARTFILL[k.k]) return;
      if(WB.TEXMAP&&WB.TEXMAP[k.k]) return;
      if(WB.TERRAIN_EDGE&&WB.TERRAIN_EDGE[k.k]) return;
      if(k.t==='fill'&&k.c) return;          /* plain colour fill is a valid look */
      out.push(k.k);
    });
    return out;
  })()`);
  S.eq('every kind draws as something (gm) ['+undrawable(ea).join(',')+']',undrawable(ea).length,0);

  /* 4. the newly wired pieces really resolve to art */
  ['glassfurnace','crucible','minecart','winch','portcullis','archway','pillar','post',
   'fireplace','partition','balcony','roofedge','chimney','wallcorner','doorframe',
   'chest_iron','chest_small','chest_broken','body_soldier','body_animal','bones_pile'
  ].forEach(k=>{
    S.check('"'+k+'" is placeable',!!ea('WB.kind('+JSON.stringify(k)+')'));
    S.check('"'+k+'" resolves to art',ea('!!WB.propFor('+JSON.stringify(k)+',1,1)'));
  });

  /* 5. the five new assets, present and identical in both files */
  ['ritualcircle','altar','cauldron','spiderweb','hedge'].forEach(k=>{
    S.check('new art "'+k+'" is in PROP3DATA',ea('!!WB.PROP3DATA['+JSON.stringify(k)+']'));
    S.check('new art "'+k+'" has meta',ea('!!WB.PROP3META['+JSON.stringify(k)+']'));
    S.check('new art "'+k+'" resolves through propFor',ea('!!WB.propFor('+JSON.stringify(k)+',1,1)'));
    S.eq('new art "'+k+'" identical in both files',
      ea('WB.PROP3DATA['+JSON.stringify(k)+'].length'),
      eb('WB.PROP3DATA['+JSON.stringify(k)+'].length'));
    S.check('new art "'+k+'" is webp',
      /^data:image\/webp;base64,/.test(ea('WB.PROP3DATA['+JSON.stringify(k)+'].slice(0,30)')));
  });
  ['ritualcircle','altar','cauldron','spiderweb'].forEach(k=>
    S.check('"'+k+'" is placeable as a kind',!!ea('WB.kind('+JSON.stringify(k)+')')));
  S.check('hedge keeps its fill type so existing maps are unaffected',
    ea('WB.kind("hedge").t')==='fill');

  /* 6. anything that costs movement must say why */
  const mute=ea('Object.keys(WB.SLOW).filter(function(k){return !WB.TERRAIN[k];})');
  S.eq('no silent movement penalties ['+mute.join(',')+']',mute.length,0);
  S.check('terrain text is present in both files',
    ea('Object.keys(WB.TERRAIN).length')===eb('Object.keys(WB.TERRAIN).length'));
  S.check('book-backed entries cite a page',
    ea('["marsh","tallgrass","thornbush","deepwater","swamp","water","ice","snow"]'
      +'.every(function(k){return /pg\\.\\d+/.test(WB.TERRAIN[k].t);})'));
  S.check('invented entries are marked with the cog',
    ea('["mud","rubble","rubblescatter","snowdrift","furrows","strawfloor"]'
      +'.every(function(k){return WB.TERRAIN[k].t.indexOf("\\u2699")>=0;})'));

  /* 6b. pg.47 Witcher Training eases environmental penalties by half the
     skill value, minimum 1, and can cancel one but never invert it. */
  S.check('witcherRelief is defined in both files',
    ea('typeof WB.witcherRelief')==='function'&&eb('typeof WB.witcherRelief')==='function');
  [[0,1],[1,1],[2,1],[3,1],[4,2],[5,2],[6,3],[7,3],[8,4],[11,5]].forEach(([wt,r])=>
    S.eq('Witcher Training '+wt+' relieves '+r,ea('WB.witcherRelief('+wt+')'),r));
  S.eq('a negative skill value still relieves the minimum',ea('WB.witcherRelief(-3)'),1);
  S.eq('a missing skill value still relieves the minimum',ea('WB.witcherRelief(null)'),1);

  const pen=(k,wt,w)=>ea('JSON.stringify(WB.terrainPenaltyFor('+JSON.stringify(k)+','+wt+','+w+'))');
  S.eq('a non-Witcher gets no relief',JSON.parse(pen('swamp',8,false)).relief,0);
  S.eq('a non-Witcher feels the full penalty',JSON.parse(pen('swamp',8,false)).eased,2);
  S.eq('Witcher Training 1 eases -2 to -1',JSON.parse(pen('swamp',1,true)).eased,1);
  S.eq('Witcher Training 4 cancels -2',JSON.parse(pen('swamp',4,true)).eased,0);
  S.eq('relief never inverts the penalty',JSON.parse(pen('swamp',20,true)).eased,0);
  S.eq('relief is capped at the penalty itself',JSON.parse(pen('swamp',20,true)).relief,2);
  ['swamp','hedge','marsh','tallgrass','thornbush','water','deepwater'].forEach(k=>
    S.check('"'+k+'" carries a reducible penalty',ea('!!WB.TERRAIN_PENALTY['+JSON.stringify(k)+']')));
  ['ice','snow'].forEach(k=>
    S.eq('"'+k+'" sets a DC, not a penalty, so it is not reduced',pen(k,8,true),'null'));
  ['mud','rubble','snowdrift','furrows','strawfloor','rubblescatter'].forEach(k=>
    S.eq('"'+k+'" is our own movement cost and is not reduced',pen(k,8,true),'null'));
  S.check('every penalty key is a real terrain kind',
    ea('Object.keys(WB.TERRAIN_PENALTY).every(function(k){return !!WB.TERRAIN[k];})'));
  S.check('the banner cites pg.47',/pg\.47/.test(eb('String(pcBattleTerrainBanner)')));
  S.check('a cancelled penalty is not printed as "-0"',
    !/eases to \\u2212' \+ 0/.test(eb('String(pcBattleTerrainBanner)')));

  /* ── scenes ───────────────────────────────────────────────────────────
     Five saved scenes were built with kind names that were never defined —
     'hearth', 'table_long', 'table_round' — which resolved to no kind, no
     art, no fill and no cover. A barracks hearth rendered as an empty div
     and stopped nothing. */
  S.eq('no scene names a kind that does not exist',
    ea(`(function(){var b=[];BATTLE_SCENES.forEach(function(s){(s.st||[]).forEach(function(e){
      if(!WB.kind(e[0]) && b.indexOf(e[0])<0) b.push(s.id+':'+e[0]); });});return b;})()`).length,0);
  /* Six textures the GM generated, plus aliases for the names that get reached
     for in practice. Twelve separate scenes shipped with an invented kind that
     rendered as flat colour; the aliases end that class of error. */
  /* Twenty textures were base64'd into both files and TEXMAP never pointed at
     one of them \u2014 so 277 wall segments across every scene rendered as flat
     colour while their art sat unused in the same file. */
  ['stonewall','timberwall','shingles','thatchroof','slateroof','burnt','sootstone',
   'minestone','tiledfloor','strawfloor','plankfloor','leaflitter','furrows','marsh',
   'bloodsnow','bloodearth','mosaic','frozenwater','pineneedle','sand_wet'].forEach(k=>{
    S.check('"'+k+'" texture is reachable',
      ea(`(function(){var n=WB.TEXMAP[${JSON.stringify(k)}];
        return !!(n && ((WB.TEX2DATA&&WB.TEX2DATA[n])||(WB.TEXDATA&&WB.TEXDATA[n])));})()`)===true);
  });
  /* art + a TEXMAP entry is not enough \u2014 a name also has to be a registered
     kind or a scene cannot use it at all */
  S.eq('every mapped texture is also a usable kind',
    ea(`Object.keys(WB.TEXMAP||{}).filter(function(k){ return !WB.kind(k); })`).length,0);
  S.check('no texture in the file is unreachable through TEXMAP',
    ea(`(function(){
      var all=[].concat(Object.keys(WB.TEXDATA||{}),Object.keys(WB.TEX2DATA||{}));
      var reached={};
      Object.keys(WB.TEXMAP||{}).forEach(function(k){ reached[WB.TEXMAP[k]]=1; });
      return all.filter(function(n){ return !reached[n]; });})()`).length,0);

  ['reeds','forest','stonepath','turnedearth','ashsnow','dust'].forEach(k=>{
    S.check('"'+k+'" is a real kind',ea('!!WB.kind('+JSON.stringify(k)+')'));
    S.check('  with art behind it',
      ea(`!!(WB.TEX2DATA && WB.TEX2DATA[(WB.TEXMAP && WB.TEXMAP[${JSON.stringify(k)}]) || ${JSON.stringify(k)}])`));
    S.check('  and renders as more than an empty div',
      ea('WB.stampHTML({k:'+JSON.stringify(k)+',x:1,y:1,w:4,h:4},true).length')>150);
  });
  [['stool','chair'],['gate','fence'],['cart','wagon'],['woodpile','crate'],
   ['bedroll','hay'],['desk','counter'],['hook','post'],['cloth','rug'],
   ['stonefloor','flagstone'],['moss','mosspatch'],['wagonbed','deck']].forEach(pair=>{
    S.check('"'+pair[0]+'" resolves (was a repeated authoring error)',
      ea('!!WB.kind('+JSON.stringify(pair[0])+')'));
    S.eq('  aliased to '+pair[1],ea('WB.KIND_ALIAS['+JSON.stringify(pair[0])+']'),pair[1]);
  });
  S.check('the Ash valley uses the ash texture rather than two flat blocks',
    ea(`BATTLE_SCENES.filter(function(s){return s.id==='ash_valley';})[0]
        .st.some(function(e){return e[0]==='ashsnow';})`));
  S.check('the Ford\u2019s burial pits are turned earth',
    ea(`BATTLE_SCENES.filter(function(s){return s.id==='bloody_ford';})[0]
        .st.some(function(e){return e[0]==='turnedearth';})`));
  S.check('the commission room is dusty',
    ea(`BATTLE_SCENES.filter(function(s){return s.id==='commission_room';})[0]
        .st.some(function(e){return e[0]==='dust';})`));

  ['hearth','table_long','table_round'].forEach(k=>{
    S.check('"'+k+'" resolves to a kind',ea('!!WB.kind('+JSON.stringify(k)+')'));
    S.check('"'+k+'" resolves to art',ea('!!WB.propFor('+JSON.stringify(k)+',3,1)'));
    /* This measured HTML length as a proxy for "has art". Prop art now lives
       in a stylesheet rather than inline, so the proxy broke while the
       behaviour did not. Check the property itself. */
    S.check('"'+k+'" actually renders art',
      ea(`(function(){
        var h=WB.stampHTML({k:${JSON.stringify(k)},x:1,y:1,w:3,h:1},true);
        if(/base64,/.test(h)) return true;
        if(/<svg|url\\(#/.test(h)) return true;
        var m=h.match(/class="(wb[pk]-[^"]*)"/);
        if(!m) return false;
        var sh=document.getElementById('wbPropCSS');
        return !!(sh && sh.textContent.indexOf('.'+m[1]+'{')>=0);})()`)===true);
  });
  /* Every scene carried a ref: line that nothing ever read. Running notes are
     the same idea made useful: what to say first, what the map is for, and the
     two or three things that go wrong if nobody mentions them. */
  S.eq('every playable scene carries GM notes',
    ea(`BATTLE_SCENES.filter(function(s){
      return !/^blank/.test(s.id) && !(s.gm && s.gm.length); }).map(function(s){return s.id;})`).length,0);
  S.check('the notes are structured, not a wall',
    ea(`BATTLE_SCENES.filter(function(s){return s.gm&&s.gm.length;}).every(function(s){
      return s.gm.some(function(l){return String(l).charAt(0)==='#';}); })`));
  S.check('each opens with something to say aloud',
    ea(`BATTLE_SCENES.filter(function(s){return s.gm&&s.gm.length;}).every(function(s){
      return /say first/i.test(String(s.gm[0])); })`));
  S.check('and warns what breaks if unmentioned',
    ea(`BATTLE_SCENES.filter(function(s){return s.gm&&s.gm.length;}).every(function(s){
      return s.gm.some(function(l){return /goes wrong|what the map is for/i.test(String(l));}); })`));
  S.check('every playable scene says how the fight actually plays',
    ea(`BATTLE_SCENES.filter(function(s){return !/^blank/.test(s.id);}).every(function(s){
      return (s.gm||[]).some(function(l){return /^#how it plays/i.test(String(l));}); })`));
  /* the tactical block is derived from the scene data, so it cannot go stale */
  S.check('the briefing is derived, not transcribed',
    ea('typeof gmBattleSceneTactics')==='function');
  ['rd_ambush','vent_shelf','council_room','glass_forge','forge_theft'].forEach(id=>{
    const t=ea(`gmBattleSceneTactics(BATTLE_SCENES.filter(function(s){return s.id===${JSON.stringify(id)};})[0])`);
    S.check('"'+id+'" derives a briefing ('+t.length+' lines)',t.length>4);
    S.check('  listing the ways through',t.some(l=>/#Ways through/.test(l)));
    S.check('  and who starts concealed',
      t.some(l=>/concealed until you reveal|VISIBLE from the start/.test(l)));
  });
  S.check('a route with a DC in its label reports that DC',
    ea(`gmBattleSceneTactics(BATTLE_SCENES.filter(function(s){return s.id==='vent_shelf';})[0])
        .some(function(l){return /DC 16/.test(l);})`));
  S.check('hazards are listed with their position',
    ea(`gmBattleSceneTactics(BATTLE_SCENES.filter(function(s){return s.id==='ash_valley';})[0])
        .some(function(l){return /#Hazards/.test(l);})`));
  S.check('firing positions are called out where they exist',
    ea(`gmBattleSceneTactics(BATTLE_SCENES.filter(function(s){return s.id==='vent_shelf';})[0])
        .some(function(l){return /arrowslit/.test(l);})`));
  S.check('a scene with no spawns derives no spawn block',
    ea(`gmBattleSceneTactics(BATTLE_SCENES.filter(function(s){return s.id==='commission_room';})[0])
        .every(function(l){return !/On the board at load/.test(l);})`));
  S.check('no note is an empty line',
    ea(`BATTLE_SCENES.every(function(s){
      return !s.gm || s.gm.every(function(l){return String(l).trim().length>3;}); })`));
  S.check('the panel renders and closes',
    ea(`(function(){
      try{
        gmBattleSceneNotes('ash_valley');
        var open = !!document.getElementById('wbSceneNotes');
        gmBattleSceneNotes('ash_valley');
        var shut = document.getElementById('wbSceneNotes')===null;
        return open && shut;
      }catch(e){ return false; }})()`)===true);

  S.check('every scene stamp carries a level within the scene\u2019s range',
    ea(`(function(){var ok=true;BATTLE_SCENES.forEach(function(s){
      var top=(s.lv?s.lv.length:1)-1;
      (s.st||[]).forEach(function(e){ var l=e[6]||0; if(l<0||l>top) ok=false; });});return ok;})()`));
  S.check('every scene stamp sits inside its own grid',
    ea(`(function(){var ok=true;BATTLE_SCENES.forEach(function(s){
      (s.st||[]).forEach(function(e){
        if(e[1]<0||e[2]<0||e[1]+e[3]>s.w||e[2]+e[4]>s.h) ok=false; });});return ok;})()`));

  /* the Glass Forge, built to the Bandit Camp's level of detail */
  const gf=ea(`(function(){var x=BATTLE_SCENES.filter(function(b){return b.id==='glass_forge';})[0];
    if(!x) return null; var k={},lv={};
    x.st.forEach(function(e){k[e[0]]=1;lv[e[6]||0]=(lv[e[6]||0]||0)+1;});
    return {w:x.w,h:x.h,levels:x.lv.length,stamps:x.st.length,kinds:Object.keys(k).length,
            lv0:lv[0]||0,lv1:lv[1]||0,lv2:lv[2]||0};})()`);
  S.check('the Glass Forge scene exists',!!gf);
  if(gf){
    S.eq('it has the three levels gf3 calls for',gf.levels,3);
    S.check('every level is actually built ('+gf.lv0+'/'+gf.lv1+'/'+gf.lv2+')',
      gf.lv0>20&&gf.lv1>20&&gf.lv2>20);
    S.check('it is larger than the Bandit Camp ('+gf.w+'x'+gf.h+')',gf.w*gf.h>44*32);
    S.check('at least the Bandit Camp\u2019s detail ('+gf.stamps+' stamps, '+gf.kinds+' kinds)',
      gf.stamps>=95&&gf.kinds>=35);
    S.check('it has a way down and a way up',
      ea(`(function(){var x=BATTLE_SCENES.filter(function(b){return b.id==='glass_forge';})[0];
        var k=x.st.map(function(e){return e[0];});
        return k.indexOf('stairdown')>=0 && k.indexOf('stairup')>=0;})()`));
    S.check('it uses the forge art that had no home before',
      ea(`(function(){var x=BATTLE_SCENES.filter(function(b){return b.id==='glass_forge';})[0];
        var k=x.st.map(function(e){return e[0];});
        return ['glassfurnace','crucible','minecart','winch','portcullis'].every(function(n){
          return k.indexOf(n)>=0; });})()`));
  }

  /* ── scenes must be playable, not just drawn ───────────────────────────
     A level with no paired aperture cannot be reached at all: the Talgar Road
     shipped with its scramble points on the bank level only, so the banks
     that make it an ambush were unreachable. Some apertures are deliberately
     one-ended and say so in their label — vents, drains, roof hatches, ship
     holds, an open pit shaft that is a fall rather than a route, and a rope
     walkway that spans a single level rather than joining two. */
  const conn=ea(`(function(){
    return BATTLE_SCENES.filter(function(s){return (s.lv?s.lv.length:1)>1;}).map(function(s){
      var ap=(s.st||[]).filter(function(e){return WB.APERTURES[e[0]];})
        .map(function(e){return {k:e[0],x:e[1],y:e[2],w:e[3],h:e[4],lv:e[6]||0,l:String(e[5]||'')};});
      var routes={}, orph=[];
      ap.forEach(function(a){
        var mate=ap.filter(function(b){ return b!==a && Math.abs(b.lv-a.lv)===1 &&
          !(b.x+b.w<=a.x||a.x+a.w<=b.x||b.y+b.h<=a.y||a.y+a.h<=b.y); });
        if(mate.length){ var k=Math.min(a.lv,mate[0].lv)+'>'+Math.max(a.lv,mate[0].lv);
          routes[k]=(routes[k]||0)+1; }
        else if(!/vent|over the side|hold|sump|drain|roof|chute|hatch|shaft|walk|span|bridge|way in|off-map|approach/i.test(a.l))
          orph.push(s.id+':'+a.k+'@'+a.lv+' ('+a.l+')');
      });
      return {id:s.id, levels:s.lv.length, routes:routes, orphans:orph};
    });
  })()`);
  /* Five separate scenes shipped with a level you could climb to and not
     from \u2014 the Talgar banks, the abbey tower, the cornice, the wagon-tops,
     the bell-loft. Each was caught here and fixed by hand. The loader now
     pairs them itself so the data does not have to be perfect. */
  /* Painted settlement maps under the grid. The image underlay already
     existed for hand-uploaded maps; scenes now point at it by name. */
  /* Every point-of-interest icon has to open something that exists. One shop
     icon pointed at 'fence' where the shop id is 'blackmarket', which would
     have opened an empty card at the table. */
  const SHOPIDS=['wagonwright','armorer','weaponsmith','fletcher','apothecary','mage',
    'general','stable','inn','services','transit','bank','healer','herbalist',
    'blackmarket','ferry'];
  const PLACES=['forest','field','cave','mountain','water','swamp','burnt',
    'smith','brewery','fletcher'];
  const GAMES=['gwent','dice','memory','aard'];
  S.eq('every shop icon names a real shop',
    ea(`(function(){
      var bad=[]; BATTLE_SCENES.forEach(function(s){
        (s.ic||[]).forEach(function(e){
          if(e[5]==='shop' && ${JSON.stringify(SHOPIDS)}.indexOf(e[6])<0) bad.push(s.id+':'+e[6]);
        }); });
      return bad;})()`).length,0);
  S.eq('every forage icon names a real place',
    ea(`(function(){
      var bad=[]; BATTLE_SCENES.forEach(function(s){
        (s.ic||[]).forEach(function(e){
          if(e[5]==='forage' && ${JSON.stringify(PLACES)}.indexOf(e[6])<0) bad.push(s.id+':'+e[6]);
        }); });
      return bad;})()`).length,0);
  S.eq('every game icon names a real game',
    ea(`(function(){
      var bad=[]; BATTLE_SCENES.forEach(function(s){
        (s.ic||[]).forEach(function(e){
          if(e[5]==='game' && ${JSON.stringify(GAMES)}.indexOf(e[6])<0) bad.push(s.id+':'+e[6]);
        }); });
      return bad;})()`).length,0);
  S.check('every icon has a kind the sheet knows how to open',
    ea(`BATTLE_SCENES.every(function(s){
      return (s.ic||[]).every(function(e){
        return ['shop','forage','game','inn'].indexOf(e[5])>=0; }); })`));
  S.check('and a name and a position',
    ea(`BATTLE_SCENES.every(function(s){
      return (s.ic||[]).every(function(e){
        return !!e[0] && e[1]>=0 && e[2]>=0 && e[1]<s.w && e[2]<s.h; }); })`));

  /* Two faults found in play rather than in tests.

     Fog marked as an interior draws a 96%-opaque diagonal roof. I used the fg
     array to label regions and wrote 'hidden' as the fifth element, which
     roofed 49 regions across 20 scenes \u2014 eleven boards more than a quarter
     covered and the council room completely. Scenes must load clear; the GM
     applies fog by hand.

     And on a painted settlement the painting is the map. Stamp terrain laid
     over it reads as a texture quilt, so those scenes keep only what the rules
     need: connectors, apertures, hazards. */
  S.eq('no scene ships with a roofed region',
    ea(`(function(){
      var bad=[];
      BATTLE_SCENES.forEach(function(s){
        (s.fg||[]).forEach(function(f){
          if(f[5]==='hidden'||f[5]==='roof') bad.push(s.id+':'+(f[0]||'?')); }); });
      return bad;})()`).length,0);
  S.check('spawn "open" flags were not collateral damage',
    ea(`(function(){var n=0;BATTLE_SCENES.forEach(function(s){
      (s.sp||[]).forEach(function(e){ if(e[5]==='open') n++; }); }); return n>=8;})()`)===true);
  S.check('the GM can clear every covered region in one press',
    ea('document.documentElement.innerHTML.indexOf("fog-clear")>=0')===true);
  S.check('and fog travels to the players so clearing it clears theirs',
    ea(`(function(){
      var f=(gmBattleSnapshot().fog||[])[0];
      return !f || ('r' in f && 'roof' in f);})()`)===true);
  /* On a painted settlement nothing may draw a coloured block over the art.
     Whatever stamps remain must be transparent prop images \u2014 an archway
     marking a gate is fine, a terrain fill is not. And no elevation tint or
     roofed region either: the painting plus tokens is the whole picture. */
  S.eq('nothing on a painted settlement renders as a coloured block',
    ea(`(function(){
      var bad=[];
      BATTLE_SCENES.filter(function(s){return s.bg && (s.ic||[]).length;}).forEach(function(s){
        (s.st||[]).forEach(function(e){
          var h=WB.stampHTML({k:e[0],x:e[1],y:e[2],w:e[3],h:e[4]},true);
          var art = /base64,/.test(h) || /<svg|url\\(#/.test(h);
          if(!art){
            var m=h.match(/class="(wb[pk]-[^"]*)"/);
            var sh=document.getElementById('wbPropCSS');
            art = !!(m && sh && sh.textContent.indexOf('.'+m[1]+'{')>=0);
          }
          if(!art) bad.push(s.id+':'+e[0]); }); });
      return bad;})()`).length,0);
  S.eq('and no elevation tint over the art',
    ea(`(function(){
      var bad=[];
      BATTLE_SCENES.filter(function(s){return s.bg && (s.ic||[]).length;}).forEach(function(s){
        if((s.ev||[]).length) bad.push(s.id); });
      return bad;})()`).length,0);
  /* The stripe pattern that made maps unplayable was NOT fog \u2014 it was
     WB.roofHTML, which draws a stripe on every cell with a floor on the level
     above, automatically and regardless of any fog setting. glass_forge was
     99% striped and three_cells 100%. Off by default. */
  /* VOCABULARY.md records the real vocabulary of these apps, because a whole
     session of wrong answers came from testing with inputs the system never
     produces. A reference that drifts is worse than none, so the load-bearing
     claims in it are checked here. */
  S.eq('the board still produces exactly three side values',
    ea(`(function(){
      var seen={};
      BATTLE_SCENES.forEach(function(sc){
        (sc.npc||[]).forEach(function(){ seen['npc']=1; });
        (sc.sp||[]).forEach(function(){ seen['enemy']=1; });
      });
      return Object.keys(seen).sort();})()`).join(','),'enemy,npc');
  S.eq('enemy still rings red',ea('WB.sideColor("enemy")'),'#E05545');
  S.eq('neutral still rings gold',ea('WB.sideColor("neutral")'),'#D9A53A');
  S.check('and npc rings the same as neutral, which is why icons use purpose',
    ea('WB.sideColor("npc")===WB.sideColor("neutral")')===true);
  S.check('"pc" and "foe" are still not real side values',
    ea(`WB.sideColor('pc')===WB.sideColor('nonsense')
        && WB.sideColor('foe')===WB.sideColor('nonsense')`)===true);
  S.eq('a loaded stamp still labels with .l, not .label',
    ea(`(function(){
      var s={i:'x',k:'tree',x:1,y:1,w:1,h:1,l:'a label',lv:0};
      return Object.keys(s).indexOf('l')>=0 && Object.keys(s).indexOf('label')<0;})()`),true);
  S.check('there are still two stampHTML definitions, the later one live',
    ea('typeof WB.stampHTML')==='function');
  /* The reference listed a flat-colour path with 11 kinds in it. Those were
     kinds whose art was registered in the wrong texture map; with that fixed
     the path is empty, so the reference no longer claims it is populated. */
  S.check('the render paths named in the reference still exist',
    ea(`(function(){
      var paths={};
      WB.KINDS.forEach(function(kd){
        var h=WB.stampHTML({k:kd.k,x:1,y:1,w:2,h:2},true);
        if(/url\\(#/.test(h)) paths.svg=1;
        else if(/class="wbp-/.test(h)) paths.css=1;
        else if(/base64,/.test(h)) paths.inline=1; });
      return !!(paths.svg && paths.css);})()`)===true);
  S.eq('"smith" is a forage place and not a shop id',
    ea(`(function(){
      var SHOPS=['wagonwright','armorer','weaponsmith','fletcher','apothecary',
        'mage','general','stable','inn','services','transit','bank','healer',
        'herbalist','blackmarket','ferry'];
      return SHOPS.indexOf('smith');})()`),-1);

  /* There are two texture maps \u2014 TEXMAP indexes WB.TEXDATA, TEX2MAP indexes
     WB.TEX2DATA \u2014 and texSrc() consults each against its own. Eleven textures
     were imported into TEX2DATA and registered in TEXMAP, so the renderer
     never found them and the Ash valley, the forests and the reed beds all
     drew as flat colour while their art sat unreachable in the file. */
  S.eq('no kind renders as flat colour when art exists for it',
    ea(`(function(){
      var bad=[];
      WB.KINDS.forEach(function(kd){
        var h=WB.stampHTML({k:kd.k,x:1,y:1,w:2,h:2},true);
        var drawn=/url\\(#/.test(h)||/class="wbp-/.test(h)||/base64,/.test(h);
        if(drawn) return;
        var hasArt=(WB.TEXDATA&&WB.TEXDATA[kd.k])||(WB.TEX2DATA&&WB.TEX2DATA[kd.k]);
        if(hasArt) bad.push(kd.k); });
      return bad;})()`).length,0);
  /* TEXMAP and TEX2MAP are function-local, so a test cannot read them, and a
     texture name is not always a kind name \u2014 'moss' is drawn by the 'swamp'
     kind. The first assertion above already covers the failure that mattered
     (a kind with art rendering flat); this only checks nothing draws flat. */
  S.eq('no kind in the catalogue renders as flat colour',
    ea(`(function(){
      var flat=[];
      WB.KINDS.forEach(function(kd){
        var h=WB.stampHTML({k:kd.k,x:1,y:1,w:2,h:2},true);
        if(!/url\\(#/.test(h)&&!/class="wbp-/.test(h)&&!/base64,/.test(h)) flat.push(kd.k); });
      return flat;})()`).length,0);

  /* Geometry that runs off the edge draws into nothing and misreports its
     own area. The abbey's bell-tower hazard and two elevation zones were built
     for a board that later shrank; the vent shelf's crumbling-lip trap was
     centred on column 0 with half its radius outside the map. */
  S.eq('no hazard, trap, zone or cache runs off its board',
    ea(`(function(){
      var bad=[];
      BATTLE_SCENES.forEach(function(s){
        var over=function(x,y,w,h){return x<0||y<0||x+(w||1)>s.w||y+(h||1)>s.h;};
        (s.st||[]).forEach(function(e){ if(over(e[1],e[2],e[3],e[4])) bad.push(s.id+' stamp'); });
        (s.hz||[]).forEach(function(e){ if(over(e[0],e[1],e[2],e[3])) bad.push(s.id+' hazard'); });
        (s.ev||[]).forEach(function(e){ if(over(e[0],e[1],e[2],e[3])) bad.push(s.id+' zone'); });
        (s.ct||[]).forEach(function(e){ if(over(e[0],e[1],1,1)) bad.push(s.id+' cache'); });
        (s.sp||[]).forEach(function(e){ if(over(e[2],e[3],1,1)) bad.push(s.id+' spawn'); });
        (s.tr||[]).forEach(function(e){
          var r=e[2]||2;
          if(e[0]-r<0||e[1]-r<0||e[0]+r>=s.w||e[1]+r>=s.h) bad.push(s.id+' trap'); });
      });
      return bad;})()`).length,0);

  /* Stamp order is render order. The commission room's dust layer was drawn
     last and buried the linen-covered shapes, the ledger counter and the
     footprints meant to be IN the dust; Eskalott's one-PC-wide drowned
     section sat under the islet's gravel; four of the ruined keep's windows
     were drawn before their walls and so vanished into them. Only a bare
     floor under a dust layer may be wholly covered \u2014 that is the look. */
  S.eq('no stamp is wholly buried under a later one, except floor under dust',
    ea(`(function(){
      var bad=[];
      BATTLE_SCENES.forEach(function(s){
        var st=s.st||[];
        st.forEach(function(e,i){
          var kd=WB.kind(e[0]); if(!kd||kd.t!=='fill') return;
          for(var j=i+1;j<st.length;j++){
            var f=st[j], kf=WB.kind(f[0]);
            if(!kf||kf.t!=='fill'||(f[6]||0)!==(e[6]||0)) continue;
            if(f[1]<=e[1]&&f[2]<=e[2]&&f[1]+f[3]>=e[1]+e[3]&&f[2]+f[4]>=e[2]+e[4]){
              if(!(e[0]==='flagstone' && f[0]==='dust')) bad.push(s.id+':'+e[0]+' under '+f[0]);
              break; } } }); });
      return bad;})()`).length,0);
  S.check('and the commission room draws dust before the objects in it',
    ea(`(function(){
      var st=BATTLE_SCENES.filter(function(s){return s.id==='commission_room';})[0].st;
      var di=-1, ri=-1, fi=-1;
      st.forEach(function(e,i){
        if(e[0]==='dust') di=i;
        if(e[0]==='rug') ri=i;
        if(e[0]==='footprints') fi=i; });
      return di>=0 && di<ri && di<fi;})()`)===true);

  S.check('overhead roofs are off by default',ea('WB.ROOFS_ON')===false);
  S.eq('and nothing is striped with them off',
    ea(`(function(){
      var worst=0;
      BATTLE_SCENES.forEach(function(sc){
        var n=(WB.roofHTML(
          (sc.st||[]).map(function(e,i){
            return {i:'x'+i,k:e[0],x:e[1],y:e[2],w:e[3],h:e[4],lv:e[6]||0};}),
          0, sc.w, sc.h).match(/<div/g)||[]).length;
        if(n>worst) worst=n; });
      return worst;})()`),0);
  S.check('the toggle exists and is reachable',
    ea('document.documentElement.innerHTML.indexOf("fog-clear")>=0')===true);
  S.check('and the state travels to the players',
    ea(`(function(){
      window._gmB.roofs=true;
      var s=gmBattleSnapshot();
      window._gmB.roofs=false;
      return s.roofs===true;})()`)===true);
  /* icons clustered where my invented districts were, not over the art */
  S.eq('every settlement icon sits on the board',
    ea(`(function(){
      var bad=[];
      BATTLE_SCENES.filter(function(s){return (s.ic||[]).length;}).forEach(function(s){
        (s.ic||[]).forEach(function(e){
          if(e[1]<0||e[1]>=s.w||e[2]<0||e[2]>=s.h) bad.push(s.id+':'+e[0]); }); });
      return bad;})()`).length,0);
  /* A settlement icon belongs on the painting; an OUTSKIRTS icon deliberately
     does not. A dense city map has no fields or woods in it, so forage icons
     sit in the board margin beyond the walls, on terrain stamps placed there.
     The rule is that a shop, game or inn is on the painting and a forage icon
     is either on it or outside it \u2014 never off the board. */
  S.eq('every shop, game and inn icon sits on the painting',
    ea(`(function(){
      var bad=[];
      BATTLE_SCENES.filter(function(s){return s.bg && (s.ic||[]).length;}).forEach(function(s){
        (s.ic||[]).forEach(function(e){
          if(e[5]==='forage') return;
          if(e[1]<s.bgx||e[1]>=s.bgx+s.bgw||e[2]<s.bgy||e[2]>=s.bgy+s.bgw)
            bad.push(s.id+':'+e[0]); }); });
      return bad;})()`).length,0);
  S.eq('no two icons share a cell',
    ea(`(function(){
      var bad=[];
      BATTLE_SCENES.filter(function(s){return (s.ic||[]).length;}).forEach(function(s){
        var seen={};
        (s.ic||[]).forEach(function(e){
          var k=e[1]+','+e[2]+'@'+(e[3]||0);
          if(seen[k]) bad.push(s.id+':'+e[0]); seen[k]=1; }); });
      return bad;})()`).length,0);
  S.check('and they are spread rather than clustered',
    ea(`BATTLE_SCENES.filter(function(s){return s.bg && (s.ic||[]).length>=8;})
        .every(function(s){
          var xs=s.ic.map(function(e){return e[1];});
          var ys=s.ic.map(function(e){return e[2];});
          var spanx=Math.max.apply(null,xs)-Math.min.apply(null,xs);
          var spany=Math.max.apply(null,ys)-Math.min.apply(null,ys);
          /* Written when icons were spread on a grid. They now sit on the
             terrain the painting shows, and a town legitimately clusters
             where its buildings are \u2014 Luton's shops are around the square
             and the quay because the upper third is windmill and pasture.
             The intent was "not bunched in one corner", so 40% each way. */
          return spanx >= s.bgw*0.4 && spany >= Math.min(s.bgw,s.h)*0.4; })`));

  /* This required at least 8 icons, which encoded the wrong intent: Spetz has
     six on purpose, because half its trades are shut and that is the whole
     scene. What matters is that a painted settlement stays tokens-on-a-map
     and does not drift back into terrain building \u2014 so icons must outnumber
     stamps, and stamps stay few. */
  /* Every settlement map was cut off. Six of the eight are portrait
     (1024x1536) and the underlay scales by width, so a map 34 cells wide drew
     51 cells tall on a 32-row board \u2014 about 40% of each painting hung off the
     bottom, unreachable. The maps are square now and each board is fitted to
     the rows it actually has. */
  S.eq('every painted map fits the board it is drawn on',
    ea(`(function(){
      var bad=[];
      BATTLE_SCENES.filter(function(s){return s.bg;}).forEach(function(s){
        /* maps are square, so drawn height equals bgw */
        if((s.bgy||0) + s.bgw > s.h) bad.push(s.id+' needs '+((s.bgy||0)+s.bgw)+' of '+s.h);
        if((s.bgx||0) + s.bgw > s.w) bad.push(s.id+' too wide');
      });
      return bad;})()`).length,0);
  S.check('and the map is centred rather than jammed against an edge',
    ea(`BATTLE_SCENES.filter(function(s){return s.bg;}).every(function(s){
      return (s.bgx||0) >= 1 && (s.bgy||0) >= 1; })`));

  S.check('a painted settlement is tokens and icons on a map',
    ea(`BATTLE_SCENES.filter(function(s){return s.bg && (s.ic||[]).length;}).every(function(s){
      /* only stamps that overlap the painting count against the limit \u2014
         terrain in the margin is the outskirts, not a quilt on the art */
      var onArt=(s.st||[]).filter(function(e){
        return e[1] < s.bgx+s.bgw && e[1]+e[3] > s.bgx
            && e[2] < s.bgy+s.bgw && e[2]+e[4] > s.bgy; });
      return (s.ic||[]).length >= 4 && onArt.length <= 8; })`));

  /* Terrain is barred from the painting and allowed outside it. */
  S.eq('no terrain stamp overlaps the painting',
    ea(`(function(){
      var KEEP=/^(stairup|stairdown|stairs|stonesteps|ladder|trapdoor|grate|hatch|ropebridge|archway|door|doorframe|portcullis|window|arrowslit)$/;
      var bad=[];
      BATTLE_SCENES.filter(function(s){return s.bg && (s.ic||[]).length;}).forEach(function(s){
        (s.st||[]).forEach(function(e){
          if(KEEP.test(e[0])) return;
          var overlaps = e[1] < s.bgx+s.bgw && e[1]+e[3] > s.bgx
                      && e[2] < s.bgy+s.bgw && e[2]+e[4] > s.bgy;
          if(overlaps) bad.push(s.id+':'+e[0]); }); });
      return bad;})()`).length,0);
  S.check('settlement maps are loaded',ea('Object.keys(WB.CITYMAPS||{}).length')>=6);
  S.check('each is a real image',
    ea(`Object.keys(WB.CITYMAPS||{}).every(function(k){
      return /^data:image\\/(webp|png|jpeg);base64,/.test(WB.CITYMAPS[k]); })`));
  S.check('a scene with bg gets an underlay',
    ea(`(function(){
      var sc=BATTLE_SCENES.filter(function(s){return s.id==='lan_exeter_city';})[0];
      return !!(sc && sc.bg && WB.CITYMAPS[sc.bg]);})()`)===true);
  S.check('every scene bg names a map that exists',
    ea(`BATTLE_SCENES.filter(function(s){return s.bg;}).every(function(s){
      return !!(WB.CITYMAPS && WB.CITYMAPS[s.bg]); })`));

  S.check('the loader can pair a connector',ea('typeof gmBattleAutoPairConnectors')==='function');
  S.check('an orphaned ladder gets its other end',
    ea(`(function(){
      window._gmB={toks:[],stamps:[
        {i:'a',k:'ladder',x:7,y:7,w:1,h:2,lv:1,l:'Up to the loft'}
      ],levels:[{n:'g'},{n:'l'}],lvl:0,w:20,h:20};
      var n=gmBattleAutoPairConnectors({st:[[]],lv:[{n:'g'},{n:'l'}]});
      var ap=window._gmB.stamps.filter(function(s){return s.autopaired;});
      return n===1 && ap.length===1 && ap[0].lv===0;})()`)===true);
  S.check('a deliberate off-map entrance is left alone',
    ea(`(function(){
      window._gmB={toks:[],stamps:[
        {i:'b',k:'stonesteps',x:10,y:17,w:2,h:2,lv:0,l:'The way in from off-map'}
      ],levels:[{n:'g'},{n:'l'}],lvl:0,w:20,h:20};
      return gmBattleAutoPairConnectors({st:[[]],lv:[{n:'g'},{n:'l'}]})===0;})()`)===true);
  S.check('a vent is left alone',
    ea(`(function(){
      window._gmB={toks:[],stamps:[
        {i:'c',k:'grate',x:4,y:4,w:2,h:2,lv:1,l:'The vent \u2014 warm air'}
      ],levels:[{n:'g'},{n:'l'}],lvl:0,w:20,h:20};
      return gmBattleAutoPairConnectors({st:[[]],lv:[{n:'g'},{n:'l'}]})===0;})()`)===true);
  S.check('a stair that already has its mate is not duplicated',
    ea(`(function(){
      window._gmB={toks:[],stamps:[
        {i:'d',k:'stairup',x:3,y:3,w:2,h:2,lv:0,l:'Up'},
        {i:'e',k:'stairdown',x:3,y:3,w:2,h:2,lv:1,l:'Down'}
      ],levels:[{n:'g'},{n:'l'}],lvl:0,w:20,h:20};
      return gmBattleAutoPairConnectors({st:[[]],lv:[{n:'g'},{n:'l'}]})===0;})()`)===true);
  S.check('and no existing scene needs pairing \u2014 they are all already correct',
    ea(`(function(){
      var need=0;
      BATTLE_SCENES.forEach(function(sc){
        if(!sc.lv || sc.lv.length<2) return;
        var saved=window._gmB;
        window._gmB={toks:[],stamps:(sc.st||[]).map(function(e,i){
          return {i:'x'+i,k:e[0],x:e[1],y:e[2],w:e[3],h:e[4],lv:e[6]||0,l:String(e[5]||'')};
        }),levels:sc.lv,lvl:0,w:sc.w,h:sc.h};
        need += gmBattleAutoPairConnectors(sc);
        window._gmB=saved;
      });
      return need===0;})()`)===true);

  conn.forEach(c=>{
    S.eq('"'+c.id+'" has no unpaired connector ['+c.orphans.join(',')+']',c.orphans.length,0);
    for (let l=0; l<c.levels-1; l++){
      const k=l+'>'+(l+1);
      S.check('"'+c.id+'" level '+l+' reaches level '+(l+1),(c.routes[k]||0)>0);
    }
  });
  /* the four rebuilt for the Courier's Burden opening carry a real encounter */
  ['rd_ambush','luton_quay','gullet_siren','glass_forge'].forEach(id=>{
    const sc=ea('(function(){var s=BATTLE_SCENES.filter(function(x){return x.id==='+JSON.stringify(id)+';})[0];'
      +'if(!s)return null;return {sp:(s.sp||[]).reduce(function(a,x){return a+x[1];},0),'
      +'ct:(s.ct||[]).length,hz:(s.hz||[]).length,tr:(s.tr||[]).length,fg:(s.fg||[]).length,'
      +'ev:(s.ev||[]).length,stg:(s.stg||[]).length};})()');
    S.check('"'+id+'" arrives with its creatures placed ('+(sc&&sc.sp)+')',!!sc&&sc.sp>=5);
    S.check('"'+id+'" has loot containers',!!sc&&sc.ct>=3);
    S.check('"'+id+'" has hazards and traps',!!sc&&sc.hz>=1&&sc.tr>=1);
    S.check('"'+id+'" has named areas and elevation',!!sc&&sc.fg>=4&&sc.ev>=3);
    S.check('"'+id+'" has staged reveals',!!sc&&sc.stg>=2);
  });
  S.check('every spawned creature exists in the bestiary',
    ea(`(function(){var bad=0;BATTLE_SCENES.forEach(function(s){(s.sp||[]).forEach(function(x){
      if(!DEFAULT_BESTIARY.some(function(m){return m.name===x[0];})) bad++; });});return bad===0;})()`));
  S.check('every spawn point sits inside its scene',
    ea(`(function(){var ok=true;BATTLE_SCENES.forEach(function(s){(s.sp||[]).forEach(function(x){
      if(x[2]<0||x[3]<0||x[2]>=s.w||x[3]>=s.h) ok=false; });});return ok;})()`));
  S.check('a locked door carries a DC',
    ea(`(function(){var ok=true;BATTLE_SCENES.forEach(function(s){(s.st||[]).forEach(function(e){
      if(e[7]!=null && e[7]!=='locked' && typeof e[7]!=='number') ok=false; });});return ok;})()`));

  /* 7. toolbar */
  const grouped=ea('(function(){var s={};WB.GM_TOOL_GROUPS.forEach(function(g){'
    +'g.acts.forEach(function(a){s[a]=1;});});return Object.keys(s);})()');
  S.check('tool-select stays on the bar, not inside a category',grouped.indexOf('tool-select')<0);
  S.check('eff-panel is not a second entry for the effects tool',grouped.indexOf('eff-panel')<0);
  S.check('tool-eff is still grouped',grouped.indexOf('tool-eff')>=0);
  S.check('Build is no longer a third of the bar ('+ea('WB.GM_TOOL_GROUPS[0].acts.length')+')',
    ea('WB.GM_TOOL_GROUPS[0].acts.length')<=9);
  S.check('no group is empty',ea('WB.GM_TOOL_GROUPS.every(function(g){return g.acts.length>0;})'));

  process.exit(S.report()?0:1);
},6000);
