/* Suite 09 — Stamp catalogue and art library.
   Three things this guards:
     - every embedded prop image must be reachable from a placeable kind.
       22 of 108 were not; roughly 1 MiB shipped in every load unusable.
     - every kind must carry a category, or it falls out of the grouped picker.
     - every kind that costs movement must explain why. */
const {boot,Suite}=require('../harness.js');
const S=Suite('09 stamp-catalogue');
const A=boot('/home/claude/W/gm.html');
const B=boot('/home/claude/W/sheet.html');

setTimeout(()=>{
  const ea=s=>A.dom.window.eval(s), eb=s=>B.dom.window.eval(s);
  S.check('gm boots clean',A.errs.length===0);
  S.check('sheet boots clean',B.errs.length===0);

  /* 1. categories */
  S.check('every kind carries a category',ea('WB.KINDS.every(function(k){return !!k.cat;})'));
  S.check('every category has a label',
    ea('WB.KINDS.every(function(k){return !!(WB.KIND_CATS&&WB.KIND_CATS[k.cat]);})'));
  S.check('CAT_ORDER covers every category in use',
    ea('(function(){var u={};WB.KINDS.forEach(function(k){u[k.cat]=1;});'
      +'return Object.keys(u).every(function(c){return WB.CAT_ORDER.indexOf(c)>=0;});})()'));
  S.check('no category is empty',
    ea('WB.CAT_ORDER.every(function(c){return WB.KINDS.some(function(k){return k.cat===c;});})'));
  S.check('terrain edge decals are their own group, not mixed with furniture',
    ea('WB.KINDS.filter(function(k){return k.k.indexOf("edge_")===0;})'
      +'.every(function(k){return k.cat==="edge";})'));
  S.check('kind count is plausible ('+ea('WB.KINDS.length')+')',ea('WB.KINDS.length')>=145);
  S.check('kind keys are unique',
    ea('(function(){var s={},d=0;WB.KINDS.forEach(function(k){if(s[k.k])d++;s[k.k]=1;});return d===0;})()'));

  /* 2. no art may be unreachable, in either file */
  const orphans=f=>f(`(function(){
    var reach={};
    WB.KINDS.forEach(function(k){
      [[1,1],[2,1],[1,2]].forEach(function(d){
        var p=null; try{ p=WB.propFor(k.k,d[0],d[1]); }catch(e){}
        if(p&&p.name) reach[p.name]=1;
      });
    });
    var out=[];
    ['PROPDATA','PROP2DATA','PROP3DATA','STRUCTDATA'].forEach(function(L){
      if(!WB[L]) return;
      Object.keys(WB[L]).forEach(function(n){ if(!reach[n]) out.push(L+'/'+n); });
    });
    return out;
  })()`);
  const oa=orphans(ea), ob=orphans(eb);
  S.eq('no unreachable art in gm ('+oa.join(',')+')',oa.length,0);
  S.eq('no unreachable art in sheet ('+ob.join(',')+')',ob.length,0);

  /* 3. every kind resolves to something drawable */
  const undrawable=f=>f(`(function(){
    var out=[];
    WB.KINDS.forEach(function(k){
      var p=null; try{ p=WB.propFor(k.k,1,1); }catch(e){}
      if(p) return;
      if(WB.ART&&WB.ART[k.k]) return;
      if(WB.ARTFILL&&WB.ARTFILL[k.k]) return;
      if(WB.TEXMAP&&WB.TEXMAP[k.k]) return;
      if(WB.TERRAIN_EDGE&&WB.TERRAIN_EDGE[k.k]) return;
      if(k.t==='fill'&&k.c) return;          /* plain colour fill is a valid look */
      out.push(k.k);
    });
    return out;
  })()`);
  S.eq('every kind draws as something (gm) ['+undrawable(ea).join(',')+']',undrawable(ea).length,0);

  /* 4. the newly wired pieces really resolve to art */
  ['glassfurnace','crucible','minecart','winch','portcullis','archway','pillar','post',
   'fireplace','partition','balcony','roofedge','chimney','wallcorner','doorframe',
   'chest_iron','chest_small','chest_broken','body_soldier','body_animal','bones_pile'
  ].forEach(k=>{
    S.check('"'+k+'" is placeable',!!ea('WB.kind('+JSON.stringify(k)+')'));
    S.check('"'+k+'" resolves to art',ea('!!WB.propFor('+JSON.stringify(k)+',1,1)'));
  });

  /* 5. the five new assets, present and identical in both files */
  ['ritualcircle','altar','cauldron','spiderweb','hedge'].forEach(k=>{
    S.check('new art "'+k+'" is in PROP3DATA',ea('!!WB.PROP3DATA['+JSON.stringify(k)+']'));
    S.check('new art "'+k+'" has meta',ea('!!WB.PROP3META['+JSON.stringify(k)+']'));
    S.check('new art "'+k+'" resolves through propFor',ea('!!WB.propFor('+JSON.stringify(k)+',1,1)'));
    S.eq('new art "'+k+'" identical in both files',
      ea('WB.PROP3DATA['+JSON.stringify(k)+'].length'),
      eb('WB.PROP3DATA['+JSON.stringify(k)+'].length'));
    S.check('new art "'+k+'" is webp',
      /^data:image\/webp;base64,/.test(ea('WB.PROP3DATA['+JSON.stringify(k)+'].slice(0,30)')));
  });
  ['ritualcircle','altar','cauldron','spiderweb'].forEach(k=>
    S.check('"'+k+'" is placeable as a kind',!!ea('WB.kind('+JSON.stringify(k)+')')));
  S.check('hedge keeps its fill type so existing maps are unaffected',
    ea('WB.kind("hedge").t')==='fill');

  /* 6. anything that costs movement must say why */
  const mute=ea('Object.keys(WB.SLOW).filter(function(k){return !WB.TERRAIN[k];})');
  S.eq('no silent movement penalties ['+mute.join(',')+']',mute.length,0);
  S.check('terrain text is present in both files',
    ea('Object.keys(WB.TERRAIN).length')===eb('Object.keys(WB.TERRAIN).length'));
  S.check('book-backed entries cite a page',
    ea('["marsh","tallgrass","thornbush","deepwater","swamp","water","ice","snow"]'
      +'.every(function(k){return /pg\\.\\d+/.test(WB.TERRAIN[k].t);})'));
  S.check('invented entries are marked with the cog',
    ea('["mud","rubble","rubblescatter","snowdrift","furrows","strawfloor"]'
      +'.every(function(k){return WB.TERRAIN[k].t.indexOf("\\u2699")>=0;})'));

  /* 6b. pg.47 Witcher Training eases environmental penalties by half the
     skill value, minimum 1, and can cancel one but never invert it. */
  S.check('witcherRelief is defined in both files',
    ea('typeof WB.witcherRelief')==='function'&&eb('typeof WB.witcherRelief')==='function');
  [[0,1],[1,1],[2,1],[3,1],[4,2],[5,2],[6,3],[7,3],[8,4],[11,5]].forEach(([wt,r])=>
    S.eq('Witcher Training '+wt+' relieves '+r,ea('WB.witcherRelief('+wt+')'),r));
  S.eq('a negative skill value still relieves the minimum',ea('WB.witcherRelief(-3)'),1);
  S.eq('a missing skill value still relieves the minimum',ea('WB.witcherRelief(null)'),1);

  const pen=(k,wt,w)=>ea('JSON.stringify(WB.terrainPenaltyFor('+JSON.stringify(k)+','+wt+','+w+'))');
  S.eq('a non-Witcher gets no relief',JSON.parse(pen('swamp',8,false)).relief,0);
  S.eq('a non-Witcher feels the full penalty',JSON.parse(pen('swamp',8,false)).eased,2);
  S.eq('Witcher Training 1 eases -2 to -1',JSON.parse(pen('swamp',1,true)).eased,1);
  S.eq('Witcher Training 4 cancels -2',JSON.parse(pen('swamp',4,true)).eased,0);
  S.eq('relief never inverts the penalty',JSON.parse(pen('swamp',20,true)).eased,0);
  S.eq('relief is capped at the penalty itself',JSON.parse(pen('swamp',20,true)).relief,2);
  ['swamp','hedge','marsh','tallgrass','thornbush','water','deepwater'].forEach(k=>
    S.check('"'+k+'" carries a reducible penalty',ea('!!WB.TERRAIN_PENALTY['+JSON.stringify(k)+']')));
  ['ice','snow'].forEach(k=>
    S.eq('"'+k+'" sets a DC, not a penalty, so it is not reduced',pen(k,8,true),'null'));
  ['mud','rubble','snowdrift','furrows','strawfloor','rubblescatter'].forEach(k=>
    S.eq('"'+k+'" is our own movement cost and is not reduced',pen(k,8,true),'null'));
  S.check('every penalty key is a real terrain kind',
    ea('Object.keys(WB.TERRAIN_PENALTY).every(function(k){return !!WB.TERRAIN[k];})'));
  S.check('the banner cites pg.47',/pg\.47/.test(eb('String(pcBattleTerrainBanner)')));
  S.check('a cancelled penalty is not printed as "-0"',
    !/eases to \\u2212' \+ 0/.test(eb('String(pcBattleTerrainBanner)')));

  /* ── scenes ───────────────────────────────────────────────────────────
     Five saved scenes were built with kind names that were never defined —
     'hearth', 'table_long', 'table_round' — which resolved to no kind, no
     art, no fill and no cover. A barracks hearth rendered as an empty div
     and stopped nothing. */
  S.eq('no scene names a kind that does not exist',
    ea(`(function(){var b=[];BATTLE_SCENES.forEach(function(s){(s.st||[]).forEach(function(e){
      if(!WB.kind(e[0]) && b.indexOf(e[0])<0) b.push(s.id+':'+e[0]); });});return b;})()`).length,0);
  ['hearth','table_long','table_round'].forEach(k=>{
    S.check('"'+k+'" resolves to a kind',ea('!!WB.kind('+JSON.stringify(k)+')'));
    S.check('"'+k+'" resolves to art',ea('!!WB.propFor('+JSON.stringify(k)+',3,1)'));
    S.check('"'+k+'" renders as more than an empty div',
      ea('WB.stampHTML({k:'+JSON.stringify(k)+',x:1,y:1,w:3,h:1},true).length')>1000);
  });
  S.check('every scene stamp carries a level within the scene\u2019s range',
    ea(`(function(){var ok=true;BATTLE_SCENES.forEach(function(s){
      var top=(s.lv?s.lv.length:1)-1;
      (s.st||[]).forEach(function(e){ var l=e[6]||0; if(l<0||l>top) ok=false; });});return ok;})()`));
  S.check('every scene stamp sits inside its own grid',
    ea(`(function(){var ok=true;BATTLE_SCENES.forEach(function(s){
      (s.st||[]).forEach(function(e){
        if(e[1]<0||e[2]<0||e[1]+e[3]>s.w||e[2]+e[4]>s.h) ok=false; });});return ok;})()`));

  /* the Glass Forge, built to the Bandit Camp's level of detail */
  const gf=ea(`(function(){var x=BATTLE_SCENES.filter(function(b){return b.id==='glass_forge';})[0];
    if(!x) return null; var k={},lv={};
    x.st.forEach(function(e){k[e[0]]=1;lv[e[6]||0]=(lv[e[6]||0]||0)+1;});
    return {w:x.w,h:x.h,levels:x.lv.length,stamps:x.st.length,kinds:Object.keys(k).length,
            lv0:lv[0]||0,lv1:lv[1]||0,lv2:lv[2]||0};})()`);
  S.check('the Glass Forge scene exists',!!gf);
  if(gf){
    S.eq('it has the three levels gf3 calls for',gf.levels,3);
    S.check('every level is actually built ('+gf.lv0+'/'+gf.lv1+'/'+gf.lv2+')',
      gf.lv0>20&&gf.lv1>20&&gf.lv2>20);
    S.check('it is larger than the Bandit Camp ('+gf.w+'x'+gf.h+')',gf.w*gf.h>44*32);
    S.check('at least the Bandit Camp\u2019s detail ('+gf.stamps+' stamps, '+gf.kinds+' kinds)',
      gf.stamps>=95&&gf.kinds>=35);
    S.check('it has a way down and a way up',
      ea(`(function(){var x=BATTLE_SCENES.filter(function(b){return b.id==='glass_forge';})[0];
        var k=x.st.map(function(e){return e[0];});
        return k.indexOf('stairdown')>=0 && k.indexOf('stairup')>=0;})()`));
    S.check('it uses the forge art that had no home before',
      ea(`(function(){var x=BATTLE_SCENES.filter(function(b){return b.id==='glass_forge';})[0];
        var k=x.st.map(function(e){return e[0];});
        return ['glassfurnace','crucible','minecart','winch','portcullis'].every(function(n){
          return k.indexOf(n)>=0; });})()`));
  }

  /* ── scenes must be playable, not just drawn ───────────────────────────
     A level with no paired aperture cannot be reached at all: the Talgar Road
     shipped with its scramble points on the bank level only, so the banks
     that make it an ambush were unreachable. Some apertures are deliberately
     one-ended and say so in their label — vents, drains, roof hatches, ship
     holds, an open pit shaft that is a fall rather than a route, and a rope
     walkway that spans a single level rather than joining two. */
  const conn=ea(`(function(){
    return BATTLE_SCENES.filter(function(s){return (s.lv?s.lv.length:1)>1;}).map(function(s){
      var ap=(s.st||[]).filter(function(e){return WB.APERTURES[e[0]];})
        .map(function(e){return {k:e[0],x:e[1],y:e[2],w:e[3],h:e[4],lv:e[6]||0,l:String(e[5]||'')};});
      var routes={}, orph=[];
      ap.forEach(function(a){
        var mate=ap.filter(function(b){ return b!==a && Math.abs(b.lv-a.lv)===1 &&
          !(b.x+b.w<=a.x||a.x+a.w<=b.x||b.y+b.h<=a.y||a.y+a.h<=b.y); });
        if(mate.length){ var k=Math.min(a.lv,mate[0].lv)+'>'+Math.max(a.lv,mate[0].lv);
          routes[k]=(routes[k]||0)+1; }
        else if(!/vent|over the side|hold|sump|drain|roof|chute|hatch|shaft|walk|span|bridge|way in|off-map|approach/i.test(a.l))
          orph.push(s.id+':'+a.k+'@'+a.lv+' ('+a.l+')');
      });
      return {id:s.id, levels:s.lv.length, routes:routes, orphans:orph};
    });
  })()`);
  conn.forEach(c=>{
    S.eq('"'+c.id+'" has no unpaired connector ['+c.orphans.join(',')+']',c.orphans.length,0);
    for (let l=0; l<c.levels-1; l++){
      const k=l+'>'+(l+1);
      S.check('"'+c.id+'" level '+l+' reaches level '+(l+1),(c.routes[k]||0)>0);
    }
  });
  /* the four rebuilt for the Courier's Burden opening carry a real encounter */
  ['rd_ambush','luton_quay','gullet_siren','glass_forge'].forEach(id=>{
    const sc=ea('(function(){var s=BATTLE_SCENES.filter(function(x){return x.id==='+JSON.stringify(id)+';})[0];'
      +'if(!s)return null;return {sp:(s.sp||[]).reduce(function(a,x){return a+x[1];},0),'
      +'ct:(s.ct||[]).length,hz:(s.hz||[]).length,tr:(s.tr||[]).length,fg:(s.fg||[]).length,'
      +'ev:(s.ev||[]).length,stg:(s.stg||[]).length};})()');
    S.check('"'+id+'" arrives with its creatures placed ('+(sc&&sc.sp)+')',!!sc&&sc.sp>=5);
    S.check('"'+id+'" has loot containers',!!sc&&sc.ct>=3);
    S.check('"'+id+'" has hazards and traps',!!sc&&sc.hz>=1&&sc.tr>=1);
    S.check('"'+id+'" has named areas and elevation',!!sc&&sc.fg>=4&&sc.ev>=3);
    S.check('"'+id+'" has staged reveals',!!sc&&sc.stg>=2);
  });
  S.check('every spawned creature exists in the bestiary',
    ea(`(function(){var bad=0;BATTLE_SCENES.forEach(function(s){(s.sp||[]).forEach(function(x){
      if(!DEFAULT_BESTIARY.some(function(m){return m.name===x[0];})) bad++; });});return bad===0;})()`));
  S.check('every spawn point sits inside its scene',
    ea(`(function(){var ok=true;BATTLE_SCENES.forEach(function(s){(s.sp||[]).forEach(function(x){
      if(x[2]<0||x[3]<0||x[2]>=s.w||x[3]>=s.h) ok=false; });});return ok;})()`));
  S.check('a locked door carries a DC',
    ea(`(function(){var ok=true;BATTLE_SCENES.forEach(function(s){(s.st||[]).forEach(function(e){
      if(e[7]!=null && e[7]!=='locked' && typeof e[7]!=='number') ok=false; });});return ok;})()`));

  /* 7. toolbar */
  const grouped=ea('(function(){var s={};WB.GM_TOOL_GROUPS.forEach(function(g){'
    +'g.acts.forEach(function(a){s[a]=1;});});return Object.keys(s);})()');
  S.check('tool-select stays on the bar, not inside a category',grouped.indexOf('tool-select')<0);
  S.check('eff-panel is not a second entry for the effects tool',grouped.indexOf('eff-panel')<0);
  S.check('tool-eff is still grouped',grouped.indexOf('tool-eff')>=0);
  S.check('Build is no longer a third of the bar ('+ea('WB.GM_TOOL_GROUPS[0].acts.length')+')',
    ea('WB.GM_TOOL_GROUPS[0].acts.length')<=9);
  S.check('no group is empty',ea('WB.GM_TOOL_GROUPS.every(function(g){return g.acts.length>0;})'));

  process.exit(S.report()?0:1);
},6000);
