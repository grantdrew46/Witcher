/* Suite 12 — Merchant & Craftsman collaboration.
   Two players working one economy: the craftsman makes goods, the pair own
   ventures together, and the merchant sells. Checks the collaboration is
   actually wired rather than merely offered — a partner slot that is set but
   never read would look identical in the UI. */
const {boot,Suite}=require('../harness.js');
const S=Suite('12 merchant-craftsman');
const {dom,errs}=boot('/home/claude/W/sheet.html');

setTimeout(()=>{
  const ev=x=>{try{return dom.window.eval(x);}catch(e){return 'THREW: '+e.message;}};
  S.check('sheet boots clean',errs.length===0);

  ev(`(function(){
    window.toast=function(){};window.save=function(){};
    window.renderVitals=function(){};window.renderInventory=function(){};
    window.syncLogLine=function(){};window.renderTableLog=function(){};
    window.openModal=function(){};window.closeModal=function(){};
    window.renderVentures=function(){};window._ventureSyncPanel=function(){};
    window._renderHaggleModal=function(){};window.confirm=function(){return true;};
    window.renderCraftingList=function(){};window.syncSend=function(){};
    window.__merchant=function(){
      char.name='Yorveth';char.profession='Merchant';char.rep=6;
      char.stats={INT:8,REF:5,DEX:5,BODY:5,SPD:5,EMP:7,CRA:6,WILL:7,LUCK:4,STUN:7,
                  RUN:15,LEAP:3,STA:25,ENC:50,REC:5,HP:25,VIGOR:0};
      char.skills={Business:{val:6},Persuasion:{val:5},'Human Perception':{val:4},
        Charisma:{val:5},'Well Traveled':{val:4},Gambling:{val:3},Education:{val:3},
        Deceit:{val:3},'Resist Coercion':{val:4},Language:{val:2},'Small Blades':{val:2},
        Awareness:{val:3},Intimidation:{val:2},Brawling:{val:2}};
      char.crowns=2000;
      char.inventory=[{name:'Iron Long Sword',cost:160,qty:1,equipped:false,avail:'C'}];
      char.profSkillTree={};
      PROFESSIONS.Merchant.tree.paths.forEach(function(p,pi){
        (p.skills||[]).forEach(function(s,si){char.profSkillTree[pi+'-'+si]=1;});});
    };
    return true;})()`);
  ev('__merchant()');

  /* ── the profession ──────────────────────────────────────────────────── */
  S.eq('Merchant is a playable profession',ev('typeof PROFESSIONS.Merchant'),'object');
  S.eq('its defining skill is Well Traveled',ev('PROFESSIONS.Merchant.defSkill'),'Well Traveled');
  S.eq('rolled on INT',ev('PROFESSIONS.Merchant.defStat'),'INT');
  ['Charisma','Small Blades','Education','Language','Business','Persuasion',
   'Human Perception','Gambling','Resist Coercion'].forEach(sk=>{
    S.check('"'+sk+'" is a merchant skill',
      ev('PROFESSIONS.Merchant.skills.indexOf('+JSON.stringify(sk)+')')>=0);
    S.check('  and maps to a stat',
      /^(INT|REF|DEX|BODY|SPD|EMP|CRA|WILL|LUCK)$/.test(String(ev('getSkillStat('+JSON.stringify(sk)+')'))));
  });
  S.eq('three profession paths',ev('PROFESSIONS.Merchant.tree.paths.length'),3);
  S.check('one of them is the Concern line',
    ev('PROFESSIONS.Merchant.tree.paths.map(function(p){return p.name;}).indexOf("The Concern")')>=0);

  /* ── ventures ────────────────────────────────────────────────────────── */
  S.eq('the tree gates venture tier',ev('_concernTier()'),3);
  S.check('tier 3 grants slots ('+ev('_ventureSlots()')+')',ev('_ventureSlots()')>=3);
  S.check('the sheet knows this is a merchant',ev('_isMerchant()')===true);
  ['stall','route','fence','warehouse','tavern','forge','workshop','armory'].forEach(t=>{
    S.check('venture type "'+t+'" exists',ev('!!VENTURE_TYPES['+JSON.stringify(t)+']'));
  });
  S.check('forge and workshop want a craftsman partner',
    ev('!!VENTURE_TYPES.forge.craft && !!VENTURE_TYPES.workshop.craft'));
  /* The armoury used to return 0% and depend on the player consigning gear by
     hand, which nothing tracked and which made it read as a broken option in
     the picker. It now trades like any venture and works its own rack. */
  S.check('the armoury has a real return',
    ev('VENTURE_TYPES.armory.ret[0]>0 && VENTURE_TYPES.armory.ret[1]>0'));
  S.check('and still carries stock',ev('!!VENTURE_TYPES.armory.stock'));
  S.check('it can make its own stock',ev('typeof _ventureProduce')==='function');
  S.check('and the party can take a piece off the rack',ev('typeof ventureClaim')==='function');
  const shop=JSON.parse(ev(`(function(){
    __merchant(); char.crowns=0; char.inventory=[];
    char._ventures=[{id:'a1',type:'armory',name:'Shop',capital:600,myCapital:600,
      rep:0,weeks:0,earned:0,debt:0,closed:false,partner:null,partnerBiz:0,
      staffBiz:0,linkedTo:null,stock:[]}];
    ventureRunWeeks(26);
    var v=char._ventures[0];
    return JSON.stringify({earned:v.earned, rack:v.stock.length,
      named:v.stock.every(function(s){return !!s.name && s.val>0;})});})()`));
  S.check('it earns without anything being consigned ('+shop.earned+' cr)',shop.earned>0);
  /* the rack can legitimately be emptied by theft, so assert that the bench
     works rather than that stock happens to be standing at week 26 */
  S.check('the bench turns things out',
    ev(`(function(){
      var made=0, e={mult:1};
      for(var i=0;i<30;i++){
        if(_ventureProduce({rep:2,partner:null,stock:[]},20,15,e)) made++;
      }
      return made>0;})()`)===true);
  S.check('anything on the rack is a real named item',shop.named);
  S.check('and the shop never sells its last piece',
    ev(`_ventureSellStock({rep:5,stock:[{name:'A',val:100}]},20,10,{mult:1}).coin===0`));
  /* test the bench directly — after 26 random weeks the rack may have sold
     down to nothing, which made this assertion flaky rather than wrong */
  S.check('a craftsman partner marks what the shop makes',
    ev(`(function(){
      var withP={rep:5,partner:'Brouver',stock:[]}, without={rep:5,partner:null,stock:[]};
      var e={mult:1};
      var a=0,b=0;
      for(var i=0;i<30;i++){
        var p=_ventureProduce(withP,20,10,e); if(p&&p.certified) a++;
        var q=_ventureProduce(without,20,10,e); if(q&&q.certified) b++;
      }
      return a>0 && b===0;})()`)===true);
  S.check('and makes better things than a shop without one',
    ev(`(function(){
      var e={mult:1}, hi=0, lo=0;
      for(var i=0;i<40;i++){
        var p=_ventureProduce({rep:8,partner:'B',stock:[]},22,10,e);
        var q=_ventureProduce({rep:0,partner:null,stock:[]},12,10,e);
        if(p) hi+=p.val; if(q) lo+=q.val;
      }
      return hi>lo;})()`)===true);
  const claim=JSON.parse(ev(`(function(){
    __merchant(); char.crowns=800; char.inventory=[];
    char._ventures=[{id:'a3',type:'armory',name:'S',capital:600,myCapital:600,
      rep:0,weeks:0,earned:0,debt:0,closed:false,partner:null,partnerBiz:0,
      staffBiz:0,linkedTo:null,stock:[{name:'Iron Long Sword',val:160,certified:false}]}];
    window.prompt=function(){return '1';};
    var before=char.crowns;
    ventureClaim('a3');
    var it=char.inventory[0];
    return JSON.stringify({rack:char._ventures[0].stock.length, paid:before-char.crowns,
      name:it?it.name:null, dmg:it?it.dmg:null});})()`));
  S.eq('claiming takes it off the rack',claim.rack,0);
  S.eq('and puts it in the pack',claim.name,'Iron Long Sword');
  S.check('with its compendium stats ('+claim.dmg+')',!!claim.dmg);
  S.check('paid at cost, not retail ('+claim.paid+' of 160)',claim.paid>0&&claim.paid<160);

  const V=`{id:'v1',type:'forge',name:'Ironhand Forge',capital:900,rep:0,weeks:0,earned:0,
            debt:0,closed:false,partner:'Brouver',partnerBiz:16,staffBiz:0,linkedTo:null}`;
  S.eq('a partner adds 2 for the partnership itself',ev(`_ventureRollFor(${V}).bonus`),2);
  S.eq('the better Business of the two is used',ev(`_ventureRollFor(${V}).best`),16);
  S.eq('and the merchant\u2019s own is used when it is higher',
    ev(`_ventureRollFor(Object.assign(${V},{partnerBiz:3})).best`),14);
  S.eq('solo ventures get no partnership bonus',
    ev(`_ventureRollFor(Object.assign(${V},{partner:null,partnerBiz:0})).bonus`),0);
  S.check('hired staff stack on top',
    ev(`_ventureRollFor(Object.assign(${V},{staffBiz:4})).total`)
    > ev(`_ventureRollFor(${V}).total`));

  /* a year of trading pays, and reputation can climb */
  const year=JSON.parse(ev(`(function(){
    __merchant(); char.crowns=0;
    char._ventures=[${V}];
    ventureRunWeeks(52);
    var v=char._ventures[0];
    return JSON.stringify({earned:v.earned, rep:v.rep, weeks:v.weeks, crowns:char.crowns});})()`));
  S.eq('a year runs 52 weeks',year.weeks,52);
  S.check('a partnered forge turns a profit ('+year.earned+' cr)',year.earned>0);
  S.check('reputation can rise ('+year.rep+')',year.rep>0);
  S.check('reputation is clamped to 10',year.rep<=10);

  /* ── the craftsman's mark ────────────────────────────────────────────── */
  S.eq('a mark is worth 5% at low reputation',ev('_ventureMarkBonus({rep:0})'),5);
  S.eq('rising with the shop\u2019s standing',ev('_ventureMarkBonus({rep:5})'),20);
  S.eq('and capped at 25%',ev('_ventureMarkBonus({rep:10})'),25);
  /* the shop keeps one piece on the rack, so a fair test needs two */
  S.check('marked stock sells for more than unmarked',
    ev(`(function(){
      var e={mult:1};
      var marked=_ventureSellStock({rep:10,stock:[
        {name:'A',val:100,certified:true},{name:'B',val:100,certified:true}]},20,10,e);
      var plain =_ventureSellStock({rep:10,stock:[
        {name:'A',val:100,certified:false},{name:'B',val:100,certified:false}]},20,10,e);
      return marked.coin>plain.coin;})()`));
  S.check('and the shop never sells its last piece',
    ev(`_ventureSellStock({rep:5,stock:[{name:'A',val:100}]},20,10,{mult:1}).coin===0`));

  /* ── co-investment ────────────────────────────────────────────────────
     A partner brings two things and only one was modelled: their Business
     improved the roll, while their money was invisible and every crown of
     profit went to the founder. */
  /* nothing in the picker may read as a 0% venture */
  S.check('no venture type advertises a zero return',
    ev(`Object.keys(VENTURE_TYPES).every(function(k){
      var T=VENTURE_TYPES[k]; return T.ret && T.ret[1] > 0; })`));
  S.check('and the picker line never contains 0-0',
    ev(`Object.keys(VENTURE_TYPES).every(function(k){
      var T=VENTURE_TYPES[k];
      var earns=(T.ret&&T.ret[1]>0)?('returns '+T.ret[0]+'-'+T.ret[1]+'%')
        :(T.stock?'no weekly % - earns from stock':'no weekly return');
      return earns.indexOf('0-0')<0; })`));

  const CO=`{id:'v9',type:'forge',name:'Co',capital:1000,myCapital:600,
    partnerCapital:400,partnerShare:40,rep:0,weeks:0,earned:0,debt:0,closed:false,
    partner:'Brouver',partnerBiz:16,staffBiz:0,linkedTo:null}`;
  const yr=JSON.parse(ev(`(function(){
    __merchant(); char.crowns=0; char._ventures=[${CO}];
    ventureRunWeeks(52);
    var v=char._ventures[0];
    return JSON.stringify({banked:char.crowns, paid:v.partnerPaid||0});})()`));
  S.check('the venture earns something ('+(yr.banked+yr.paid)+' cr)',yr.banked+yr.paid>0);
  S.check('the partner is paid their share ('+yr.paid+' cr)',yr.paid>0);
  const pct=Math.round(yr.paid/(yr.banked+yr.paid)*100);
  S.check('and it is close to the agreed 40% (got '+pct+'%)',pct>=37&&pct<=43);
  S.check('the party banks only its own portion',yr.banked<yr.banked+yr.paid);
  S.eq('winding up returns half of your stake, not half of the business',
    ev(`(function(){
      __merchant(); char.crowns=0; char._ventures=[${CO}];
      window.confirm=function(){return true;};
      ventureClose('v9');
      return char.crowns;})()`),300);
  S.check('a silent partner takes nothing but still helps the roll',
    ev(`(function(){
      __merchant(); char.crowns=0;
      char._ventures=[{id:'v8',type:'stall',name:'S',capital:400,myCapital:400,
        partnerCapital:0,partnerShare:0,rep:0,weeks:0,earned:0,debt:0,closed:false,
        partner:'Brouver',partnerBiz:16,staffBiz:0,linkedTo:null}];
      var bonus=_ventureRollFor(char._ventures[0]).bonus;
      ventureRunWeeks(20);
      return bonus===2 && (char._ventures[0].partnerPaid||0)===0 && char.crowns>0;})()`)===true);
  S.check('a solo venture is unaffected',
    ev(`(function(){
      __merchant(); char.crowns=0;
      char._ventures=[{id:'v7',type:'stall',name:'S',capital:400,myCapital:400,
        rep:0,weeks:0,earned:0,debt:0,closed:false,partner:null,partnerBiz:0,
        staffBiz:0,linkedTo:null}];
      ventureRunWeeks(20);
      return (char._ventures[0].partnerPaid||0)===0 && char.crowns>0;})()`)===true);

  /* ── capital and the table log ────────────────────────────────────────
     Capital was capped per type, so a forge could never take more than 1500
     however rich the party got. And a venture week resolved silently in one
     player's ledger, which is the wrong place for a shared fiction. */
  S.check('no venture type carries an upper capital cap that binds',
    ev(`(function(){
      // the founder no longer reads cap[1]; a 25000 cr stall must be possible
      return typeof ventureFound === 'function'
        && String(ventureFound).indexOf('cap[1]') < 0; })()`)===true);
  S.check('the floor is 500',String(ev('String(ventureFound)')).indexOf('MIN_CAP = 500')>=0);
  const bcast=JSON.parse(ev(`(function(){
    __merchant(); char.crowns=0;
    window.__sent=[]; window.syncSend=function(o){window.__sent.push(o);};
    window._sync={connected:true,name:'Yorveth',log:[],id:'p1'};
    window.syncLogLine=function(){};
    char._ventures=[{id:'b1',type:'forge',name:'F',capital:900,myCapital:900,rep:0,weeks:0,
      earned:0,debt:0,closed:false,partner:'Brouver',partnerBiz:16,staffBiz:0,linkedTo:null}];
    ventureRunWeeks(2);
    var rolls=window.__sent.filter(function(m){return m.t==='roll';});
    return JSON.stringify({rolls:rolls.length,
      summary:window.__sent.filter(function(m){return m.t==='event';}).length,
      hasNote:rolls.every(function(m){return /\u00b7/.test(m.detail||'');}),
      hasDC:rolls.every(function(m){return /vs DC/.test(m.detail||'');}),
      namesPartner:rolls.every(function(m){return /Brouver/.test(m.label||'');})});})()`));
  S.eq('a two-week run broadcasts both weeks',bcast.rolls,2);
  S.eq('and one closing summary',bcast.summary,1);
  S.check('each roll shows the DC it was against',bcast.hasDC);
  S.check('each carries the event description',bcast.hasNote);
  S.check('and names the partner',bcast.namesPartner);
  S.check('a long run sends only the summary',
    ev(`(function(){
      __merchant(); char.crowns=0;
      window.__sent=[]; window.syncSend=function(o){window.__sent.push(o);};
      window._sync={connected:true,name:'Y',log:[],id:'p1'};
      window.syncLogLine=function(){};
      char._ventures=[{id:'b2',type:'stall',name:'S',capital:500,myCapital:500,rep:0,weeks:0,
        earned:0,debt:0,closed:false,partner:null,partnerBiz:0,staffBiz:0,linkedTo:null}];
      ventureRunWeeks(52);
      return window.__sent.length===1;})()`)===true);
  S.check('nothing is sent when not connected',
    ev(`(function(){
      __merchant(); char.crowns=0;
      window.__sent=[]; window.syncSend=function(o){window.__sent.push(o);};
      window._sync={connected:false,name:'Y',log:[],id:'p1'};
      window.syncLogLine=function(){};
      char._ventures=[{id:'b3',type:'stall',name:'S',capital:500,myCapital:500,rep:0,weeks:0,
        earned:0,debt:0,closed:false,partner:null,partnerBiz:0,staffBiz:0,linkedTo:null}];
      ventureRunWeeks(2);
      return window.__sent.length===0;})()`)===true);

  /* ── investment bands ─────────────────────────────────────────────────
     A merchant rolls INT + Business + d10, so around 20 before a partner.
     The printed risk DCs of 14-18 were never a real question, which made a
     large stake strictly better than a small one. */
  S.check('bands exist',ev('Array.isArray(VENTURE_BANDS)')===true);
  S.check('there are at least four',ev('VENTURE_BANDS.length')>=4);
  S.check('the DC rises with the stake',
    ev(`_ventureBand(20000).dc > _ventureBand(8000).dc
        && _ventureBand(8000).dc > _ventureBand(2000).dc
        && _ventureBand(2000).dc > _ventureBand(500).dc`));
  S.check('and so does the payout',
    ev(`_ventureBand(20000).pay > _ventureBand(8000).pay
        && _ventureBand(8000).pay > _ventureBand(2000).pay
        && _ventureBand(2000).pay > _ventureBand(500).pay`));
  S.eq('a modest stake is unchanged',ev('_ventureBand(500).dc'),0);
  S.eq('and pays as printed',ev('_ventureBand(500).pay'),1);
  S.check('the largest band is a real question against a ~20 roll',
    ev('VENTURE_TYPES.stall.risk + _ventureBand(20000).dc')>=22);
  S.check('a big stake can actually go wrong',
    ev(`(function(){
      __merchant(); char.crowns=0;
      char._ventures=[{id:'z',type:'stall',name:'S',capital:20000,myCapital:20000,rep:0,
        weeks:0,earned:0,debt:0,closed:false,partner:null,partnerBiz:0,staffBiz:0,linkedTo:null}];
      var fails=0;
      for(var i=0;i<40;i++){
        var before=char._ventures[0].earned;
        ventureRunWeeks(1);
        if(char._ventures[0].earned===before) fails++;
      }
      return fails>0;})()`)===true);

  /* ── the table gets the whole account, not the headline ────────────── */
  /* a single week can legitimately be a catastrophe with no coin, no sale and
     no partner cut, so gather several four-week runs and assert every element
     appears somewhere across them */
  const acct=JSON.parse(ev(`(function(){
    var all=[], n=0;
    for (var t=0; t<12; t++){
      __merchant(); char.crowns=0;
      window.__sent=[]; window.syncSend=function(o){window.__sent.push(o);};
      window._sync={connected:true,name:'Y',log:[],id:'p1'};
      window.syncLogLine=function(){};
      char._ventures=[{id:'acc',type:'armory',name:'Shop',capital:6000,myCapital:4000,
        partnerCapital:2000,partnerShare:35,rep:6,weeks:0,earned:0,debt:0,closed:false,
        partner:'Brouver',partnerBiz:16,staffBiz:0,linkedTo:null,
        stock:[{name:'Iron Long Sword',val:160,certified:true},
               {name:'Brigandine',val:120,certified:true},
               {name:'Gambeson',val:90,certified:true}]}];
      ventureRunWeeks(4);
      var rolls=window.__sent.filter(function(m){return m.t==='roll';});
      n+=rolls.length;
      all.push(rolls.map(function(m){return m.detail;}).join(' ~ '));
    }
    return JSON.stringify({n:n, detail:all.join(' ~ ')});})()`));
  S.check('the week is broadcast',acct.n>0);
  S.check('with the DC',/vs DC \d+/.test(acct.detail));
  S.check('the coin',/\d+ cr/.test(acct.detail));
  S.check('the stake and its band',/stake \(\d+ cr/.test(acct.detail));
  S.check('the event description',/\u00b7 [A-Z][^\u00b7]{6,}/.test(acct.detail));
  S.check('the partner\u2019s share',/to Brouver \(35%\)/.test(acct.detail));
  S.check('and what the shop sold or made',
    /sold:|turned out/.test(acct.detail));

  /* ── cancelling must never destroy the flow ───────────────────────────
     "This venture needs a craftsman partner. Do you have one?" answered No
     used to abort the whole thing silently, after the player had chosen a
     type and committed a figure. Cancelling the capital prompt reported
     "needs at least 500 cr behind it", which was not what happened. */
  const stage=(cfg)=>JSON.parse(ev(`(function(){
    __merchant(); char.crowns=50000; char._ventures=[]; window.__t='';
    window.toast=function(t){ window.__t=t; };
    var c=${cfg};
    window.prompt=function(q,def){
      if(/Found a venture/.test(q)) return c.type===null?null:'6';
      if(/Capital to invest/.test(q)) return c.capital===null?null:'3000';
      if(/Name it/.test(q)) return c.name===null?null:'Test';
      if(/Partner name/.test(q)) return c.pname===null?null:'Brouver';
      if(/Business \\+ INT/.test(q)) return c.pbiz===null?null:'16';
      if(/Crowns they are putting in/.test(q)) return c.pcap===null?null:'1000';
      if(/share of the takings/.test(q)) return c.pshare===null?null:'40';
      return def; };
    window.confirm=function(q){
      if(/craftsman partner/.test(q)) return !c.craftNo;
      if(/Bring a partner/.test(q)) return !c.partnerNo;
      return true; };
    var threw=null;
    try{ ventureFound(); }catch(e){ threw=String(e.message); }
    var v=(char._ventures||[])[0];
    return JSON.stringify({threw:threw, founded:!!v, partner:v?v.partner:null,
      share:v?v.partnerShare:null, risk:v?(v.riskMod||0):null,
      toast:String(window.__t)});})()`));

  [['the type list','{type:null}'],['the capital prompt','{capital:null}'],
   ['the partner name','{pname:null}'],['their Business','{pbiz:null}'],
   ['their capital','{pcap:null}'],['the share split','{pshare:null}'],
   ['the name prompt','{name:null}']].forEach(function(pair){
    const r=stage(pair[1]);
    S.check('cancelling '+pair[0]+' does not throw',!r.threw);
  });
  ['{craftNo:true}','{partnerNo:true}'].forEach(function(cfg){
    const r=stage(cfg);
    S.check('answering no does not throw '+cfg,!r.threw);
    S.check('  and still founds the venture '+cfg,r.founded);
  });
  S.check('cancelling the type list says so rather than failing silently',
    /No venture founded/.test(stage('{type:null}').toast));
  S.check('cancelling capital does not claim the figure was too small',
    !/at least/.test(stage('{capital:null}').toast));
  S.check('no craftsman founds it short-handed instead of aborting',
    stage('{craftNo:true,partnerNo:true}').risk===2);
  S.check('a short-handed venture still trades',
    ev(`(function(){
      __merchant(); char.crowns=0;
      char._ventures=[{id:'sh',type:'forge',name:'Cold',capital:3000,myCapital:3000,
        riskMod:2,shortHanded:true,rep:0,weeks:0,earned:0,debt:0,closed:false,
        partner:null,partnerBiz:0,staffBiz:0,linkedTo:null}];
      ventureRunWeeks(12);
      return char._ventures[0].earned>0;})()`)===true);
  S.check('and a craftsman removes the penalty',
    stage('{craftNo:false}').risk===0);
  S.check('cancelling the share keeps the suggested split, not zero',
    stage('{pshare:null}').share>0);
  S.check('cancelling the partner name means no partner, not a broken one',
    stage('{pname:null}').partner===null);

  /* ── the haggle ──────────────────────────────────────────────────────── */
  ev('__merchant(); window._haggle=null; openHaggle(0);');
  S.check('a haggle opens',ev('!!window._haggle'));
  S.check('the merchant is flagged in it',ev('!!window._haggle.merchant'));
  S.eq('merchants get a fourth round',ev('window._haggle.maxRounds'),4);
  S.check('and see the true market value',ev('!!window._haggle.trueValue'));
  S.eq('and a price floor beneath them',ev('window._haggle.floor'),ev('MERCHANT_FLOOR'));
  ['_haggleReadRoom','_haggleUndercut','_haggleVouch','_haggleCertify','_haggleDeceive',
   '_haggleBribe','_haggleExchange','_haggleRenegotiate','_haggleSlate','_haggleBrawl',
   '_haggleAskPartner','_haggleAssistSet','_haggleAccept','_haggleFinalize','_haggleRiskRep']
   .forEach(f=>S.eq('tactic '+f.replace('_haggle','')+' exists',ev('typeof '+f),'function'));

  /* the partner is not just decoration */
  const before=ev('(function(){__merchant();window._haggle=null;openHaggle(0);return window._haggle.ceiling;})()');
  ev(`_haggleAssistSet('Brouver Ironhand',14)`);
  S.check('an assist can be registered',ev('!!window._haggle.assist'));
  ev('_haggleCertify()');
  S.check('his mark raises the ceiling ('+before+'% \u2192 '+ev('window._haggle.ceiling')+'%)',
    ev('window._haggle.ceiling')>before);
  ev('_haggleVouch()');
  S.eq('a vouch banks his full Business',ev('window._haggle.vouchBonus'),14);
  S.check('and cannot be spent twice',
    ev(`(function(){var b=window._haggle.vouchBonus;_haggleVouch();
      return window._haggle.vouchBonus===b;})()`));
  S.check('an exchange consumes it',
    ev(`(function(){_haggleExchange();return (window._haggle.vouchBonus||0)===0;})()`));

  /* every tactic survives being called */
  ['_haggleReadRoom()','_haggleUndercut()','_haggleCertify()','_haggleDeceive()',
   '_haggleSlate()','_haggleRenegotiate()','_haggleExchange()'].forEach(call=>{
    S.check(call.replace('_haggle','')+' runs without throwing',
      ev(`(function(){__merchant();window._haggle=null;openHaggle(0);
        _haggleAssistSet('Brouver',14);
        try{ ${call}; return true; }catch(e){ return false; }})()`)===true);
  });

  /* a sale settles and moves the goods */
  const sale=JSON.parse(ev(`(function(){
    __merchant(); window._haggle=null; openHaggle(0);
    _haggleAssistSet('Brouver',14); _haggleCertify(); _haggleVouch();
    var H=window._haggle;
    for(var i=0;i<H.maxRounds;i++){ _haggleExchange(); if(window._haggle.finished) break; }
    var before=char.crowns, items=char.inventory.length;
    _haggleAccept(); _haggleFinalize();
    return JSON.stringify({paid:char.crowns-before, itemsBefore:items,
      itemsAfter:char.inventory.length, cleared:window._haggle===null});})()`));
  S.check('the sale pays out ('+sale.paid+' cr on a 160 cr sword)',sale.paid>0);
  S.eq('the item leaves inventory',sale.itemsAfter,sale.itemsBefore-1);
  S.check('and the haggle closes',sale.cleared);
  S.check('the price respects the floor',sale.paid>=Math.round(160*ev('MERCHANT_FLOOR')/100));

  /* ── the craftsman's side ────────────────────────────────────────────── */
  S.check('there are diagrams to work from',
    ev(`getAllCompData().filter(function(c){return c.type==='recipe';}).length`)>100);
  const craft=JSON.parse(ev(`(function(){
    char.inventory=[];
    var r=getAllCompData().filter(function(c){
      return c.type==='recipe' && c.result==='Iron Long Sword';})[0];
    if(!r) return JSON.stringify({none:true});
    _addCraftedItem(r);
    var it=char.inventory[0];
    return JSON.stringify({name:it.name, dmg:it.dmg, from:it.craftedFrom,
      needs:(r.components||[]).length, dc:r.dc});})()`));
  S.check('a diagram exists for a common sword',!craft.none);
  S.eq('crafting it yields the right item',craft.name,'Iron Long Sword');
  S.check('with its damage from the compendium',!!craft.dmg);
  S.check('and a record of what it was made from',!!craft.from);
  S.check('the diagram lists its components',craft.needs>0);
  S.check('and carries a DC',craft.dc>0);

  process.exit(S.report()?0:1);
},6000);
