/* Suite 01 — Critical wound location (pg.158)
   Rule under test: an AIMED critical ALWAYS lands where aimed.
   The 1d6 only chooses between that location's two table entries:
   5-6 greater, 1-4 lesser.  Head 11/12, Torso 6-8 / 9-10, Arms 4-5, Legs 2-3. */
const {boot,Suite}=require('../harness.js');
const S=Suite('01 crit-location (pg.158)');
const {dom,window:w,errs}=boot(process.env.SHEET||'/home/claude/W/sheet.html');

setTimeout(()=>{
  const ev=s=>dom.window.eval(s);
  const LEVELS=ev('Object.keys(CRIT_WOUNDS)');           // Simple/Complex/Difficult/Deadly
  const face=f=>{ const o=w.Math.random; w.Math.random=()=>((f-1)/6)+0.01; return ()=>{w.Math.random=o;}; };
  const loc=(id,label)=>({id:id,label:label||id});

  S.check('boot clean',errs.length===0);
  S.check('CRIT_WOUNDS has 4 levels',LEVELS.length===4);

  /* A. location bands from a 2d6 total */
  const bands={2:'Leg',3:'Leg',4:'Arm',5:'Arm',6:'Torso',7:'Torso',8:'Torso',
               9:'Torso',10:'Torso',11:'Head',12:'Head'};
  Object.keys(bands).forEach(t=>
    S.eq('critLocationFromTotal('+t+')',w.critLocationFromTotal(+t),bands[t]));

  /* B-E. aimed resolution per level, per d6 face */
  LEVELS.forEach(L=>{
    for(let f=1;f<=6;f++){
      const greater=f>=5, undo=face(f);
      try{
        const h=w.resolveAimedCritWound(L,loc('head','Head'));
        S.eq(L+' aimed head d6='+f,h&&h.wound&&h.wound.roll,greater?'12':'11');
        S.check(L+' aimed head d6='+f+' is a wound',h&&h.mode==='wound'&&!!h.wound);

        const t=w.resolveAimedCritWound(L,loc('torso','Torso'));
        S.eq(L+' aimed torso d6='+f,t&&t.wound&&t.wound.roll,greater?'9\u201310':'6\u20138');

        ['r_arm','l_arm'].forEach(a=>{
          const r=w.resolveAimedCritWound(L,loc(a,'Arm'));
          S.eq(L+' aimed '+a+' d6='+f,r&&r.wound&&r.wound.roll,'4\u20135');
        });
        ['r_leg','l_leg'].forEach(a=>{
          const r=w.resolveAimedCritWound(L,loc(a,'Leg'));
          S.eq(L+' aimed '+a+' d6='+f,r&&r.wound&&r.wound.roll,'2\u20133');
        });

        /* F. monster limbs: pg.158 rolls 1d6 only for Torso/Head, so a limb
           takes its wound with no roll. Mapped to Arm (GM decision). */
        ['r_limb','l_limb'].forEach(k=>{
          const lm=w.resolveAimedCritWound(L,loc(k,'Limb'));
          S.eq(L+' aimed '+k+' d6='+f+' (no roll, Arm)',lm&&lm.wound&&lm.wound.roll,'4\u20135');
        });
        /* Special (roll 10) is treated as Torso with a d6 - house rule, not pg.158 */
        const sp=w.resolveAimedCritWound(L,loc('special','Special'));
        S.eq(L+' aimed special d6='+f,sp&&sp.wound&&sp.wound.roll,greater?'9\u201310':'6\u20138');
      } finally { undo(); }
    }
  });

  /* G. no aim location */
  S.eq('null aimLoc returns null',w.resolveAimedCritWound('Simple',null),null);

  /* G2. a limb never comes back as a leg wound now */
  LEVELS.forEach(L=>{
    let bad=0;
    for(let i=0;i<200;i++){
      const r=w.resolveAimedCritWound(L,loc('r_limb','Limb'));
      if(!r||!r.wound||r.wound.roll!=='4\u20135') bad++;
    }
    S.check(L+' 200 aimed-limb rolls always give the Arm entry (bad='+bad+')',bad===0);
  });

  /* H. invariant sweep — aimed head can NEVER produce a non-head wound */
  LEVELS.forEach(L=>{
    let bad=0,nulls=0;
    for(let i=0;i<300;i++){
      const r=w.resolveAimedCritWound(L,loc('head','Head'));
      if(!r||!r.wound){nulls++;continue;}
      if(r.wound.roll!=='11'&&r.wound.roll!=='12') bad++;
    }
    S.check(L+' 300 aimed-head rolls never leave the head (bad='+bad+')',bad===0);
    S.check(L+' 300 aimed-head rolls never return a null wound (null='+nulls+')',nulls===0);
  });

  /* I. every aimed range resolves to a real table entry, all levels */
  const ranges=['12','11','9\u201310','6\u20138','4\u20135','2\u20133'];
  LEVELS.forEach(L=>ranges.forEach(r=>{
    const wd=w.woundByRollRange(L,r);
    S.check('woundByRollRange('+L+',"'+r+'") resolves',!!wd&&!!wd.name);
  }));

  /* J. both faces of the coin are actually reachable (not hardcoded to one) */
  LEVELS.forEach(L=>{
    const seen={};
    for(let i=0;i<300;i++){
      const r=w.resolveAimedCritWound(L,loc('torso','Torso'));
      if(r&&r.wound) seen[r.wound.roll]=1;
    }
    S.check(L+' aimed torso reaches both greater and lesser',
      seen['9\u201310']&&seen['6\u20138']);
  });

  process.exit(S.report()?0:1);
},4500);
