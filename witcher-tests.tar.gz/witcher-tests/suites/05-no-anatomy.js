/* Suite 05 — Monsters Without Anatomy (pg.159)
   Elementa and specters have no organs: Foreign Object, Ruptured Spleen,
   Torn Stomach, Sucking Chest Wound and Septic Shock cannot land on them.
   The strike does bonus damage instead — Simple +5, Complex +10,
   Difficult +15, Deadly +20. Specters are also immune to leg strikes. */
const {boot,Suite}=require('../harness.js');
const S=Suite('05 no-anatomy (pg.159)');
const A=boot('/home/claude/W/sheet.html');
const B=boot('/home/claude/W/gm.html');

setTimeout(()=>{
  const ea=s=>A.dom.window.eval(s), eb=s=>B.dom.window.eval(s);
  S.check('sheet boots clean',A.errs.length===0);
  S.check('gm boots clean',B.errs.length===0);

  /* 1. the helpers exist and agree across both apps */
  ['NO_ANATOMY_WOUNDS','NO_ANATOMY_BONUS','NO_ANATOMY_TYPES'].forEach(k=>{
    S.eq(k+' identical in both files',ea('JSON.stringify(WB.'+k+')'),eb('JSON.stringify(WB.'+k+')'));
  });
  S.eq('five substituted wounds',ea('WB.NO_ANATOMY_WOUNDS.length'),5);
  [['Simple',5],['Complex',10],['Difficult',15],['Deadly',20]].forEach(([l,b])=>
    S.eq('bonus for '+l,ea('WB.NO_ANATOMY_BONUS.'+l),b));

  /* 2. type detection */
  ['elementa','specter','Specter','ELEMENTA'].forEach(t=>
    S.check('hasNoAnatomy("'+t+'")',ea('WB.hasNoAnatomy('+JSON.stringify(t)+')')===true));
  ['beast','necrophage','draconid','humanoid','vampire','relict','',null].forEach(t=>
    S.check('hasNoAnatomy('+JSON.stringify(t)+') is false',
      ea('WB.hasNoAnatomy('+JSON.stringify(t)+')')===false));
  S.check('skipsLegs specter',ea('WB.skipsLegs("specter")')===true);
  S.check('skipsLegs elementa is false (they have legs)',ea('WB.skipsLegs("elementa")')===false);

  /* 3. substitution matrix */
  const LV=['Simple','Complex','Difficult','Deadly'];
  const SUB=ea('JSON.parse(JSON.stringify(WB.NO_ANATOMY_WOUNDS))');
  LV.forEach(L=>{
    SUB.forEach(wn=>{
      ['elementa','specter'].forEach(t=>{
        const r=ea('WB.noAnatomySub('+JSON.stringify(L)+','+JSON.stringify(wn)+','+JSON.stringify(t)+')');
        S.check(L+'/'+t+'/'+wn+' substitutes',!!r);
        if(r) S.eq(L+'/'+t+'/'+wn+' bonus',r.bonus,ea('WB.NO_ANATOMY_BONUS.'+L));
      });
      S.eq(L+'/beast/'+wn+' does NOT substitute',
        ea('WB.noAnatomySub('+JSON.stringify(L)+','+JSON.stringify(wn)+',"beast")'),null);
    });
    /* wounds that are NOT organ damage still land on them */
    ['Cracked Jaw','Sprained Arm','Damaged Eye','Concussion','Heart Damage'].forEach(wn=>
      S.eq(L+'/specter/'+wn+' still lands',
        ea('WB.noAnatomySub('+JSON.stringify(L)+','+JSON.stringify(wn)+',"specter")'),null));
  });

  /* 4. every substituted name must exist in the real crit tables */
  SUB.forEach(wn=>{
    S.check('"'+wn+'" is a real wound in the GM tables',
      eb('Object.keys(CRIT_TABLES).some(function(L){'
        +'return CRIT_TABLES[L].some(function(e){return e.name==='+JSON.stringify(wn)+';});})')===true);
    S.check('"'+wn+'" is mapped to the torso',
      eb('CRIT_WOUND_LOCATION['+JSON.stringify(wn)+']')==='torso');
  });

  /* 4b. the five substituted wounds sit one per level, except Difficult which
     holds two (Torn Stomach and Sucking Chest Wound) — pg.158-160 tables. */
  const dist={Simple:['Foreign Object'],Complex:['Ruptured Spleen'],
              Difficult:['Torn Stomach','Sucking Chest Wound'],Deadly:['Septic Shock']};
  Object.keys(dist).forEach(L=>{
    const got=eb('CRIT_TABLES['+JSON.stringify(L)+'].map(function(e){return e.name;})'
      +'.filter(function(n){return WB.NO_ANATOMY_WOUNDS.indexOf(n)>=0;})');
    S.eq(L+' substituted wounds',got.sort(),dist[L].slice().sort());
  });
  S.eq('all five are accounted for across the four tables',
    Object.keys(dist).reduce((a,k)=>a+dist[k].length,0),5);

  /* 5. specter leg reroll — the whole point is that legs never come back */
  LV.forEach(L=>{
    const legs=eb('(function(){var n=0;for(var i=0;i<400;i++){'
      +'var cw=rollCritWound('+JSON.stringify(L)+',false,"specter");'
      +'if(CRIT_WOUND_LOCATION[cw.wound.name]==="leg") n++;}return n;})()');
    S.eq(L+' 400 specter crits yield no leg wounds',legs,0);
    const legs2=eb('(function(){var n=0;for(var i=0;i<400;i++){'
      +'var cw=rollCritWound('+JSON.stringify(L)+',false,"beast");'
      +'if(CRIT_WOUND_LOCATION[cw.wound.name]==="leg") n++;}return n;})()');
    S.check(L+' a beast still takes leg wounds ('+legs2+'/400)',legs2>0);
    /* omitting the type must not change legacy behaviour */
    const legs3=eb('(function(){var n=0;for(var i=0;i<400;i++){'
      +'var cw=rollCritWound('+JSON.stringify(L)+',false);'
      +'if(CRIT_WOUND_LOCATION[cw.wound.name]==="leg") n++;}return n;})()');
    S.check(L+' no creature type = unchanged behaviour ('+legs3+'/400)',legs3>0);
  });
  S.check('reroll still returns a valid wound every time',
    eb('(function(){for(var i=0;i<300;i++){var cw=rollCritWound("Deadly",false,"specter");'
      +'if(!cw||!cw.wound||!cw.wound.name) return false;}return true;})()')===true);

  /* 6. the ten affected creatures are actually typed that way in the bestiary */
  const n=eb('DEFAULT_BESTIARY.filter(function(b){return WB.hasNoAnatomy(b.type);}).length');
  S.check('bestiary contains no-anatomy creatures (found '+n+')',n>0);
  S.check('Wraith is one of them',
    eb('(function(){var b=DEFAULT_BESTIARY.find(function(x){return x.name==="Wraith";});'
      +'return !!b&&WB.hasNoAnatomy(b.type);})()')===true);
  S.check('Golem is one of them',
    eb('(function(){var b=DEFAULT_BESTIARY.find(function(x){return x.name==="Golem";});'
      +'return !!b&&WB.hasNoAnatomy(b.type);})()')===true);
  S.check('a Nekker is not',
    eb('(function(){var b=DEFAULT_BESTIARY.find(function(x){return /Nekker/.test(x.name);});'
      +'return !b||!WB.hasNoAnatomy(b.type);})()')===true);

  process.exit(S.report()?0:1);
},6000);
