/* Suite 03 — The crit rule lives in two places. They must agree.
     sheet:  resolveAimedCritWound(level, aimLoc)      ids: head torso r_arm l_arm r_leg l_leg r_limb l_limb
     WB:     WB.aimedCrit(table, locationId, d6)       ids: head torso rarm larm rleg lleg rlimb llimb
     WB:     WB.critForLocation(table, locId, 2d6)     unaimed - still follows the struck location
   Settled: aimed crits always land where aimed; d6 5-6 greater, 1-4 lesser.
   Unaimed crits also follow the struck location; the roll only picks between
   that location's entries. */
const {boot,Suite}=require('../harness.js');
const S=Suite('03 crit-parity (pg.158)');
const {dom,errs}=boot('/home/claude/W/sheet.html');

setTimeout(()=>{
  const ev=s=>dom.window.eval(s);
  const LEVELS=ev('Object.keys(CRIT_WOUNDS)');
  S.check('boot clean',errs.length===0);

  /* 1. band table integrity */
  const bands=ev('JSON.parse(JSON.stringify(WB.AIM_CRIT_BANDS))');
  S.eq('head bands',bands.head,['11','12']);
  S.eq('torso bands',bands.torso,['6\u20138','9\u201310']);
  ['rarm','larm'].forEach(k=>S.eq(k+' bands',bands[k],['4\u20135']));
  ['rleg','lleg'].forEach(k=>S.eq(k+' bands',bands[k],['2\u20133']));
  S.check('every band string exists in every crit level table',
    LEVELS.every(L=>Object.keys(bands).every(k=>
      bands[k].every(b=>ev('!!woundByRollRange('+JSON.stringify(L)+','+JSON.stringify(b)+')')))));

  /* 2. LOC_TO_CRIT must translate every id the sheet side uses */
  const sheetIds=['head','torso','r_arm','l_arm','r_leg','l_leg','r_limb','l_limb'];
  sheetIds.forEach(id=>{
    const k=ev('WB.LOC_TO_CRIT['+JSON.stringify(id)+']');
    S.check('LOC_TO_CRIT maps "'+id+'" -> a real band ('+k+')',!!k&&!!bands[k]);
  });

  /* 3. WB.aimedCrit honours 5-6 greater / 1-4 lesser at every level */
  LEVELS.forEach(L=>{
    for(let d=1;d<=6;d++){
      const g=d>=5;
      const h=ev('WB.aimedCrit(CRIT_WOUNDS['+JSON.stringify(L)+'],"head",'+d+')');
      S.eq(L+' WB.aimedCrit head d6='+d,h&&h.band,g?'12':'11');
      S.eq(L+' WB.aimedCrit head tier d6='+d,h&&h.tier,g?'greater':'lesser');
      const t=ev('WB.aimedCrit(CRIT_WOUNDS['+JSON.stringify(L)+'],"torso",'+d+')');
      S.eq(L+' WB.aimedCrit torso d6='+d,t&&t.band,g?'9\u201310':'6\u20138');
      ['rarm','larm'].forEach(k=>{
        const r=ev('WB.aimedCrit(CRIT_WOUNDS['+JSON.stringify(L)+'],'+JSON.stringify(k)+','+d+')');
        S.eq(L+' WB.aimedCrit '+k+' d6='+d,r&&r.band,'4\u20135');
        S.eq(L+' WB.aimedCrit '+k+' tier',r&&r.tier,'only');
      });
      ['rleg','lleg'].forEach(k=>{
        const r=ev('WB.aimedCrit(CRIT_WOUNDS['+JSON.stringify(L)+'],'+JSON.stringify(k)+','+d+')');
        S.eq(L+' WB.aimedCrit '+k+' d6='+d,r&&r.band,'2\u20133');
      });
    }
  });

  /* 4. underscore ids must not silently return null */
  ['r_arm','l_arm','r_leg','l_leg','r_limb','l_limb'].forEach(id=>{
    const raw=ev('WB.aimedCrit(CRIT_WOUNDS.Simple,'+JSON.stringify(id)+',3)');
    S.check('WB.aimedCrit("'+id+'") does not silently return null',raw!==null);
  });

  /* 5. UNAIMED: the wound must belong to the struck location, for every 2d6 total */
  const expect={head:['11','12'],torso:['6\u20138','9\u201310'],
    r_arm:['4\u20135'],l_arm:['4\u20135'],r_leg:['2\u20133'],l_leg:['2\u20133']};
  LEVELS.forEach(L=>{
    Object.keys(expect).forEach(loc=>{
      let ok=true,seen={};
      for(let r=2;r<=12;r++){
        const res=ev('WB.critForLocation(CRIT_WOUNDS['+JSON.stringify(L)+'],'+JSON.stringify(loc)+','+r+')');
        if(!res||!res.wound){ok=false;break;}
        if(expect[loc].indexOf(String(res.wound.roll))<0){ok=false;break;}
        seen[res.wound.roll]=1;
      }
      S.check(L+' unaimed crit to '+loc+' stays on that location for all 2d6 totals',ok);
      if(expect[loc].length>1)
        S.check(L+' unaimed '+loc+' reaches both its entries across 2-12',
          Object.keys(seen).length===2);
    });
  });

  /* 6. unaimed torso crossover is at 9, head at 12 */
  S.eq('unaimed torso 8 -> lesser',ev('WB.critForLocation(CRIT_WOUNDS.Simple,"torso",8).wound.roll'),'6\u20138');
  S.eq('unaimed torso 9 -> greater',ev('WB.critForLocation(CRIT_WOUNDS.Simple,"torso",9).wound.roll'),'9\u201310');
  S.eq('unaimed head 11 -> lesser',ev('WB.critForLocation(CRIT_WOUNDS.Simple,"head",11).wound.roll'),'11');
  S.eq('unaimed head 12 -> greater',ev('WB.critForLocation(CRIT_WOUNDS.Simple,"head",12).wound.roll'),'12');

  /* 7. PARITY: the two aimed implementations must pick the same band */
  const pairs=[['head','head'],['torso','torso'],['r_arm','rarm'],['l_arm','larm'],
               ['r_leg','rleg'],['l_leg','lleg'],['r_limb','rlimb'],['l_limb','llimb']];
  LEVELS.forEach(L=>{
    pairs.forEach(([sheetId,wbId])=>{
      for(let d=1;d<=6;d++){
        const a=ev('(function(){var o=Math.random;Math.random=function(){return '+(((d-1)/6)+0.01)+';};'
          +'try{var r=resolveAimedCritWound('+JSON.stringify(L)+',{id:'+JSON.stringify(sheetId)+',label:"x"});'
          +'return r&&r.wound?String(r.wound.roll):null;}finally{Math.random=o;}})()');
        const b=ev('(function(){var r=WB.aimedCrit(CRIT_WOUNDS['+JSON.stringify(L)+'],'
          +JSON.stringify(wbId)+','+d+');return r&&r.wound?String(r.wound.roll):null;})()');
        S.eq('parity '+L+' '+sheetId+'/'+wbId+' d6='+d,a,b);
      }
    });
  });

  process.exit(S.report()?0:1);
},5000);
