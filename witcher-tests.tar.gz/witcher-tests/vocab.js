/* Extracts the real vocabulary of the two apps by measurement. Every wrong
   answer I gave in the session that prompted this came from testing with
   inputs the system never produces. This writes down what it does produce. */
const {boot}=require('/home/claude/T/harness.js');
const fs=require('fs');
const G=boot('/home/claude/W/gm.html'), S=boot('/home/claude/W/sheet.html');
setTimeout(()=>{
  const eg=x=>{try{return G.dom.window.eval(x);}catch(e){return null;}};
  const es=x=>{try{return S.dom.window.eval(x);}catch(e){return null;}};
  const J=v=>{try{return JSON.parse(v);}catch(e){return null;}};
  const out={};

  /* which globals live where \u2014 the mistake that cost two turns */
  const NAMES=['BATTLE_SCENES','DEFAULT_BESTIARY','RANDOM_POOLS','WB','combatants',
    'LAN_EXETER_SHOPS','SHOP_MIN_TIER','FORAGE_PLACES','getAllCompData','char',
    'RARITY_COLORS','SUBSTANCE_COLORS','_lanStock','_shopTier','GM_WATCHES',
    'PC_WATCHES','gmClock','pcClock','rollDiceFormula','_forageRollQty',
    'pcLootFindComp','resolveLootLine','TEXMAP','CITY_SIZES'];
  out.globals={};
  NAMES.forEach(n=>{
    const inG=eg('typeof '+n)!=='undefined' && eg('typeof '+n)!==null;
    const inS=es('typeof '+n)!=='undefined' && es('typeof '+n)!==null;
    out.globals[n]=(inG?'gm':'')+(inG&&inS?'+':'')+(inS?'sheet':'')||'neither';
  });

  /* side values the board actually produces, and what each renders as */
  eg('window.gmBattleToast=function(){};window.gmBattleTouch=function(){};window.gmBattleUndoPush=function(){};window.gmBroadcastRoster=function(){};window.gmSyncSend=function(){};window.logRoll=function(){};window.renderCombatants=function(){};window.gmBroadcastInitiative=function(){};window._gmBUi={};window._gmBView=null;window._gmB={toks:[],stamps:[],levels:[{n:"G"}],lvl:0,w:20,h:20};');
  const sides=new Set();
  (J(eg('JSON.stringify(BATTLE_SCENES.map(function(s){return s.id;}))'))||[]).forEach(id=>{
    eg('combatants.length=0;gmBattleLoadScene('+JSON.stringify(id)+',false);');
    (J(eg('JSON.stringify(window._gmB.toks.map(function(t){return t.side;}))'))||[])
      .forEach(s=>sides.add(String(s)));
  });
  out.sides={};
  Array.from(sides).sort().forEach(s=>{
    out.sides[s]={ colour:eg('WB.sideColor('+JSON.stringify(s)+')'),
                   shape:eg('WB.sideShape('+JSON.stringify(s)+')'),
                   dash:eg('WB.sideDash('+JSON.stringify(s)+')') };
  });
  out.sidesNotUsed={};
  ['pc','foe','npc','ally','monster'].forEach(s=>{
    if(!sides.has(s)) out.sidesNotUsed[s]=eg('WB.sideColor('+JSON.stringify(s)+')');
  });

  /* which render path a kind takes \u2014 the other mistake */
  out.renderPaths={};
  const kinds=J(eg('JSON.stringify(WB.KINDS.map(function(k){return k.k;}))'))||[];
  const counts={svgPattern:0, cssClass:0, inlineBase64:0, emojiOnly:0, flatColour:0};
  const sample={};
  kinds.forEach(k=>{
    const h=String(eg('WB.stampHTML({k:'+JSON.stringify(k)+',x:1,y:1,w:2,h:2},true)')||'');
    let path;
    if(/url\(#/.test(h))                 path='svgPattern';
    else if(/class="wbp-/.test(h))       path='cssClass';
    else if(/base64,/.test(h))           path='inlineBase64';
    else if(/background|gradient/.test(h)) path='flatColour';
    else                                 path='emojiOnly';
    counts[path]++;
    if(!sample[path]) sample[path]=k;
  });
  out.renderPaths={counts:counts, example:sample};

  /* the scene schema, as the loader actually reads it */
  out.sceneSchema={
    st:"[kind, x, y, w, h, label|null, level]  \u2014 terrain and props",
    sp:"[creatureName, count, x, y, level, 'open'?]  \u2014 'open' = visible at load",
    npc:"[name, x, y, level, role, info, where]  \u2014 tappable card, not a combatant",
    ic:"[name, x, y, level, emoji, kind, target, note]  \u2014 kind: shop|forage|game|inn",
    ct:"[x, y, type, difficulty, label, level, stampKind]  \u2014 loot",
    hz:"[x, y, w, h, name, effect, level]",
    tr:"[x, y, radius, name, detect, level]",
    fg:"[name, x, y, w, h, 'hidden'|'roof'|null, level]  \u2014 FOG, not labels",
    ev:"[x, y, w, h, height, name, level]  \u2014 elevation",
    lv:"[{n:'level name'}, ...]",
    bg:"a key into WB.CITYMAPS; bgx/bgy/bgw/bgo position it",
    gm:"['#Heading', 'line', ...]  \u2014 running notes shown on load"
  };

  /* valid targets for the things scenes point at */
  out.validTargets={
    shop:J(es('JSON.stringify(LAN_EXETER_SHOPS.map(function(s){return s.id;}))')),
    forage:J(es('JSON.stringify(Object.keys(FORAGE_PLACES))')),
    game:['gwent','dice','memory','aard'],
    bg:J(eg('JSON.stringify(Object.keys(WB.CITYMAPS||{}))')),
    poiArt:J(eg('JSON.stringify(Object.keys(WB.POI_ART||{}))'))
  };

  /* fields a loaded stamp and token actually carry */
  eg('combatants.length=0;gmBattleLoadScene("glass_forge",false);');
  out.loadedShapes={
    stamp:J(eg('JSON.stringify(Object.keys(window._gmB.stamps[0]||{}))')),
    token:J(eg('JSON.stringify(Object.keys(window._gmB.toks[0]||{}))')),
    stampLabelField:"l  (NOT 'label' \u2014 reading the wrong one broke the fog guard)"
  };

  fs.writeFileSync('/home/claude/T/vocab.json', JSON.stringify(out,null,1));
  console.log('globals mapped   :', Object.keys(out.globals).length);
  console.log('sides in use     :', Object.keys(out.sides).join(', '));
  console.log('sides NOT in use :', Object.keys(out.sidesNotUsed).join(', '));
  console.log('render paths     :', JSON.stringify(out.renderPaths.counts));
  console.log('valid shop ids   :', (out.validTargets.shop||[]).length);
  console.log('valid places     :', (out.validTargets.forage||[]).length);
  process.exit(0);
},7000);
