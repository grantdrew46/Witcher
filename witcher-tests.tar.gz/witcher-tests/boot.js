const {JSDOM}=require('jsdom'); const fs=require('fs');
const file=process.argv[2];
const errs=[];
const dom=new JSDOM(fs.readFileSync(file,'utf8'),{runScripts:'dangerously',pretendToBeVisual:true,
  url:'https://local/',resources:undefined,
  beforeParse(w){
    w.matchMedia=w.matchMedia||(q=>({matches:false,media:q,addListener(){},removeListener(){},addEventListener(){},removeEventListener(){}}));
    w.HTMLCanvasElement.prototype.getContext=()=>({fillRect(){},clearRect(){},drawImage(){},beginPath(){},arc(){},fill(){},stroke(){},moveTo(){},lineTo(){},save(){},restore(){},translate(){},rotate(){},scale(){},measureText:()=>({width:10}),fillText(){},strokeText(){},setTransform(){},createLinearGradient:()=>({addColorStop(){}}),putImageData(){},getImageData:()=>({data:[]}),closePath(){},rect(){},clip(){},quadraticCurveTo(){},bezierCurveTo(){},ellipse(){},setLineDash(){}});
    w.onerror=(m,s,l,c,e)=>{errs.push('window.onerror: '+m);};
    w.addEventListener('unhandledrejection',e=>errs.push('unhandledrejection: '+e.reason));
    const ce=w.console.error; w.console.error=(...a)=>{errs.push('console.error: '+a.join(' ').slice(0,200)); };
  }});
const vc=dom.virtualConsole; if(vc) vc.on('jsdomError',e=>errs.push('jsdomError: '+(e.message||e)));
setTimeout(()=>{
  const d=dom.window.document;
  console.log(file.split('/').pop(),
    '| els:',d.querySelectorAll('*').length,
    '| title:',(d.title||'').slice(0,50),
    '| errors:',errs.length);
  errs.slice(0,8).forEach(e=>console.log('   !',e.slice(0,220)));
  process.exit(0);
},4000);
