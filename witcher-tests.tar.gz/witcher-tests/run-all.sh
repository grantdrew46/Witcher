#!/bin/bash
export NODE_PATH=/home/claude/.npm-global/lib/node_modules
cd /home/claude/T || exit 1
P=0; F=0; BAD=0
for s in suites/*.js; do
  OUT=$(node --max-old-space-size=7168 "$s" 2>&1)
  echo "$OUT" | head -12
  L=$(echo "$OUT" | grep -o -E '[0-9]+ passed, [0-9]+ failed' | tail -1)
  p=$(echo "$L" | grep -o -E '^[0-9]+'); f=$(echo "$L" | grep -o -E '[0-9]+ failed' | grep -o -E '^[0-9]+')
  P=$((P+${p:-0})); F=$((F+${f:-0}))
  echo "$OUT" | grep -q '^\[PASS\]' || BAD=$((BAD+1))
done
echo "════════════════════════════════════════"
echo "TOTAL: $P passed, $F failed across $(ls suites/*.js | wc -l) suites ($BAD suite(s) failing)"
