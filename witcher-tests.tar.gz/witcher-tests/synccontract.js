/* Extracts the sync contract from both apps by parsing the source.
   Three things tripped a naive pass earlier and are handled here:
     - a handler can guard with !== as well as ===  (battle_state)
     - some traffic is sheet->sheet, not sheet->GM   (shop_state)
     - payload fields can be nested inside objects   (battle_fx a.gx / b.gy) */
const fs=require('fs');

function js(path){
  const h=fs.readFileSync(path,'utf8');
  const out=[]; const re=/<script(?![^>]*\bsrc=)[^>]*>([\s\S]*?)<\/script>/g;
  let m; while((m=re.exec(h))) out.push(m[1]);
  return out.join('\n;\n');
}

/* brace-match an object literal starting at the '{' index */
function objAt(s,i){
  let d=0,j=i;
  for(;j<s.length;j++){
    if(s[j]==='{') d++;
    else if(s[j]==='}'){ d--; if(!d) return s.slice(i,j+1); }
  }
  return s.slice(i,i+400);
}

/* top-level keys of an object literal, descending one level into nested
   objects so {a:{gx:1}} yields 'a' and 'a.gx'.
   Skips string and template literals — a payload like
   detail:'... rider: ' + x  otherwise reports a phantom 'rider' field. */
function keysOf(body){
  const keys=new Set();
  let d=0, q=null;
  for(let i=0;i<body.length;i++){
    const c=body[i];
    if(q){                                   /* inside a string: find its end */
      if(c==='\\'){ i++; continue; }
      if(c===q) q=null;
      continue;
    }
    if(c==='"'||c==="'"||c==='`'){ q=c; continue; }
    if(c==='{'||c==='['){ d++; continue; }
    if(c==='}'||c===']'){ d--; continue; }
    if(d!==1) continue;
    const m=/^([A-Za-z_$][\w$]*)\s*:/.exec(body.slice(i));
    if(m && (i===0 || /[{,\s]/.test(body[i-1]))){
      const k=m[1];
      keys.add(k);
      const rest=body.slice(i+m[0].length).replace(/^\s*/,'');
      if(rest[0]==='{'){
        const inner=objAt(rest,0);
        let dd=0, iq=null;
        for(let z=0;z<inner.length;z++){
          const ic=inner[z];
          if(iq){ if(ic==='\\'){ z++; continue; } if(ic===iq) iq=null; continue; }
          if(ic==='"'||ic==="'"||ic==='`'){ iq=ic; continue; }
          if(ic==='{'||ic==='[') dd++;
          else if(ic==='}'||ic===']') dd--;
          else if(dd===1){
            const im=/^([A-Za-z_$][\w$]*)\s*:/.exec(inner.slice(z));
            if(im && /[{,\s]/.test(inner[z-1]||'{')) keys.add(k+'.'+im[1]);
          }
        }
      }
      i+=m[0].length-1;
    }
  }
  return keys;
}

/* every {t:'x', ...} handed to the given send function */
function outbound(src,fn){
  const map={}; const re=new RegExp(fn.replace('$','\\$')+'\\(\\s*\\{','g');
  let m;
  while((m=re.exec(src))){
    const body=objAt(src,m.index+m[0].length-1);
    const t=/\bt\s*:\s*['"]([A-Za-z0-9_]+)['"]/.exec(body);
    if(!t) continue;
    const keys=keysOf(body); keys.delete('t');
    if(!map[t[1]]) map[t[1]]=new Set();
    keys.forEach(k=>map[t[1]].add(k));
  }
  return map;
}

/* every message type this file dispatches on, however it phrases the test */
function handled(src){
  const s=new Set();
  const pats=[
    /(?:\bm|msg|d|data|o|p|st|e)\s*\.\s*t\s*(?:===?|!==?)\s*['"]([A-Za-z0-9_]+)['"]/g,
    /['"]([A-Za-z0-9_]+)['"]\s*(?:===?|!==?)\s*(?:\bm|msg|d|data)\s*\.\s*t\b/g,
    /\bcase\s+['"]([A-Za-z0-9_]+)['"]\s*:/g,
    /\bt\s*(?:===?|!==?)\s*['"]([A-Za-z0-9_]+)['"]/g
  ];
  pats.forEach(re=>{ let m; while((m=re.exec(src))) s.add(m[1]); });
  return s;
}

/* is a payload field read anywhere in the receiving file? */
function reads(src,field){
  const parts=field.split('.');
  const leaf=parts[parts.length-1];
  return new RegExp('\\.\\s*'+leaf+'\\b|\\[\\s*[\'"]'+leaf+'[\'"]\\s*\\]').test(src);
}

module.exports={js,outbound,handled,reads,keysOf,objAt};
