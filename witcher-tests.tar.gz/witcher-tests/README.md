# Witcher toolkit — test suites

**2,513 assertions across 12 suites.** They load `gm.html` and `sheet.html` in
a headless browser and exercise them: aimed criticals against pg.158, falls
per pg.171, every battle scene loaded and checked for creatures standing in
walls or levels you cannot reach, a merchant and craftsman run through a year
of ventures, and every field the GM sends checked against what the sheet
actually reads.

## Running them

Node 18+ and jsdom.

    npm install -g jsdom
    export NODE_PATH=$(npm root -g)

Put `gm.html`, `sheet.html` and `map.html` somewhere, then edit the path at the
top of `harness.js` and in `validate.sh` if it is not `/home/claude/W/`.

    ./run-all.sh                        # every suite, about a minute
    node suites/06-loot-lifecycle.js    # one suite
    ./validate.sh sheet                 # syntax, boot, element count, size gate

## The suites

| # | covers |
|---|---|
| 01 | aimed criticals, pg.158 |
| 02 | falls pg.171, collision, floor traversal |
| 03 | both aimed-crit implementations agree |
| 04 | Balanced weapon effect, pg.72 |
| 05 | Monsters Without Anatomy, pg.159 |
| 06 | loot resolution, compendium matching, coin lines, mutagens, random pools |
| 07 | mounted charge, pg.171 |
| 08 | every GM-outbound and sheet-outbound message and field, plus world sync |
| 09 | stamp kinds, art reachability, scene integrity, level connectors |
| 10 | token names, stacking, cover, firing lanes |
| 11 | every scene loads and is playable; named NPCs; concealment |
| 12 | ventures, investment bands, co-investment, haggling, crafting, the armoury |

## Things it has caught

An abbey bell-tower that could not be reached because the stair skipped a
level. Cellar mud slowing anyone on the floor above it. A loot note that would
have spawned as an item called "See the sourcebook for this character's
equipment" on a player's board. Scene coordinates written for a 44-wide map
pasted into a 24-wide one. Creature names splitting their own mutagens in two.

## Notes

`validate.sh` enforces a 20,000,000-byte gate. That is 20 MB decimal, not 20
MiB — the sheet once sat at 20.55 MB while a MiB-based check called it fine.

`booktext/` holds plain-text extracts of the sourcebook PDFs, used to check
whether an item is actually printed somewhere before inventing stats for it.

A test that passes four times in five is worse than no test. Several suites
here gather across repeated runs rather than asserting on one random result,
because the first versions were flaky and that is worse than being absent.
